// Bhagavad Gita adhyay 7 - Gyaan Vigyana Yoga (30 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch07"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 7,
 "title": "ज्ञानविज्ञानयोग",
 "illustration": "",
 "illustrationCaption": "Self-Knowledge and Enlightenment",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का सातवा अध्याय ज्ञानविज्ञानयोग है। इस अध्याय में कृष्ण बताते हैं कि वह सर्वोच्च सत्य हैं एवं हर चीज़ के मुख्य कारण हैं। वे इस भौतिक संसार में अपनी भ्रामक ऊर्जा - योगमाया के बारे में बताते हैं अथवा प्रकट करते हैं कि इस ऊर्जा पर काबू पाना साधारण मनुष्य के लिए कितना कठिन है परन्तु जो मनुष्य अपने मन को परमात्मा में लीन कर लेते हैं वे इस माया को जीत लेते हैं और उन्हे आसानी से प्राप्त कर लेते हैं। वे उन चार प्रकार के लोगों का भी वर्णन करते हैं जो भक्ति में लीन होकर उनको आत्मसमर्पण करते हैं अथवा वे चार प्रकार जो नहीं करते। कृष्ण पुष्टि करते हैं कि वे ही परम सत्य हैं। जो लोग इस सत्य को समझ लेते हैं, वे आध्यात्मिक प्राप्ति के शिखर पर पहुंच जाते हैं और भगवान को प्राप्त कर लेते हैं।",
 "summaryEn": "The seventh chapter of the Bhagavad Gita is \"Gyaan Vigyana Yoga \". In this chapter, Krishna reveals that he is the Supreme Truth, the principal cause and the sustaining force of everything. He reveals his illusionary energy in this material world called Maya, which is very difficult to overcome but those who surrender their minds unto Him attain Him easily. He also describes the four types of people who surrender to Him in devotion and the four kinds that don't. Krishna confirms that He is the Ultimate Reality and those who realize this Truth reach the pinnacle of spiritual realization and unite with the Lord.",
 "verses": [
  {
   "n": 1,
   "sa": "श्री भगवानुवाच\nमय्यासक्तमनाः पार्थ योगं युञ्जन्मदाश्रयः।\nअसंशयं समग्रं मां यथा ज्ञास्यसि तच्छृणु।।7.1।।",
   "tr": "śhrī bhagavān uvācha\nmayyāsakta-manāḥ pārtha yogaṁ yuñjan mad-āśhrayaḥ\nasanśhayaṁ samagraṁ māṁ yathā jñāsyasi tach chhṛiṇu",
   "hi": "हे पार्थ ! मुझमें असक्त हुए मन वाले तथा मदाश्रित होकर योग का अभ्यास करते हुए जिस प्रकार तुम मुझे समग्ररूप से, बिना किसी संशय के, जानोगे वह सुनो।।",
   "en": "Lord Shri Krishna said: Listen, O Arjuna! I will tell you how you can know Me in my full perfection. Practice meditation with your mind devoted to Me and take Me as your refuge.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "ज्ञानं तेऽहं सविज्ञानमिदं वक्ष्याम्यशेषतः।\nयज्ज्ञात्वा नेह भूयोऽन्यज्ज्ञातव्यमवशिष्यते।।7.2।।",
   "tr": "jñānaṁ te ’haṁ sa-vijñānam idaṁ vakṣhyāmyaśheṣhataḥ\nyaj jñātvā neha bhūyo ’nyaj jñātavyam-avaśhiṣhyate",
   "hi": "मैं तुम्हारे लिए विज्ञान सहित इस ज्ञान को अशेष रूप से कहूँगा जिसको जानकर यहाँ (जगत् में) फिर और कुछ जानने योग्य (ज्ञातव्य) शेष नहीं रह जाता है।।",
   "en": "I will reveal this knowledge to you and how it can be realized; once accomplished, there is nothing else worth having in this life.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "मनुष्याणां सहस्रेषु कश्िचद्यतति सिद्धये।\nयततामपि सिद्धानां कश्िचन्मां वेत्ति तत्त्वतः।।7.3।।",
   "tr": "manuṣhyāṇāṁ sahasreṣhu kaśhchid yatati siddhaye\nyatatām api siddhānāṁ kaśhchin māṁ vetti tattvataḥ",
   "hi": "सहस्रों मनुष्यों में कोई ही मनुष्य पूर्णत्व की सिद्धि के लिए प्रयत्न करता है और उन प्रयत्नशील साधकों में भी कोई ही पुरुष मुझे तत्त्व से जानता है।।",
   "en": "Among thousands of men, scarcely one strives for perfection, and even among those who gain occult powers, perhaps only one knows me in truth.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "भूमिरापोऽनलो वायुः खं मनो बुद्धिरेव च।\nअहङ्कार इतीयं मे भिन्ना प्रकृतिरष्टधा।।7.4।।",
   "tr": "bhūmir-āpo ’nalo vāyuḥ khaṁ mano buddhir eva cha\nahankāra itīyaṁ me bhinnā prakṛitir aṣhṭadhā",
   "hi": "पृथ्वी, जल, अग्नि, वायु और आकाश तथा मन, बुद्धि और अहंकार - यह आठ प्रकार से विभक्त हुई मेरी प्रकृति है।।",
   "en": "Earth, water, fire, air, ether, mind, intellect, and personality—this is the eightfold division of My manifested nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "अपरेयमितस्त्वन्यां प्रकृतिं विद्धि मे पराम्।\nजीवभूतां महाबाहो ययेदं धार्यते जगत्।।7.5।।",
   "tr": "apareyam itas tvanyāṁ prakṛitiṁ viddhi me parām\njīva-bhūtāṁ mahā-bāho yayedaṁ dhāryate jagat",
   "hi": "हे महाबाहो ! यह अपरा प्रकृति है। इससे भिन्न मेरी जीवरूपी पराप्रकृति को जानो, जिससे यह जगत् धारण किया जाता है।।",
   "en": "This is My inferior nature; however, O valiant one, know that distinct from this is My superior nature, which is the very life that sustains the universe.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "एतद्योनीनि भूतानि सर्वाणीत्युपधारय।\nअहं कृत्स्नस्य जगतः प्रभवः प्रलयस्तथा।।7.6।।",
   "tr": "etad-yonīni bhūtāni sarvāṇītyupadhāraya\nahaṁ kṛitsnasya jagataḥ prabhavaḥ pralayas tathā",
   "hi": "यह जानो कि समम्पूर्ण भूत इन दोनों प्रकृतियों से उत्पत्ति वाले हैं। (अत:) मैं सम्पूर्ण जगत् का उत्पत्ति तथा प्रलय स्थान हूँ।।",
   "en": "It is the womb of all beings; for I am He by Whom the worlds were created and shall be dissolved.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "मत्तः परतरं नान्यत्किञ्चिदस्ति धनञ्जय।\nमयि सर्वमिदं प्रोतं सूत्रे मणिगणा इव।।7.7।।",
   "tr": "mattaḥ parataraṁ nānyat kiñchid asti dhanañjaya\nmayi sarvam idaṁ protaṁ sūtre maṇi-gaṇā iva",
   "hi": "हे धनंजय ! मुझसे श्रेष्ठ (परे) अन्य किचिन्मात्र वस्तु नहीं है। यह सम्पूर्ण जगत् सूत्र में मणियों के सदृश मुझमें पिरोया हुआ है।।",
   "en": "O Arjuna! There is nothing higher than Me; all is strung on Me like rows of pearls on a thread.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "रसोऽहमप्सु कौन्तेय प्रभास्मि शशिसूर्ययोः।\nप्रणवः सर्ववेदेषु शब्दः खे पौरुषं नृषु।।7.8।।",
   "tr": "raso ’ham apsu kaunteya prabhāsmi śhaśhi-sūryayoḥ\npraṇavaḥ sarva-vedeṣhu śhabdaḥ khe pauruṣhaṁ nṛiṣhu",
   "hi": "हे कौन्तेय ! जल में मैं रस हूँ, चन्द्रमा और सूर्य में प्रकाश हूँ, सब वेदों में प्रणव (ँ़कार) हूँ तथा आकाश में शब्द और पुरुषों में पुरुषत्व हूँ।।",
   "en": "O Arjuna! I am the fluidity in water, the light in the sun and moon, the mystic syllable Om in the Vedic scriptures, the sound in ether, and the virility in man.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "पुण्यो गन्धः पृथिव्यां च तेजश्चास्मि विभावसौ।\nजीवनं सर्वभूतेषु तपश्चास्मि तपस्विषु।।7.9।।",
   "tr": "puṇyo gandhaḥ pṛithivyāṁ cha tejaśh chāsmi vibhāvasau\njīvanaṁ sarva-bhūteṣhu tapaśh chāsmi tapasviṣhu",
   "hi": "पृथ्वी में पवित्र गन्ध हूँ और अग्नि में तेज हूँ; सम्पूर्ण भूतों में जीवन हूँ और तपस्वियों में मैं तप हूँ।।",
   "en": "I am the fragrance of the earth, the brilliance of fire, the life force in all beings, and the austerity of ascetics.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "बीजं मां सर्वभूतानां विद्धि पार्थ सनातनम्।\nबुद्धिर्बुद्धिमतामस्मि तेजस्तेजस्विनामहम्।।7.10।।",
   "tr": "bījaṁ māṁ sarva-bhūtānāṁ viddhi pārtha sanātanam\nbuddhir buddhimatām asmi tejas tejasvinām aham",
   "hi": "हे पार्थ ! सम्पूर्ण भूतों का सनातन बीज (कारण) मुझे ही जानो; मैं बुद्धिमानों की बुद्धि और तेजस्वियों का तेज हूँ।।",
   "en": "Know, O Arjuna, that I am the eternal seed of being; I am the intelligence of the intelligent, the splendour of the resplendent.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "बलं बलवतां चाहं कामरागविवर्जितम्।\nधर्माविरुद्धो भूतेषु कामोऽस्मि भरतर्षभ।।7.11।।",
   "tr": "balaṁ balavatāṁ chāhaṁ kāma-rāga-vivarjitam\ndharmāviruddho bhūteṣhu kāmo ’smi bharatarṣhabha",
   "hi": "हे भरत श्रेष्ठ ! मैं बलवानों का कामना तथा आसक्ति से रहित बल हूँ और सब भूतों में धर्म के अविरुद्ध अर्थात् अनुकूल काम हूँ।।",
   "en": "I am the strength of the strong, those who are free from attachment and desire; and, O Arjuna, I am the desire for righteousness.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "ये चैव सात्त्विका भावा राजसास्तामसाश्च ये।\nमत्त एवेति तान्विद्धि नत्वहं तेषु ते मयि।।7.12।।",
   "tr": "ye chaiva sāttvikā bhāvā rājasās tāmasāśh cha ye\nmatta eveti tān viddhi na tvahaṁ teṣhu te mayi",
   "hi": "जो भी सात्त्विक (शुद्ध), राजसिक (क्रियाशील) और तामसिक (जड़) भाव हैं, उन सबको तुम मेरे से उत्पन्न हुए जानो; तथापि मैं उनमें नहीं हूँ, वे मुझमें हैं।।",
   "en": "Whatever be the nature of their life, whether it be pure, passionate, or ignorant, they are all derived from Me. They are in Me, but I am not in them.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "त्रिभिर्गुणमयैर्भावैरेभिः सर्वमिदं जगत्।\nमोहितं नाभिजानाति मामेभ्यः परमव्ययम्।।7.13।।",
   "tr": "tribhir guṇa-mayair bhāvair ebhiḥ sarvam idaṁ jagat\nmohitaṁ nābhijānāti māmebhyaḥ param avyayam",
   "hi": "त्रिगुणों से उत्पन्न इन भावों (विकारों) से सम्पूर्ण जगत् (लोग) मोहित हुआ इन (गुणों) से परे अव्यय स्वरूप मुझे नहीं जानता है।।",
   "en": "The inhabitants of the world, misled by the natures engendered by the Qualities, do not know that I am higher than them all and that I do not change.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "दैवी ह्येषा गुणमयी मम माया दुरत्यया।\nमामेव ये प्रपद्यन्ते मायामेतां तरन्ति ते।।7.14।।",
   "tr": "daivī hyeṣhā guṇa-mayī mama māyā duratyayā\nmām eva ye prapadyante māyām etāṁ taranti te",
   "hi": "यह दैवी त्रिगुणमयी मेरी माया बड़ी दुस्तर है। परन्तु जो मेरी शरण में आते हैं, वे इस माया को पार कर जाते हैं।।",
   "en": "Verily, this divine illusion of phenomenon manifesting itself in the qualities is difficult to surmount. Only they who devote themselves exclusively to Me can accomplish it.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "न मां दुष्कृतिनो मूढाः प्रपद्यन्ते नराधमाः।\nमाययापहृतज्ञाना आसुरं भावमाश्रिताः।।7.15।।",
   "tr": "na māṁ duṣhkṛitino mūḍhāḥ prapadyante narādhamāḥ\nmāyayāpahṛita-jñānā āsuraṁ bhāvam āśhritāḥ",
   "hi": "दुष्कृत्य करने वाले, मूढ, नराधम पुरुष मुझे नहीं भजते हैं; माया के द्वारा जिनका ज्ञान हर लिया गया है, वे आसुरी भाव को धारण किये रहते हैं।।",
   "en": "The sinner, the ignorant, the vile, deprived of spiritual perception by the glamour of illusion, and he who leads a godless life—none of them shall find me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "चतुर्विधा भजन्ते मां जनाः सुकृतिनोऽर्जुन।\nआर्तो जिज्ञासुरर्थार्थी ज्ञानी च भरतर्षभ।।7.16।।",
   "tr": "chatur-vidhā bhajante māṁ janāḥ sukṛitino ’rjuna\nārto jijñāsur arthārthī jñānī cha bharatarṣhabha",
   "hi": "हे भरत श्रेष्ठ अर्जुन ! उत्तम कर्म करने वाले (सुकृतिन:) आर्त, जिज्ञासु, अर्थार्थी और ज्ञानी ऐसे चार प्रकार के लोग मुझे भजते हैं।।",
   "en": "O Arjuna! The righteous who worship Me are grouped in stages: first, those who suffer, next those who desire knowledge, then those who thirst after truth, and lastly those who attain wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "तेषां ज्ञानी नित्ययुक्त एकभक्ितर्विशिष्यते।\nप्रियो हि ज्ञानिनोऽत्यर्थमहं स च मम प्रियः।।7.17।।",
   "tr": "teṣhāṁ jñānī nitya-yukta eka-bhaktir viśhiṣhyate\npriyo hi jñānino ’tyartham ahaṁ sa cha mama priyaḥ",
   "hi": "उनमें भी मुझ से नित्ययुक्त, अनन्य भक्ति वाला ज्ञानी श्रेष्ठ है, क्योंकि ज्ञानी को मैं अत्यन्त प्रिय हूँ और वह मुझे अत्यन्त प्रिय है।।",
   "en": "Of all these, he who has gained wisdom, who meditates on Me without ceasing, devoting himself solely to Me, is the best; for I am exceedingly beloved by the wise man, and the wise man is also beloved by Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "उदाराः सर्व एवैते ज्ञानी त्वात्मैव मे मतम्।\nआस्थितः स हि युक्तात्मा मामेवानुत्तमां गतिम्।।7.18।।",
   "tr": "udārāḥ sarva evaite jñānī tvātmaiva me matam\nāsthitaḥ sa hi yuktātmā mām evānuttamāṁ gatim",
   "hi": "(यद्यपि) ये सब उत्कृष्ट हैं, परन्तु ज्ञानी तो मेरा स्वरूप ही है ऐसा मेरा मत है, क्योंकि वह स्थिर बुद्धि ज्ञानी अति उत्तम गतिस्वरूप मुझमें अच्छी प्रकार स्थित है।।",
   "en": "Noble-minded are they all, but the wise man I hold as my own self; for he, remaining always at peace with me, makes me his ultimate goal.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "बहूनां जन्मनामन्ते ज्ञानवान्मां प्रपद्यते।\nवासुदेवः सर्वमिति स महात्मा सुदुर्लभः।।7.19।।",
   "tr": "bahūnāṁ janmanām ante jñānavān māṁ prapadyate\nvāsudevaḥ sarvam iti sa mahātmā su-durlabhaḥ",
   "hi": "बहुत जन्मों के अन्त में (किसी एक जन्म विशेष में) ज्ञान को प्राप्त होकर कि 'यह सब वासुदेव है' ज्ञानी भक्त मुझे प्राप्त होता है; ऐसा महात्मा अति दुर्लभ है।।",
   "en": "After many lives, at last the wise one realizes Me as I am. It is very difficult to find a man so enlightened that he sees God everywhere.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "कामैस्तैस्तैर्हृतज्ञानाः प्रपद्यन्तेऽन्यदेवताः।\nतं तं नियममास्थाय प्रकृत्या नियताः स्वया।।7.20।।",
   "tr": "kāmais tais tair hṛita-jñānāḥ prapadyante ’nya-devatāḥ\ntaṁ taṁ niyamam āsthāya prakṛityā niyatāḥ svayā",
   "hi": "भोगविशेष की कामना से जिनका ज्ञान हर लिया गया है, ऐसे पुरुष अपने स्वभाव से प्रेरित हुए अन्य देवताओं को विशिष्ट नियम का पालन करते हुए भजते हैं।।",
   "en": "They in whom wisdom is obscured by one desire or another, worship the lesser powers, practicing many rites that vary according to their temperaments.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "यो यो यां यां तनुं भक्तः श्रद्धयार्चितुमिच्छति।\nतस्य तस्याचलां श्रद्धां तामेव विदधाम्यहम्।।7.21।।",
   "tr": "yo yo yāṁ yāṁ tanuṁ bhaktaḥ śhraddhayārchitum ichchhati\ntasya tasyāchalāṁ śhraddhāṁ tām eva vidadhāmyaham",
   "hi": "जो-जो (सकामी) भक्त जिस-जिस (देवता के) रूप को श्रद्धा से पूजना चाहता है, उस-उस (भक्त) की मैं उस ही देवता के प्रति श्रद्धा को स्थिर करता हूँ।।",
   "en": "But whatever form of worship, if the devotee has faith, then I set My own seal upon their faith in that worship.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "स तया श्रद्धया युक्तस्तस्याराधनमीहते।\nलभते च ततः कामान्मयैव विहितान् हि तान्।।7.22।।",
   "tr": "sa tayā śhraddhayā yuktas tasyārādhanam īhate\nlabhate cha tataḥ kāmān mayaiva vihitān hi tān",
   "hi": "वह (भक्त) उस श्रद्धा से युक्त होकर उस देवता का पूजन करता है और उससे मेरे द्वारा विधान किये हुये इच्छित भोगों को नि:सन्देह प्राप्त करता है।।",
   "en": "If he worships one form alone with real faith, then his desires shall be fulfilled through that alone; for thus I have ordained.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "अन्तवत्तु फलं तेषां तद्भवत्यल्पमेधसाम्।\nदेवान्देवयजो यान्ति मद्भक्ता यान्ति मामपि।।7.23।।",
   "tr": "antavat tu phalaṁ teṣhāṁ tad bhavatyalpa-medhasām\ndevān deva-yajo yānti mad-bhaktā yānti mām api",
   "hi": "परन्तु उन अल्प बुद्धि पुरुषों का वह फल नाशवान् होता है। देवताओं के पूजक देवताओं को प्राप्त होते हैं और मेरे भक्त मुझे ही प्राप्त होते हैं।।",
   "en": "The fruit that comes to people of limited insight is, after all, finite. Those who worship the Lower Powers attain them; but those who worship Me come to Me alone.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "अव्यक्तं व्यक्ितमापन्नं मन्यन्ते मामबुद्धयः।\nपरं भावमजानन्तो ममाव्ययमनुत्तमम्।।7.24।।",
   "tr": "avyaktaṁ vyaktim āpannaṁ manyante mām abuddhayaḥ\nparaṁ bhāvam ajānanto mamāvyayam anuttamam",
   "hi": "बुद्धिहीन पुरुष मेरे अनुत्तम (सर्वोत्तम) अव्यय परम भाव को न जानते हुए मुझ अव्यक्त को व्यक्त मानते हैं।।",
   "en": "The ignorant think of Me, who am the Unmanifested Spirit, as if I were in human form. They do not understand that My Superior Nature is unchanging and most excellent.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "नाहं प्रकाशः सर्वस्य योगमायासमावृतः।\nमूढोऽयं नाभिजानाति लोको मामजमव्ययम्।।7.25।।",
   "tr": "nāhaṁ prakāśhaḥ sarvasya yoga-māyā-samāvṛitaḥ\nmūḍho ’yaṁ nābhijānāti loko mām ajam avyayam",
   "hi": "अपनी योगमाया से आवृत्त मैं सबको प्रत्यक्ष नहीं होता हूँ। यह मोहित लोक (मनुष्य) मुझ जन्मरहित, अविनाशी को नहीं जानता है।।",
   "en": "I am not visible to all, for I am enveloped by the illusion of the Phenomenon. This deluded world does not know Me as the Unborn and Imperishable.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "वेदाहं समतीतानि वर्तमानानि चार्जुन।\nभविष्याणि च भूतानि मां तु वेद न कश्चन।।7.26।।",
   "tr": "vedāhaṁ samatītāni vartamānāni chārjuna\nbhaviṣhyāṇi cha bhūtāni māṁ tu veda na kaśhchana",
   "hi": "हे अर्जुन ! पूर्व में व्यतीत हुए और वर्तमान में स्थित तथा भविष्य में होने वाले भूतमात्र को मैं जानता हूँ, परन्तु मुझे कोई भी पुरुष नहीं जानता हैं।।",
   "en": "I know, O Arjuna, all beings in the past, the present, and the future; but they do not know Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "इच्छाद्वेषसमुत्थेन द्वन्द्वमोहेन भारत।\nसर्वभूतानि संमोहं सर्गे यान्ति परन्तप।।7.27।।",
   "tr": "ichchhā-dveṣha-samutthena dvandva-mohena bhārata\nsarva-bhūtāni sammohaṁ sarge yānti parantapa",
   "hi": "हे परन्तप भारत ! इच्छा और द्वेष से उत्पन्न द्वन्द्वमोह से भूतमात्र उत्पत्ति काल में ही संमोह (अविवेक) को प्राप्त होते हैं।।",
   "en": "O brave Arjuna! Man lives in a fantastical world, deceived by the glamour of opposing sensations, infatuated by desire and aversion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "येषां त्वन्तगतं पापं जनानां पुण्यकर्मणाम्।\nते द्वन्द्वमोहनिर्मुक्ता भजन्ते मां दृढव्रताः।।7.28।।",
   "tr": "yeṣhāṁ tvanta-gataṁ pāpaṁ janānāṁ puṇya-karmaṇām\nte dvandva-moha-nirmuktā bhajante māṁ dṛiḍha-vratāḥ",
   "hi": "परन्तु जिन पुण्यकर्मी पुरुषों का पाप नष्ट हो गया है, वे द्वन्द्वमोह से निर्मुक्त और दृढ़वती पुरुष मुझे भजते हैं।।",
   "en": "But those who act righteously, in whom sin has been destroyed, who are free from the infatuation of conflicting emotions, they worship Me with a firm resolve.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "जरामरणमोक्षाय मामाश्रित्य यतन्ति ये।\nते ब्रह्म तद्विदुः कृत्स्नमध्यात्मं कर्म चाखिलम्।।7.29।।",
   "tr": "jarā-maraṇa-mokṣhāya mām āśhritya yatanti ye\nte brahma tadviduḥ kṛitsnam adhyātmaṁ karma chākhilam",
   "hi": "जो मेरे शरणागत होकर जरा और मरण से मुक्ति पाने के लिए यत्न करते हैं, वे पुरुष उस ब्रह्म को, सम्पूर्ण अध्यात्म को और सम्पूर्ण कर्म को जानते हैं।।",
   "en": "Those who make Me their refuge, striving for liberation from decay and death, realize the Supreme Spirit, which is their own real Self, and in which all action finds its consummation.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 30,
   "sa": "साधिभूताधिदैवं मां साधियज्ञं च ये विदुः।\nप्रयाणकालेऽपि च मां ते विदुर्युक्तचेतसः।।7.30।।",
   "tr": "sādhibhūtādhidaivaṁ māṁ sādhiyajñaṁ cha ye viduḥ\nprayāṇa-kāle ’pi cha māṁ te vidur yukta-chetasaḥ",
   "hi": "जो पुरुष अधिभूत और अधिदैव तथा अधियज्ञ के सहित मुझे जानते हैं, वे युक्तचित्त वाले पुरुष अन्तकाल में भी मुझे जानते हैं।।",
   "en": "Those who see Me in the life of the world, in the universal sacrifice, and as pure Divinity, keeping their minds steady, they live in Me even in the hour of death's approach.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
