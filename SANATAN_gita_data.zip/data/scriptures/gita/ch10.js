// Bhagavad Gita adhyay 10 - Vibhooti Yoga (42 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch10"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 10,
 "title": "विभूतियोग",
 "illustration": "",
 "illustrationCaption": "Yoga through Appreciating the Infinite Opulences of God",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का दसवां अध्याय विभूतियोग है। इस अध्याय में, कृष्ण स्वयं को सभी कारणों के कारण बताते हैं। अर्जुन की भक्ति को बढ़ाने के लिए वे अपने विभिन्न अवतारों और प्रतिष्ठानों का वर्णन करते हैं। अर्जुन पूरी तरह से भगवान के सर्वोच्च पद से आश्वस्त हैं और उन्हें सर्वोच्च व्यक्तित्व के रूप में घोषित करते हैं। वे कृष्ण से प्रार्थना करते हैं कि वे अपनी अन्य दिव्य महिमाओं के बारेमे बताएं जो कि सुनने में अमृत सामान हैं।        ",
 "summaryEn": "The tenth chapter of the Bhagavad Gita is \"Vibhooti Yoga\". In this chapter, Krishna reveals Himself as the cause of all causes. He describes His various manifestations and opulences in order to increase Arjuna's Bhakti. Arjuna is fully convinced of Lord's paramount position and proclaims him to be the Supreme Personality. He prays to Krishna to describe more of His divine glories which are like nectar to hear.",
 "verses": [
  {
   "n": 1,
   "sa": "श्री भगवानुवाच\nभूय एव महाबाहो श्रृणु मे परमं वचः।\nयत्तेऽहं प्रीयमाणाय वक्ष्यामि हितकाम्यया।।10.1।।",
   "tr": "śhrī bhagavān uvācha\nbhūya eva mahā-bāho śhṛiṇu me paramaṁ vachaḥ\nyatte ’haṁ prīyamāṇāya vakṣhyāmi hita-kāmyayā",
   "hi": "श्रीभगवान् ने कहा -- हे महाबाहो ! पुन: तुम मेरे परम वचनों का श्रवण करो, जो मैं तुझ अतिशय प्रेम रखने वाले के लिये हित की इच्छा से कहूँगा।।",
   "en": "Lord Shri Krishna said: Now, O Prince! Listen to My supreme advice, which I give you for the sake of your welfare, for you are My beloved.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "न मे विदुः सुरगणाः प्रभवं न महर्षयः।\nअहमादिर्हि देवानां महर्षीणां च सर्वशः।।10.2।।",
   "tr": "na me viduḥ sura-gaṇāḥ prabhavaṁ na maharṣhayaḥ\naham ādir hi devānāṁ maharṣhīṇāṁ cha sarvaśhaḥ",
   "hi": "मेरी उत्पत्ति (प्रभव) को न देवतागण जानते हैं और न महर्षिजन; क्योंकि मैं सब प्रकार से देवताओं और महर्षियों का भी आदिकारण हूँ।।",
   "en": "Neither the professors of divinity nor the great ascetics know My origin, for I am the source from which they all originate.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "यो मामजमनादिं च वेत्ति लोकमहेश्वरम्।\nअसम्मूढः स मर्त्येषु सर्वपापैः प्रमुच्यते।।10.3।।",
   "tr": "yo māmajam anādiṁ cha vetti loka-maheśhvaram\nasammūḍhaḥ sa martyeṣhu sarva-pāpaiḥ pramuchyate",
   "hi": "जो मुझे अजन्मा, अनादि और लोकों के महान् ईश्वर के रूप में जानता है, र्मत्य मनुष्यों में ऐसा संमोहरहित (ज्ञानी) पुरुष सब पापों से मुक्त हो जाता है।।",
   "en": "He who knows Me as the unborn, without beginning, the Lord of the universe, he, stripped of his delusions, becomes free from all conceivable sins.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "बुद्धिर्ज्ञानमसंमोहः क्षमा सत्यं दमः शमः।\nसुखं दुःखं भवोऽभावो भयं चाभयमेव च।।10.4।।",
   "tr": "buddhir jñānam asammohaḥ kṣhamā satyaṁ damaḥ śhamaḥ\nsukhaṁ duḥkhaṁ bhavo ’bhāvo bhayaṁ chābhayameva cha",
   "hi": "बुद्धि, ज्ञान, मोह का अभाव, क्षमा, सत्य, दम (इन्द्रिय संयम), शम (मन: संयम), सुख, दु:ख, जन्म और मृत्यु, भय और अभय।।",
   "en": "Intelligence, wisdom, non-delusion, forgiveness, truth, self-control, calmness, pleasure, pain, birth, death, fear, and fearlessness;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "अहिंसा समता तुष्टिस्तपो दानं यशोऽयशः।\nभवन्ति भावा भूतानां मत्त एव पृथग्विधाः।।10.5।।",
   "tr": "ahiṁsā   samatā  tuṣṭis tapo dānaṁ   yaśo    'yaśaḥ  bhavanti    bhāvā   bhūtānāṁ    matta   eva pṛthag-vidhāḥ",
   "hi": "अहिंसा, समता, सन्तोष, तप, दान. यश और अपयश ऐसे ये प्राणियों के नानाविध भाव मुझ से ही प्रकट होते हैं।।",
   "en": "Harmlessness, equanimity, contentment, austerity, beneficence, fame, and failure—all these characteristics of beings spring from Me alone.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "महर्षयः सप्त पूर्वे चत्वारो मनवस्तथा।\nमद्भावा मानसा जाता येषां लोक इमाः प्रजाः।।10.6।।",
   "tr": "maharṣhayaḥ sapta pūrve chatvāro manavas tathā\nmad-bhāvā mānasā jātā yeṣhāṁ loka imāḥ prajāḥ",
   "hi": "सात महर्षिजन, पूर्वकाल के चार (सनकादि) तथा (चौदह) मनु ये मेरे प्रभाव वाले मेरे संकल्प से उत्पन्न हुए हैं, जिनकी संसार (लोक) में यह प्रजा है।।",
   "en": "The seven Great Seers, the progenitors of mankind, the Ancient Four, and the Lawgivers were born of My will and come forth directly from Me. The race of mankind has sprung from them. (Mareechi, Atri, Angira, Pulah, Kratu, Pulastya, Vahishta; the Masters: Sanak, Sanandan, Sanatan, Sanatkumar.)",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "एतां विभूतिं योगं च मम यो वेत्ति तत्त्वतः।\nसोऽविकम्पेन योगेन युज्यते नात्र संशयः।।10.7।।",
   "tr": "etāṁ vibhūtiṁ yogaṁ cha mama yo vetti tattvataḥ\nso ’vikampena yogena yujyate nātra sanśhayaḥ",
   "hi": "जो पुरुष इस मेरी विभूति और योग को तत्त्व से जानता है, वह पुरुष अविकम्प योग (अर्थात् निश्चल ध्यान योग) से युक्त हो जाता है, इसमें कुछ भी संशय नहीं है।।",
   "en": "He who rightly understands My manifested glory and My creative power attains perfect peace without a doubt.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "अहं सर्वस्य प्रभवो मत्तः सर्वं प्रवर्तते।\nइति मत्वा भजन्ते मां बुधा भावसमन्विताः।।10.8।।",
   "tr": "ahaṁ sarvasya prabhavo mattaḥ sarvaṁ pravartate\niti matvā bhajante māṁ budhā bhāva-samanvitāḥ",
   "hi": "मैं ही सबका प्रभव स्थान हूँ; मुझसे ही सब (जगत्) विकास को प्राप्त होता है, इस प्रकार जानकर बुधजन भक्ति भाव से युक्त होकर मुझे ही भजते हैं।।",
   "en": "I am the source of all; from me everything flows. Therefore, the wise worship me with an unchanging devotion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "मच्चित्ता मद्गतप्राणा बोधयन्तः परस्परम्।\nकथयन्तश्च मां नित्यं तुष्यन्ति च रमन्ति च।।10.9।।",
   "tr": "mach-chittā mad-gata-prāṇā bodhayantaḥ parasparam\nkathayantaśh cha māṁ nityaṁ tuṣhyanti cha ramanti cha",
   "hi": "मुझमें ही चित्त को स्थिर करने वाले और मुझमें ही प्राणों (इन्द्रियों) को अर्पित करने वाले भक्तजन, सदैव परस्पर मेरा बोध कराते हुए, मेरे ही विषय में कथन करते हुए सन्तुष्ट होते हैं और रमते हैं।।",
   "en": "With minds concentrated on Me, with lives absorbed in Me, and enlightening one another, they ever feel content and happy.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "तेषां सततयुक्तानां भजतां प्रीतिपूर्वकम्।\nददामि बुद्धियोगं तं येन मामुपयान्ति ते।।10.10।।",
   "tr": "teṣhāṁ satata-yuktānāṁ bhajatāṁ prīti-pūrvakam\ndadāmi buddhi-yogaṁ taṁ yena mām upayānti te",
   "hi": "उन (मुझ से) नित्य युक्त हुए और प्रेमपूर्वक मेरा भजन करने वाले भक्तों को, मैं वह 'बुद्धियोग' देता हूँ जिससे वे मुझे प्राप्त होते हैं।।",
   "en": "To those who are always devout and who worship Me with love, I give the power of discrimination that leads them to Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "तेषामेवानुकम्पार्थमहमज्ञानजं तमः।\nनाशयाम्यात्मभावस्थो ज्ञानदीपेन भास्वता।।10.11।।",
   "tr": "teṣhām evānukampārtham aham ajñāna-jaṁ tamaḥ\nnāśhayāmyātma-bhāva-stho jñāna-dīpena bhāsvatā",
   "hi": "उनके ऊपर अनुग्रह करने के लिए मैं उनके अन्त:करण में स्थित होकर, अज्ञानजनित अन्धकार को प्रकाशमय ज्ञान के दीपक द्वारा नष्ट करता हूँ।।",
   "en": "By My grace, I live in their hearts, and I dispel the darkness of ignorance with the shining light of wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "अर्जुन उवाच\nपरं ब्रह्म परं धाम पवित्रं परमं भवान्।\nपुरुषं शाश्वतं दिव्यमादिदेवमजं विभुम्।।10.12।।",
   "tr": "arjuna uvācha\nparaṁ brahma paraṁ dhāma pavitraṁ paramaṁ bhavān\npuruṣhaṁ śhāśhvataṁ divyam ādi-devam ajaṁ vibhum",
   "hi": "अर्जुन ने कहा आप -परम ब्रह्म, परम धाम और परम पवित्र हंै; सनातन दिव्य पुरुष, देवों के भी आदि देव, जन्म रहित और सर्वव्यापी हैं।।",
   "en": "Arjuna asked: Thou art the Supreme Spirit, the Eternal Home, the Holiest of Holies, the Eternal Divine Self, the Primal God, the Unborn, and Omnipresent.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "आहुस्त्वामृषयः सर्वे देवर्षिर्नारदस्तथा।\nअसितो देवलो व्यासः स्वयं चैव ब्रवीषि मे।।10.13।।",
   "tr": "āhus tvām ṛiṣhayaḥ sarve devarṣhir nāradas tathā\nasito devalo vyāsaḥ svayaṁ chaiva bravīṣhi me",
   "hi": "ऐसा आपको समस्त ऋषिजन कहते हैं; वैसे ही देवर्षि नारद, असित, देवल ऋषि तथा व्यास और स्वयं आप भी मेरे प्रति कहते हैं।।",
   "en": "So have said the seers, the divine sage Narada, Asita, Devala, and Vyasa; and Thou Thyself also sayest it.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "सर्वमेतदृतं मन्ये यन्मां वदसि केशव।\nन हि ते भगवन् व्यक्ितं विदुर्देवा न दानवाः।।10.14।।",
   "tr": "sarvam etad ṛitaṁ manye yan māṁ vadasi keśhava\nna hi te bhagavan vyaktiṁ vidur devā na dānavāḥ",
   "hi": "हे केशव ! जो कुछ भी आप मेरे प्रति कहते हैं, इस सबको मैं सत्य मानता हूँ। हे भगवन्, आपके (वास्तविक) स्वरूप को न देवता जानते हैं और न दानव।।",
   "en": "I believe in what You have said, my Lord! For neither the godly nor the godless comprehend Your manifestation.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "स्वयमेवात्मनाऽत्मानं वेत्थ त्वं पुरुषोत्तम।\nभूतभावन भूतेश देवदेव जगत्पते।।10.15।।",
   "tr": "swayam evātmanātmānaṁ vettha tvaṁ puruṣhottama\nbhūta-bhāvana bhūteśha deva-deva jagat-pate",
   "hi": "हे पुरुषोत्तम ! हे भूतभावन ! हे भूतेश ! हे देवों के देव ! हे जगत् के स्वामी ! आप स्वयं ही अपने आप को जानते हैं।।",
   "en": "You alone know Yourself, by the power of Your Self; You are the Supreme Spirit, the Source and Master of all being, the Lord of Lords, the Ruler of the Universe.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "वक्तुमर्हस्यशेषेण दिव्या ह्यात्मविभूतयः।\nयाभिर्विभूतिभिर्लोकानिमांस्त्वं व्याप्य तिष्ठसि।।10.16।।",
   "tr": "vaktum arhasyaśheṣheṇa divyā hyātma-vibhūtayaḥ\nyābhir vibhūtibhir lokān imāṁs tvaṁ vyāpya tiṣhṭhasi",
   "hi": "आप ही उन अपनी दिव्य विभूतियों को अशेषत: कहने के लिए योग्य हैं, जिन विभूतियों के द्वारा इन समस्त लोकों को आप व्याप्त करके स्थित हैं।।",
   "en": "Please tell me about all of Your glorious manifestations, through which You pervade the world.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "कथं विद्यामहं योगिंस्त्वां सदा परिचिन्तयन्।\nकेषु केषु च भावेषु चिन्त्योऽसि भगवन्मया।।10.17।।",
   "tr": "kathaṁ vidyām ahaṁ yogins tvāṁ sadā parichintayan\nkeṣhu keṣhu cha bhāveṣhu chintyo ’si bhagavan mayā",
   "hi": "हे योगेश्वर ! मैं किस प्रकार निरन्तर चिन्तन करता हुआ आपको जानूँ, और हे भगवन् ! आप किनकिन भावों में मेरे द्वारा चिन्तन करने योग्य हैं।।",
   "en": "O Master! How can I, through constant meditation, come to know You? My Lord! What are Your various manifestations through which I can meditate on You?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "विस्तरेणात्मनो योगं विभूतिं च जनार्दन।\nभूयः कथय तृप्तिर्हि श्रृण्वतो नास्ति मेऽमृतम्।।10.18।।",
   "tr": "vistareṇātmano yogaṁ vibhūtiṁ cha janārdana\nbhūyaḥ kathaya tṛiptir hi śhṛiṇvato nāsti me ’mṛitam",
   "hi": "हे जनार्दन ! अपनी योग शक्ति और विभूति को पुन: विस्तारपूर्वक कहिए, क्योंकि आपके अमृतमय वचनों को सुनते हुए मुझे तृप्ति नहीं होती।।",
   "en": "Tell me again, I pray, of Thy power and Thy glory in full; for I feel that I am never satisfied when I listen to Thy immortal words.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "श्री भगवानुवाच\nहन्त ते कथयिष्यामि दिव्या ह्यात्मविभूतयः।\nप्राधान्यतः कुरुश्रेष्ठ नास्त्यन्तो विस्तरस्य मे।।10.19।।",
   "tr": "śhrī bhagavān uvācha\nhanta te kathayiṣhyāmi divyā hyātma-vibhūtayaḥ\nprādhānyataḥ kuru-śhreṣhṭha nāstyanto vistarasya me",
   "hi": "श्रीभगवान् ने कहा -हन्त अब मैं तुम्हें अपनी दिव्य विभूतियों को प्रधानता से कहूँगा। हे कुरुश्रेष्ठ मेरे विस्तार का अन्त नहीं है।।",
   "en": "Lord Shri Krishna replied: So be it, My beloved friend! I will unfold to you some of the chief aspects of My glory. There is no end to its full extent.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "अहमात्मा गुडाकेश सर्वभूताशयस्थितः।\nअहमादिश्च मध्यं च भूतानामन्त एव च।।10.20।।",
   "tr": "aham ātmā guḍākeśha sarva-bhūtāśhaya-sthitaḥ\naham ādiśh cha madhyaṁ cha bhūtānām anta eva cha",
   "hi": "हे गुडाकेश (निद्राजित्) ! मैं समस्त भूतों के हृदय में स्थित सबकी आत्मा हूँ तथा सम्पूर्ण भूतों का आदि, मध्य और अन्त भी मैं ही हूँ।।",
   "en": "O Arjuna! I am the Self, seated in the hearts of all beings; I am the beginning, the life, and the end of them all.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "आदित्यानामहं विष्णुर्ज्योतिषां रविरंशुमान्।\nमरीचिर्मरुतामस्मि नक्षत्राणामहं शशी।।10.21।।",
   "tr": "ādityānām ahaṁ viṣhṇur jyotiṣhāṁ ravir anśhumān\nmarīchir marutām asmi nakṣhatrāṇām ahaṁ śhaśhī",
   "hi": "मैं (बारह) आदित्यों में विष्णु और ज्योतियों में अंशुमान् सूर्य हूँ; मैं (उनचास) मरुतों (वायु देवताओं) में मरीचि हूँ और नक्षत्रों में शशी (चन्द्रमा) हूँ।।",
   "en": "Of all the creative powers, I am the Creator; of luminaries, the Sun; of winds, the Whirlwind; and of planets, the Moon.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "वेदानां सामवेदोऽस्मि देवानामस्मि वासवः।\nइन्द्रियाणां मनश्चास्मि भूतानामस्मि चेतना।।10.22।।",
   "tr": "vedānāṁ sāma-vedo ’smi devānām asmi vāsavaḥ\nindriyāṇāṁ manaśh chāsmi bhūtānām asmi chetanā",
   "hi": "मैं वेदों में सामवेद हूँ, देवों में वासव (इन्द्र) हूँ; मैं इन्द्रियों में मन और भूतप्राणियों में चेतना (ज्ञानशक्ति) हूँ।।",
   "en": "Of the Vedas, I am the hymns; I am the electric force in the powers of nature; of the senses, I am the mind; and I am the intelligence in all that lives.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "रुद्राणां शङ्करश्चास्मि वित्तेशो यक्षरक्षसाम्।\nवसूनां पावकश्चास्मि मेरुः शिखरिणामहम्।।10.23।।",
   "tr": "rudrāṇāṁ śhaṅkaraśh chāsmi vitteśho yakṣha-rakṣhasām\nvasūnāṁ pāvakaśh chāsmi meruḥ śhikhariṇām aham",
   "hi": "मैं (ग्यारह) रुद्रों में शंकर हूँ और यक्ष तथा राक्षसों में धनपति कुबेर (वित्तेश) हूँ; (आठ) वसुओं में अग्नि हूँ तथा शिखर वाले पर्वतों में मेरु हूँ।।",
   "en": "Among forces of vitality, I am the life; I am Mammon to the heathens and the godless; I am the energy in fire, earth, wind, sky, heaven, sun, moon, and planets; and among mountains, I am Mount Meru.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "पुरोधसां च मुख्यं मां विद्धि पार्थ बृहस्पतिम्।\nसेनानीनामहं स्कन्दः सरसामस्मि सागरः।।10.24।।",
   "tr": "purodhasāṁ cha mukhyaṁ māṁ viddhi pārtha bṛihaspatim\nsenānīnām ahaṁ skandaḥ sarasām asmi sāgaraḥ",
   "hi": "हे पार्थ ! पुरोहितों में मुझे बृहस्पति जानो; मैं सेनापतियों में स्कन्द और जलाशयों में समुद्र हूँ।।",
   "en": "Among the priests, know, O Arjuna, that I am the priest Brihaspati; of generals, I am Skanda, the Commander-in-Chief, and of waters, I am the Ocean.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "महर्षीणां भृगुरहं गिरामस्म्येकमक्षरम्।\nयज्ञानां जपयज्ञोऽस्मि स्थावराणां हिमालयः।।10.25।।",
   "tr": "maharṣhīṇāṁ bhṛigur ahaṁ girām asmyekam akṣharam\nyajñānāṁ japa-yajño ’smi sthāvarāṇāṁ himālayaḥ",
   "hi": "मैं महर्षियों में भृगु और वाणी (शब्दों) में एकाक्षर ओंकार हूँ। मैं यज्ञों में जपयज्ञ और स्थावरों (अचलों) में हिमालय हूँ।।",
   "en": "Of the great seers, I am Bhrigu; of words, I am Om; of offerings, I am the silent prayer; among things immovable, I am the Himalayas.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "अश्वत्थः सर्ववृक्षाणां देवर्षीणां च नारदः।\nगन्धर्वाणां चित्ररथः सिद्धानां कपिलो मुनिः।।10.26।।",
   "tr": "aśhvatthaḥ sarva-vṛikṣhāṇāṁ devarṣhīṇāṁ cha nāradaḥ\ngandharvāṇāṁ chitrarathaḥ siddhānāṁ kapilo muniḥ",
   "hi": "मैं समस्त वृक्षों में अश्वत्थ (पीपल) हूँ और देवर्षियों में नारद हूँ; मैं गन्धर्वों में चित्ररथ और सिद्ध पुरुषों में कपिल मुनि हूँ।।",
   "en": "Of trees, I am the sacred fig tree; of divine seers, Narada; of heavenly singers, I am Chitraratha, their leader; and of sages, I am Kapila.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "उच्चैःश्रवसमश्वानां विद्धि माममृतोद्भवम्।\nऐरावतं गजेन्द्राणां नराणां च नराधिपम्।।10.27।।",
   "tr": "uchchaiḥśhravasam aśhvānāṁ viddhi mām amṛitodbhavam\nairāvataṁ gajendrāṇāṁ narāṇāṁ cha narādhipam",
   "hi": "अश्वों में अमृत से उत्पन्न हुए उच्चैश्रवा नामक अश्व, हाथियों में ऐरावत और मनुष्यों में राजा मुझे ही जानो।।",
   "en": "Know that among horses I am Pegasus, heaven-born; among the lordly elephants I am the white one, and I am the ruler among men.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "आयुधानामहं वज्रं धेनूनामस्मि कामधुक्।\nप्रजनश्चास्मि कन्दर्पः सर्पाणामस्मि वासुकिः।।10.28।।",
   "tr": "āyudhānām ahaṁ vajraṁ dhenūnām asmi kāmadhuk\nprajanaśh chāsmi kandarpaḥ sarpāṇām asmi vāsukiḥ",
   "hi": "मैं शस्त्रों में वज्र और धेनुओं (गायों) में कामधेनु हूँ, प्रजा उत्पत्ति का हेतु कन्दर्प (कामदेव) मैं हूँ और सर्पों में वासुकि हूँ।।",
   "en": "I am the thunderbolt among weapons; I am the Cow of Plenty among cows; I am Passion in those who procreate, and I am the Cobra among serpents.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "अनन्तश्चास्मि नागानां वरुणो यादसामहम्।\nपितृ़णामर्यमा चास्मि यमः संयमतामहम्।।10.29।।",
   "tr": "anantaśh chāsmi nāgānāṁ varuṇo yādasām aham\npitṝīṇām aryamā chāsmi yamaḥ sanyamatām aham",
   "hi": "मैं नागों में अनन्त (शेषनाग) हूँ और जल देवताओं में वरुण हूँ; मैं पितरों में अर्यमा हँ और नियमन करने वालों में यम हूँ।।",
   "en": "I am the king-python among snakes, I am the aqueous principle among those that live in water, I am the father of fathers, and among rulers I am death.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 30,
   "sa": "प्रह्लादश्चास्मि दैत्यानां कालः कलयतामहम्।\nमृगाणां च मृगेन्द्रोऽहं वैनतेयश्च पक्षिणाम्।।10.30।।",
   "tr": "prahlādaśh chāsmi daityānāṁ kālaḥ kalayatām aham\nmṛigāṇāṁ cha mṛigendro ’haṁ vainateyaśh cha pakṣhiṇām",
   "hi": "मैं दैत्यों में प्रह्लाद और गणना करने वालों में काल हूँ, मैं 'पशुओं' में सिंह (मृगेन्द्र) और पक्षियों में गरुड़ हूँ।।",
   "en": "And I am the devotee Prahlada among the heathens; of Time I am the Eternal Present; I am the Lion among beasts and the Eagle among birds.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 31,
   "sa": "पवनः पवतामस्मि रामः शस्त्रभृतामहम्।\nझषाणां मकरश्चास्मि स्रोतसामस्मि जाह्नवी।।10.31।।",
   "tr": "pavanaḥ pavatām asmi rāmaḥ śhastra-bhṛitām aham\njhaṣhāṇāṁ makaraśh chāsmi srotasām asmi jāhnavī",
   "hi": "मैं पवित्र करने वालों में वायु हूँ और शस्त्रधारियों में राम हूँ; तथा मत्स्यों (जलचरों) में मैं मगरमच्छ और नदियों में मैं गंगा हूँ।।",
   "en": "I am the wind among purifiers, the king Rama among warriors; I am the crocodile among fishes, and I am the Ganges among rivers.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 32,
   "sa": "सर्गाणामादिरन्तश्च मध्यं चैवाहमर्जुन।\nअध्यात्मविद्या विद्यानां वादः प्रवदतामहम्।।10.32।।",
   "tr": "sargāṇām ādir antaśh cha madhyaṁ chaivāham arjuna\nadhyātma-vidyā vidyānāṁ vādaḥ pravadatām aham",
   "hi": "हे अर्जुन ! सृष्टियों का आदि, अन्त और मध्य भी मैं ही हूँ, मैं विद्याओं में अध्यात्मविद्या और विवाद करने वालों में (अर्थात् विवाद के प्रकारों में) मैं वाद हूँ।।",
   "en": "I am the beginning, the middle, and the end of creation; among sciences, I am the science of spirituality; I am the discussion among disputants.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 33,
   "sa": "अक्षराणामकारोऽस्मि द्वन्द्वः सामासिकस्य च।\nअहमेवाक्षयः कालो धाताऽहं विश्वतोमुखः।।10.33।।",
   "tr": "अहमेवाक्षय: कालो धाताहं विश्वतोमुख: || 33||\nakṣharāṇām a-kāro ’smi dvandvaḥ sāmāsikasya cha\naham evākṣhayaḥ kālo dhātāhaṁ viśhvato-mukhaḥ",
   "hi": "मैं अक्षरों (वर्णमाला) में अकार और समासों में द्वन्द्व (नामक समास) हूँ; मैं अक्षय काल और विश्वतोमुख (विराट् स्वरूप) धाता हूँ।।",
   "en": "Of letters, I am A; I am the copulative in compound words; I am inexhaustible Time; and I am the all-pervading Preserver.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 34,
   "sa": "मृत्युः सर्वहरश्चाहमुद्भवश्च भविष्यताम्।\nकीर्तिः श्रीर्वाक्च नारीणां स्मृतिर्मेधा धृतिः क्षमा।।10.34।।",
   "tr": "mṛityuḥ sarva-haraśh chāham udbhavaśh cha bhaviṣhyatām\nkīrtiḥ śhrīr vāk cha nārīṇāṁ smṛitir medhā dhṛitiḥ kṣhamā",
   "hi": "मैं सर्वभक्षक मृत्यु और भविष्य में होने वालों की उत्पत्ति का कारण हूँ; स्त्रियों में कीर्ति, श्री, वाक (वाणी), स्मृति, मेधा, धृति और क्षमा हूँ।।",
   "en": "I am all-devouring Death; I am the Origin of all that will happen; I am Fame, Fortune, Speech, Memory, Intellect, Constancy, and Forgiveness.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 35,
   "sa": "बृहत्साम तथा साम्नां गायत्री छन्दसामहम्।\nमासानां मार्गशीर्षोऽहमृतूनां कुसुमाकरः।।10.35।।",
   "tr": "bṛihat-sāma tathā sāmnāṁ gāyatrī chhandasām aham\nmāsānāṁ mārga-śhīrṣho ’ham ṛitūnāṁ kusumākaraḥ",
   "hi": "सामों (गेय मन्त्रों) में मैं बृहत्साम और छन्दों में गायत्री छन्द हूँ; मैं मासों में मार्गशीर्ष (दिसम्बरजनवरी के भाग) और ऋतुओं में वसन्त हूँ।।",
   "en": "Of hymns, I am Brihatsama; of meters, I am Garatri; among months, I am Margasheersha (December); and I am Spring among seasons.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 36,
   "sa": "द्यूतं छलयतामस्मि तेजस्तेजस्विनामहम्।\nजयोऽस्मि व्यवसायोऽस्मि सत्त्वं सत्त्ववतामहम्।।10.36।।",
   "tr": "dyūtaṁ chhalayatām asmi tejas tejasvinām aham\njayo ’smi vyavasāyo ’smi sattvaṁ sattvavatām aham",
   "hi": "मैं छल करने वालों में द्यूत हूँ और तेजस्वियों में तेज हूँ, मैं विजय हूँ; मैं व्यवसाय (उद्यमशीलता) हूँ और सात्विक पुरुषों का सात्विक भाव हूँ।।",
   "en": "I am the gambler's cheat and the splendor of the splendid; I am victory; I am effort; and I am the purity of the pure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 37,
   "sa": "वृष्णीनां वासुदेवोऽस्मि पाण्डवानां धनंजयः।\nमुनीनामप्यहं व्यासः कवीनामुशना कविः।।10.37।।",
   "tr": "vṛiṣhṇīnāṁ vāsudevo ’smi pāṇḍavānāṁ dhanañjayaḥ\nmunīnām apyahaṁ vyāsaḥ kavīnām uśhanā kaviḥ",
   "hi": "मैं वृष्णियों में वासुदेव हूँ और पाण्डवों में धनंजय, मैं मुनियों में व्यास और कवियों में उशना कवि हूँ।।",
   "en": "I am Shri Krishna among the Vishnu-clan, Arjuna among the Pandavas, Vyasa among the saints, and Shukracharya among the sages.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 38,
   "sa": "दण्डो दमयतामस्मि नीतिरस्मि जिगीषताम्।\nमौनं चैवास्मि गुह्यानां ज्ञानं ज्ञानवतामहम्।।10.38।।",
   "tr": "daṇḍo damayatām asmi nītir asmi jigīṣhatām\nmaunaṁ chaivāsmi guhyānāṁ jñānaṁ jñānavatām aham",
   "hi": "मैं दमन करने वालों का दण्ड हूँ और विजयेच्छुओं की नीति हूँ; मैं गुह्यों में मौन हूँ और ज्ञानवानों का ज्ञान हूँ।।",
   "en": "I am the scepter of rulers, the strategy of conquerors, the silence of mystery, and the wisdom of the wise.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 39,
   "sa": "यच्चापि सर्वभूतानां बीजं तदहमर्जुन।\nन तदस्ति विना यत्स्यान्मया भूतं चराचरम्।।10.39।।",
   "tr": "yach chāpi sarva-bhūtānāṁ bījaṁ tad aham arjuna\nna tad asti vinā yat syān mayā bhūtaṁ charācharam",
   "hi": "हे अर्जुन ! जो समस्त भूतों की उत्पत्ति का बीज (कारण) है, वह भी में ही हूँ, क्योंकि ऐसा कोई चर और अचर भूत नहीं है, जो मुझसे रहित है।।",
   "en": "I am the seed of all beings, O Arjuna! No creature, moving or unmoving, can live without Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 40,
   "sa": "नान्तोऽस्ति मम दिव्यानां विभूतीनां परंतप।\nएष तूद्देशतः प्रोक्तो विभूतेर्विस्तरो मया।।10.40।।",
   "tr": "nānto ’sti mama divyānāṁ vibhūtīnāṁ parantapa\neṣha tūddeśhataḥ prokto vibhūter vistaro mayā",
   "hi": "हे परन्तप ! मेरी दिव्य विभूतियों का अन्त नहीं है; अपनी विभूतियों का यह विस्तार मैंने एक देश से अर्थात् संक्षेप में कहा है।।",
   "en": "O Arjuna! The aspects of My divine life are endless; I have mentioned only a few as an example.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 41,
   "sa": "यद्यद्विभूतिमत्सत्त्वं श्रीमदूर्जितमेव वा।\nतत्तदेवावगच्छ त्वं मम तेजोंऽशसंभवम्।।10.41।।",
   "tr": "yad yad vibhūtimat sattvaṁ śhrīmad ūrjitam eva vā\ntat tad evāvagachchha tvaṁ mama tejo ’nśha-sambhavam",
   "hi": "जो कोई भी विभूतियुक्त, कान्तियुक्त अथवा शक्तियुक्त वस्तु (या प्राणी) है, उसको तुम मेरे तेज के अंश से ही उत्पन्न हुई जानो।।",
   "en": "Whatever is glorious, excellent, beautiful, and mighty, be assured that it comes from a fragment of My splendor.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 42,
   "sa": "अथवा बहुनैतेन किं ज्ञातेन तवार्जुन।\nविष्टभ्याहमिदं कृत्स्नमेकांशेन स्थितो जगत्।।10.42।।",
   "tr": "atha vā bahunaitena kiṁ jñātena tavārjuna\nviṣhṭabhyāham idaṁ kṛitsnam ekānśhena sthito jagat",
   "hi": "अथवा हे अर्जुन ! बहुत जानने से तुम्हारा क्या प्रयोजन है? मैं इस सम्पूर्ण जगत् को अपने एक अंश मात्र से धारण करके स्थित हूँ।।",
   "en": "But what is the use of all these details to you, O Arjuna? I sustain this universe with only a small part of Myself.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
