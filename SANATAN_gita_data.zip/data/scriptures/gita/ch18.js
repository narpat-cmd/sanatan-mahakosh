// Bhagavad Gita adhyay 18 - Moksha Sanyaas Yoga (78 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch18"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 18,
 "title": "मोक्षसंन्यासयोग",
 "illustration": "",
 "illustrationCaption": "Yoga through the Perfection of Renunciation and Surrender",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का अठारहवा अध्याय मोक्षसन्यासयोग है। अर्जुन कृष्ण से अनुरोध करते हैं कि वे संन्यास और त्याग के बीच अंतर को समझाने की कृपा करें। कृष्ण बताते हैं कि एक संन्यासी वह है जो आध्यात्मिक अनुशासन का अभ्यास करने के लिए परिवार और समाज को त्याग देता है जबकि एक त्यागी वह है जो अपने कर्मों के फलों कि चिंता करे बिना भगवन को समर्पित करके कर्म करता रहता है। कृष्ण बताते हैं कि त्याग संन्यास से श्रेष्ठ है। फिर कृष्णा भौतिक संसार के तीन प्रकार के गुणों का विस्तारपूर्वक वर्णन करते हैं। कृष्णा घोषणा करते हैं कि परमात्मा की शुद्ध एवं सत्य भक्ति ही आध्यात्मिकता का उच्चतम मार्ग है। अगर हम हर क्षण उनका स्मरण करते रहें, उनका नाम जपते रहें, अपना सर्वस्व उनको समर्पित कर दें, उन्हें ही अपना सर्वोच्च लक्ष्य बना लें तो उनकी कृपा से हम निश्चित रूप से सभी बाधाओं और कठिनाइओं को दूर कर पाएंगे और इस जन्म और मृत्यु के चक्र से मुक्त हो पाएंगे।",
 "summaryEn": "The eighteenth chapter of the Bhagavad Gita is \"Moksha Sanyas Yoga\". Arjuna requests the Lord to explain the difference between the two types of renunciations - sanyaas(renunciation of actions) and tyaag(renunciation of desires). Krishna explains that a sanyaasi is one who abandons family and society in order to practise spiritual discipline whereas a tyaagi is one who performs their duties without attachment to the rewards of their actions and dedicating them to the God. Krishna recommends the second kind of renunciation - tyaag. Krishna then gives a detailed analysis of the effects of the three modes of material nature. He declares that the highest path of spirituality is pure, unconditional loving service unto the Supreme Divine Personality, Krishna. If we always remember Him, keep chanting His name and dedicate all our actions unto Him, take refuge in Him and make Him our Supreme goal, then by His grace, we will surely overcome all obstacles and difficulties and be freed from this cycle of birth and death.",
 "verses": [
  {
   "n": 1,
   "sa": "अर्जुन उवाच\nसंन्यासस्य महाबाहो तत्त्वमिच्छामि वेदितुम्।\nत्यागस्य च हृषीकेश पृथक्केशिनिषूदन।।18.1।।",
   "tr": "arjuna uvācha\nsannyāsasya mahā-bāho tattvam ichchhāmi veditum\ntyāgasya cha hṛiṣhīkeśha pṛithak keśhi-niṣhūdana",
   "hi": "अर्जुन ने कहा -- हे महाबाहो ! हे हृषीकेश ! हे केशनिषूदन ! मैं संन्यास और त्याग के तत्त्व को पृथक्-पृथक् जानना चाहता हूँ।।",
   "en": "Arjuna asked, \"O Mighty One! I desire to know how relinquishment is distinguished from renunciation.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "श्री भगवानुवाच\nकाम्यानां कर्मणां न्यासं संन्यासं कवयो विदुः।\nसर्वकर्मफलत्यागं प्राहुस्त्यागं विचक्षणाः।।18.2।।",
   "tr": "śhrī-bhagavān uvācha\nkāmyānāṁ karmaṇāṁ nyāsaṁ sannyāsaṁ kavayo viduḥ\nsarva-karma-phala-tyāgaṁ prāhus tyāgaṁ vichakṣhaṇāḥ",
   "hi": "श्रीभगवान् ने कहा -- (कुछ) कवि (पण्डित) जन काम्य कर्मों के त्याग को \"संन्यास\" समझते हैं और विचारशील जन समस्त कर्मों के फलों के त्याग को \"त्याग\" कहते हैं।।",
   "en": "Lord Shri Krishna replied: The sages say that renunciation is forgoing an action that springs from desire, and relinquishing is the surrender of its fruit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "त्याज्यं दोषवदित्येके कर्म प्राहुर्मनीषिणः।\nयज्ञदानतपःकर्म न त्याज्यमिति चापरे।।18.3।।",
   "tr": "tyājyaṁ doṣha-vad ity eke karma prāhur manīṣhiṇaḥ\nyajña-dāna-tapaḥ-karma na tyājyam iti chāpare",
   "hi": "कुछ मनीषी जन कहते हैं कि समस्त कर्म दोषयुक्त होने के कारण त्याज्य हैं; और अन्य जन कहते हैं कि यज्ञ, दान और तपरूप कर्म त्याज्य नहीं हैं।।",
   "en": "Some philosophers say that all action is evil and should be abandoned, whereas others maintain that acts of sacrifice, benevolence, and austerity should not be given up.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "निश्चयं श्रृणु मे तत्र त्यागे भरतसत्तम।त्यागो हि पुरुषव्याघ्र त्रिविधः संप्रकीर्तितः।।18.4।।",
   "tr": "niśhchayaṁ śhṛiṇu me tatra tyāge bharata-sattama\ntyāgo hi puruṣha-vyāghra tri-vidhaḥ samprakīrtitaḥ",
   "hi": "हे भरतसत्तम ! उस त्याग के विषय में तुम मेरे निर्णय को सुनो। हे पुरुष श्रेष्ठ ! वह त्याग तीन प्रकार का कहा गया है।।",
   "en": "O best of Indians! Listen to my judgment regarding this problem. It has a threefold aspect.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "यज्ञदानतपःकर्म न त्याज्यं कार्यमेव तत्।यज्ञो दानं तपश्चैव पावनानि मनीषिणाम्।।18.5।।",
   "tr": "yajña-dāna-tapaḥ-karma na tyājyaṁ kāryam eva tat\nyajño dānaṁ tapaśh chaiva pāvanāni manīṣhiṇām",
   "hi": "यज्ञ, दान और तपरूप कर्म त्याज्य नहीं है, किन्तु वह नि:सन्देह कर्तव्य है; यज्ञ, दान और तप ये मनीषियों (साधकों) को पवित्र करने वाले हैं।।",
   "en": "Acts of sacrifice, benevolence, and austerity should not be given up, but should be performed, for they purify the aspiring soul.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "एतान्यपि तु कर्माणि सङ्गं त्यक्त्वा फलानि च।कर्तव्यानीति मे पार्थ निश्िचतं मतमुत्तमम्।।18.6।।",
   "tr": "etāny api tu karmāṇi saṅgaṁ tyaktvā phalāni cha\nkartavyānīti me pārtha niśhchitaṁ matam uttamam",
   "hi": "हे पार्थ ! इन कर्मों को भी, फल और आसक्ति को त्यागकर करना चाहिए, यह मेरा निश्चय किया हुआ उत्तम मत है।।",
   "en": "But they should be done with detachment and without thought of reward. This is my final judgement.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "नियतस्य तु संन्यासः कर्मणो नोपपद्यते।मोहात्तस्य परित्यागस्तामसः परिकीर्तितः।।18.7।।",
   "tr": "niyatasya tu sannyāsaḥ karmaṇo nopapadyate\nmohāt tasya parityāgas tāmasaḥ parikīrtitaḥ",
   "hi": "नियत कर्म का त्याग उचित नहीं है; मोहवश उसका त्याग करना \"तामस त्याग\" कहा गया है।।",
   "en": "It is not right to give up actions which are obligatory; and if they are misunderstood, it is the result of sheer ignorance.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "दुःखमित्येव यत्कर्म कायक्लेशभयात्त्यजेत्।स कृत्वा राजसं त्यागं नैव त्यागफलं लभेत्।।18.8।।",
   "tr": "duḥkham ity eva yat karma kāya-kleśha-bhayāt tyajet\nsa kṛitvā rājasaṁ tyāgaṁ naiva tyāga-phalaṁ labhet",
   "hi": "जो मनुष्य, कर्म को दु:ख समझकर शारीरिक कष्ट के भय से त्याग देता है, वह पुरुष उस राजसिक त्याग को करके कदापि त्याग के फल को प्राप्त नहीं होता है।।",
   "en": "To avoid an action out of fear of physical suffering, as it is likely to be painful, is to act out of passion, and the benefit of renunciation will not be gained.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "कार्यमित्येव यत्कर्म नियतं क्रियतेऽर्जुन।सङ्गं त्यक्त्वा फलं चैव स त्यागः सात्त्विको मतः।।18.9।।",
   "tr": "kāryam ity eva yat karma niyataṁ kriyate ‘rjuna\nsaṅgaṁ tyaktvā phalaṁ chaiva sa tyāgaḥ sāttviko mataḥ",
   "hi": "हे अर्जुन ! \"कर्म करना कर्तव्य है\" ऐसा समझकर जो नियत कर्म आसक्ति और फल को त्यागकर किया जाता है, वही सात्त्विक त्याग माना गया है।।",
   "en": "He who performs an obligatory action, believing it to be a duty that ought to be done, without any personal desire to do the act or to receive any return—such renunciation is pure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "न द्वेष्ट्यकुशलं कर्म कुशले नानुषज्जते।त्यागी सत्त्वसमाविष्टो मेधावी छिन्नसंशयः।।18.10।।",
   "tr": "na dveṣhṭy akuśhalaṁ karma kuśhale nānuṣhajjate\ntyāgī sattva-samāviṣhṭo medhāvī chhinna-sanśhayaḥ",
   "hi": "जो पुरुष अकुशल (अशुभ) कर्म से द्वेष नहीं करता और कुशल (शुभ) कर्म में आसक्त नहीं होता, वह सत्त्वगुण से सम्पन्न पुरुष संशयरहित, मेधावी (ज्ञानी) और त्यागी है।।",
   "en": "The wise man who has attained purity, whose doubts are resolved, who is filled with the spirit of self-abnegation, does not shy away from action due to its pain, nor does he crave it due to its pleasure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "न हि देहभृता शक्यं त्यक्तुं कर्माण्यशेषतः।यस्तु कर्मफलत्यागी स त्यागीत्यभिधीयते।।18.11।।",
   "tr": "na hi deha-bhṛitā śhakyaṁ tyaktuṁ karmāṇy aśheṣhataḥ\nyas tu karma-phala-tyāgī sa tyāgīty abhidhīyate",
   "hi": "क्योंकि देहधारी पुरुष के द्वारा अशेष कर्मों का त्याग संभव नहीं है, इसलिए जो कर्मफल त्यागी है, वही पुरुष त्यागी कहा जाता है।।",
   "en": "But since those still in the body cannot entirely avoid action, in their case, the abandonment of the fruit of action is considered as complete renunciation.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "अनिष्टमिष्टं मिश्रं च त्रिविधं कर्मणः फलम्।भवत्यत्यागिनां प्रेत्य न तु संन्यासिनां क्वचित्।।18.12।।",
   "tr": "aniṣhṭam iṣhṭaṁ miśhraṁ cha tri-vidhaṁ karmaṇaḥ phalam\nbhavaty atyāgināṁ pretya na tu sannyāsināṁ kvachit",
   "hi": "कर्मों के शुभ, अशुभ और मिश्र ये त्रिविध फल केवल अत्यागी जनों को मरण के पश्चात् भी प्राप्त होते हैं; परन्तु संन्यासी पुरुषों को कदापि नहीं।।",
   "en": "For those who cannot renounce all desires, the fruit of action hereafter is threefold—good, evil, and partly good and partly evil. But for him who has renounced, there is none.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "पञ्चैतानि महाबाहो कारणानि निबोध मे।सांख्ये कृतान्ते प्रोक्तानि सिद्धये सर्वकर्मणाम्।।18.13।।",
   "tr": "pañchaitāni mahā-bāho kāraṇāni nibodha me\nsānkhye kṛitānte proktāni siddhaye sarva-karmaṇām",
   "hi": "हे महाबाहो ! समस्त कर्मों की सिद्धि के लिए ये पांच कारण सांख्य सिद्धांत में कहे गये हैं, जिनको तुम मुझसे भलीभांति जानो।।",
   "en": "I will now tell you, O Mighty Man, the five causes that must come together, according to the final decision of philosophy, for an action to be accomplished.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "अधिष्ठानं तथा कर्ता करणं च पृथग्विधम्।विविधाश्च पृथक्चेष्टा दैवं चैवात्र पञ्चमम्।।18.14।।",
   "tr": "adhiṣhṭhānaṁ tathā kartā karaṇaṁ cha pṛithag-vidham\nvividhāśh cha pṛithak cheṣhṭā daivaṁ chaivātra pañchamam",
   "hi": "अधिष्ठान (शरीर), कर्ता ,विविध करण (इन्द्रियादि) ,विविध और पृथक्-पृथक् चेष्टाएं तथा पाँचवा हेतु दैव है।।",
   "en": "They have a body, a personality, physical organs, and manifold activities and destinies.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "शरीरवाङ्मनोभिर्यत्कर्म प्रारभते नरः।न्याय्यं वा विपरीतं वा पञ्चैते तस्य हेतवः।।18.15।।",
   "tr": "śharīra-vāṅ-manobhir yat karma prārabhate naraḥ\nnyāyyaṁ vā viparītaṁ vā pañchaite tasya hetavaḥ",
   "hi": "मनुष्य अपने शरीर, वाणी और मन से जो कोई न्याय्य (उचित) या विपरीत (अनुचित) कर्म करता है, उसके ये पाँच कारण ही हैं।।",
   "en": "Whatever action a person performs, whether by muscular effort, speech, or thought, and whether it be right or wrong, these five are the essential causes.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "तत्रैवं सति कर्तारमात्मानं केवलं तु यः।पश्यत्यकृतबुद्धित्वान्न स पश्यति दुर्मतिः।।18.16।।",
   "tr": "tatraivaṁ sati kartāram ātmānaṁ kevalaṁ tu yaḥ\npaśhyaty akṛita-buddhitvān na sa paśhyati durmatiḥ",
   "hi": "अब इस स्थिति में जो पुरुष असंस्कृत बुद्धि होने के कारण, केवल शुद्ध आत्मा को कर्ता समझता हैं, वह दुर्मति पुरुष (यथार्थ) नहीं देखता है।।",
   "en": "But the fool, who, due to his immature judgment, supposes that it is his own Self alone that acts, perverts the truth and does not see rightly.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "यस्य नाहंकृतो भावो बुद्धिर्यस्य न लिप्यते।हत्वापि स इमाँल्लोकान्न हन्ति न निबध्यते।।18.17।।",
   "tr": "yasya nāhankṛito bhāvo buddhir yasya na lipyate\nhatvā ‘pi sa imāl lokān na hanti na nibadhyate",
   "hi": "जिस पुरुष में अहंकार का भाव नहीं है और बुद्धि किसी (गुण दोष) से लिप्त नहीं होती, वह पुरुष इन सब लोकों को मारकर भी वास्तव में न मरता है और न (पाप से) बँधता है।।",
   "en": "He who has no pride and whose intellect is unalloyed by attachment, even though he kills these people, he does not kill them, and his act does not bind him.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "ज्ञानं ज्ञेयं परिज्ञाता त्रिविधा कर्मचोदना।करणं कर्म कर्तेति त्रिविधः कर्मसंग्रहः।।18.18।।",
   "tr": "jñānaṁ jñeyaṁ parijñātā tri-vidhā karma-chodanā\nkaraṇaṁ karma karteti tri-vidhaḥ karma-saṅgrahaḥ",
   "hi": "ज्ञान, ज्ञेय और परिज्ञाता ये त्रिविध कर्म प्रेरक हैं, और, करण, कर्म. कर्ता ये त्रिविध कर्म संग्रह हैं।।",
   "en": "Knowledge, the knower, and the object of knowledge are the three incentives to action; and the act, the actor, and the instrument are the threefold constituents.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "ज्ञानं कर्म च कर्ता च त्रिधैव गुणभेदतः।प्रोच्यते गुणसंख्याने यथावच्छृणु तान्यपि।।18.19।।",
   "tr": "jñānaṁ karma cha kartā cha tridhaiva guṇa-bhedataḥ\nprochyate guṇa-saṅkhyāne yathāvach chhṛiṇu tāny api",
   "hi": "ज्ञान, कर्म और कर्ता भी गुणों के भेद से सांख्यशास्त्र (गुणसंख्याने) में त्रिविध ही कहे गये हैं; उनको भी तुम मुझ से यथावत् श्रवण करो।।",
   "en": "The knowledge, the action, and the doer differ according to their qualities. Listen to this as well.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "सर्वभूतेषु येनैकं भावमव्ययमीक्षते।अविभक्तं विभक्तेषु तज्ज्ञानं विद्धि सात्त्विकम्।।18.20।।",
   "tr": "sarva-bhūteṣhu yenaikaṁ bhāvam avyayam īkṣhate\navibhaktaṁ vibhakteṣhu taj jñānaṁ viddhi sāttvikam",
   "hi": "जिस ज्ञान से मनुष्य, विभक्त रूप में स्थित समस्त भूतों में एक अविभक्त और अविनाशी (अव्यय) स्वरूप को देखता है, उस ज्ञान को तुम सात्त्विक जानो।।",
   "en": "That knowledge which sees the One Indestructible in all beings, the One Indivisible in all separate lives, can be truly called Pure Knowledge.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "पृथक्त्वेन तु यज्ज्ञानं नानाभावान्पृथग्विधान्।वेत्ति सर्वेषु भूतेषु तज्ज्ञानं विद्धि राजसम्।।18.21।।",
   "tr": "pṛithaktvena tu yaj jñānaṁ nānā-bhāvān pṛithag-vidhān\nvetti sarveṣhu bhūteṣhu taj jñānaṁ viddhi rājasam",
   "hi": "जिस ज्ञान के द्वारा मनुष्य समस्त भूतों में नाना भावों को पृथक्-पृथक् जानता है, उस ज्ञान को तुम राजस जानो।।",
   "en": "The knowledge that perceives the manifold existence in all beings as separate comes from passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "यत्तु कृत्स्नवदेकस्मिन्कार्ये सक्तमहैतुकम्।अतत्त्वार्थवदल्पं च तत्तामसमुदाहृतम्।।18.22।।",
   "tr": "yat tu kṛitsna-vad ekasmin kārye saktam ahaitukam\natattvārtha-vad alpaṁ cha tat tāmasam udāhṛitam",
   "hi": "और जिस ज्ञान के द्वारा मनुष्य एक कार्य (शरीर) में ही आसक्त हो जाता है, मानो वह (कार्य ही) पूर्ण वस्तु हो तथा जो (ज्ञान) हेतुरहित (अयुक्तिक), तत्त्वार्थ से रहित तथा संकुचित (अल्प) है, वह (ज्ञान) तामस है।।",
   "en": "But that which clings blindly to one idea as if it were all, without logic, truth, or insight, has its origin in darkness.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "नियतं सङ्गरहितमरागद्वेषतः कृतम्।अफलप्रेप्सुना कर्म यत्तत्सात्त्विकमुच्यते।।18.23।।",
   "tr": "niyataṁ saṅga-rahitam arāga-dveṣhataḥ kṛitam\naphala-prepsunā karma yat tat sāttvikam uchyate",
   "hi": "जो कर्म (शास्त्रविधि से) नियत और संगरहित है, तथा फल को न चाहने वाले पुरुष के द्वारा बिना किसी राग द्वेष के किया गया है, वह (कर्म) सात्त्विक कहा जाता है।।",
   "en": "An obligatory action done by one who is disinterested, who neither likes nor dislikes it, and gives no thought to the consequences that may follow, such an action is Pure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "यत्तु कामेप्सुना कर्म साहङ्कारेण वा पुनः।क्रियते बहुलायासं तद्राजसमुदाहृतम्।।18.24।।",
   "tr": "yat tu kāmepsunā karma sāhankāreṇa vā punaḥ\nkriyate bahulāyāsaṁ tad rājasam udāhṛitam",
   "hi": "और जो कर्म बहुत परिश्रम से युक्त है तथा फल की कामना वाले, अहंकारयुक्त पुरुष के द्वारा किया जाता है, वह कर्म राजस कहा गया है।।",
   "en": "But even though an action involves the most strenuous endeavor, yet if the doer is seeking to gratify their desires and is filled with personal vanity, it may be assumed to originate in passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "अनुबन्धं क्षयं हिंसामनपेक्ष्य च पौरुषम्।मोहादारभ्यते कर्म यत्तत्तामसमुच्यते।।18.25।।",
   "tr": "anubandhaṁ kṣhayaṁ hinsām anapekṣhya cha pauruṣham\nmohād ārabhyate karma yat tat tāmasam uchyate",
   "hi": "जो कर्म परिणाम, हानि, हिंसा और सार्मथ्य (पौरुषम्) का विचार न करके केवल मोहवश आरम्भ किया जाता है, वह कर्म तामस कहलाता है।।",
   "en": "An action undertaken through delusion, with no regard to the spiritual implications, the capacity of the doer, or the potential harm that may follow, is assumed to be a product of ignorance.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "मुक्तसङ्गोऽनहंवादी धृत्युत्साहसमन्वितः।सिद्ध्यसिद्ध्योर्निर्विकारः कर्ता सात्त्विक उच्यते।।18.26।।",
   "tr": "mukta-saṅgo ‘nahaṁ-vādī dhṛity-utsāha-samanvitaḥ\nsiddhy-asiddhyor nirvikāraḥ kartā sāttvika uchyate",
   "hi": "जो कर्ता संगरहित, अहंमन्यता से रहित, धैर्य और उत्साह से युक्त एवं कार्य की सिद्धि (सफलता) और असिद्धि (विफलता) में निर्विकार रहता है, वह कर्ता सात्त्विक कहा जाता है।।",
   "en": "But when a person has no sentiment or ego, when they possess courage and confidence, not caring whether they succeed or fail, then their action arises from purity.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "रागी कर्मफलप्रेप्सुर्लुब्धो हिंसात्मकोऽशुचिः।हर्षशोकान्वितः कर्ता राजसः परिकीर्तितः।।18.27।।",
   "tr": "rāgī karma-phala-prepsur lubdho hinsātmako ‘śhuchiḥ\nharṣha-śhokānvitaḥ kartā rājasaḥ parikīrtitaḥ",
   "hi": "रागी, कर्मफल का इच्छुक, लोभी, हिंसक स्वभाव वाला, अशुद्ध और हर्षशोक से युक्त कर्ता राजस कहलाता है।।",
   "en": "In one who is impulsive, greedy, looking for reward, violent, impure, and torn between joy and sorrow, it may be assumed that Passion is predominant.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "अयुक्तः प्राकृतः स्तब्धः शठो नैष्कृतिकोऽलसः।विषादी दीर्घसूत्री च कर्ता तामस उच्यते।।18.28।।",
   "tr": "ayuktaḥ prākṛitaḥ stabdhaḥ śhaṭho naiṣhkṛitiko ‘lasaḥ\nviṣhādī dīrgha-sūtrī cha kartā tāmasa uchyate",
   "hi": "अयुक्त, प्राकृत, स्तब्ध, शठ, नैष्कृतिक, आलसी, विषादी और दीर्घसूत्री कर्ता तामस कहा जाता है।।",
   "en": "While he whose purpose is weak, who is low-minded, stubborn, dishonest, malicious, lazy, despondent, and procrastinating—he may be assumed to be in darkness.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "बुद्धेर्भेदं धृतेश्चैव गुणतस्त्रिविधं श्रृणु।प्रोच्यमानमशेषेण पृथक्त्वेन धनञ्जय।।18.29।।",
   "tr": "buddher bhedaṁ dhṛiteśh chaiva guṇatas tri-vidhaṁ śhṛiṇu\nprochyamānam aśheṣheṇa pṛithaktvena dhanañjaya",
   "hi": "हे धनंजय ! मेरे द्वारा अशेषत: और पृथकत: कहे जाने वाले, गुणों के कारण उत्पन्न हुए बुद्धि और धृति के त्रिविध भेद को सुनो।।",
   "en": "Reason and conviction are threefold, according to the quality that is dominant. I will explain them fully and separately, O Arjuna!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 30,
   "sa": "प्रवृत्तिं च निवृत्तिं च कार्याकार्ये भयाभये।बन्धं मोक्षं च या वेत्ति बुद्धिः सा पार्थ सात्त्विकी।।18.30।।",
   "tr": "pravṛittiṁ cha nivṛittiṁ cha kāryākārye bhayābhaye\nbandhaṁ mokṣhaṁ cha yā vetti buddhiḥ sā pārtha sāttvikī",
   "hi": "हे पार्थ ! जो बुद्धि प्रवृत्ति और निवृत्ति, कार्य और अकार्य, भय और अभय तथा बन्ध और मोक्ष को तत्त्वत जानती है, वह बुद्धि सात्विकी है।।",
   "en": "That intellect which understands the creation and dissolution of life, what actions should be done and what not, which discriminates between fear and fearlessness, bondage and deliverance, is Pure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 31,
   "sa": "यया धर्ममधर्मं च कार्यं चाकार्यमेव च।अयथावत्प्रजानाति बुद्धिः सा पार्थ राजसी।।18.31।।",
   "tr": "yayā dharmam adharmaṁ cha kāryaṁ chākāryam eva cha\nayathāvat prajānāti buddhiḥ sā pārtha rājasī",
   "hi": "हे पार्थ ! जिस बुद्धि के द्वारा मनुष्य धर्म और अधर्म को तथा कर्तव्य और अकर्तव्य को यथावत् नहीं जानता है, वह बुद्धि राजसी है।।",
   "en": "The intellect that does not understand what is right and wrong, and what should be done and not done, is under the sway of Passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 32,
   "sa": "अधर्मं धर्ममिति या मन्यते तमसाऽऽवृता।सर्वार्थान्विपरीतांश्च बुद्धिः सा पार्थ तामसी।।18.32।।",
   "tr": "adharmaṁ dharmam iti yā manyate tamasāvṛitā\nsarvārthān viparītānśh cha buddhiḥ sā pārtha tāmasī",
   "hi": "हे पार्थ ! तमस् (अज्ञान अन्ध:कार) से आवृत जो बुद्धि अधर्म को ही धर्म मानती है और सभी पदार्थों को विपरीत रूप से जानती है, वह बुद्धि तामसी है।।",
   "en": "And that which, shrouded in Ignorance, thinks wrong to be right, and sees everything perversely, O Arjuna, that intellect is ruled by Darkness.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 33,
   "sa": "धृत्या यया धारयते मनःप्राणेन्द्रियक्रियाः।योगेनाव्यभिचारिण्या धृतिः सा पार्थ सात्त्विकी।।18.33।।",
   "tr": "dhṛityā yayā dhārayate manaḥ-prāṇendriya-kriyāḥ\nyogenāvyabhichāriṇyā dhṛitiḥ sā pārtha sāttvikī",
   "hi": "सात्त्विकी है।।",
   "en": "The conviction and steady concentration with which the mind, the energy, and the senses are controlled—O Arjuna!—are the result of purity.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 34,
   "sa": "यया तु धर्मकामार्थान् धृत्या धारयतेऽर्जुन।प्रसङ्गेन फलाकाङ्क्षी धृतिः सा पार्थ राजसी।।18.34।।",
   "tr": "yayā tu dharma-kāmārthān dhṛityā dhārayate ‘rjuna\nprasaṅgena phalākāṅkṣhī dhṛitiḥ sā pārtha rājasī",
   "hi": "हे पृथापुत्र अर्जुन ! कर्मफल का इच्छुक पुरुष अति आसक्ति (प्रसंग) से जिस धृति के द्वारा धर्म, अर्थ और काम (इन तीन पुरुषार्थों) को धारण करता है, वह धृति राजसी है।।",
   "en": "The conviction that always holds fast to rituals, self-interest, and wealth for the sake of what they may bring forth comes from passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 35,
   "sa": "यया स्वप्नं भयं शोकं विषादं मदमेव च।न विमुञ्चति दुर्मेधा धृतिः सा पार्थ तामसी।।18.35।।",
   "tr": "yayā svapnaṁ bhayaṁ śhokaṁ viṣhādaṁ madam eva cha\nna vimuñchati durmedhā dhṛitiḥ sā pārtha tāmasī",
   "hi": "हो पार्थ ! दुर्बुद्धि पुरुष जिस धारणा के द्वारा, स्वप्न, भय, शोक, विषाद और मद को नहीं त्यागता है, वह धृति तामसी है।।",
   "en": "And that which clings perversely to false idealism, fear, grief, despair, and vanity is the product of ignorance.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 36,
   "sa": "सुखं त्विदानीं त्रिविधं श्रृणु मे भरतर्षभ।अभ्यासाद्रमते यत्र दुःखान्तं च निगच्छति।।18.36।।",
   "tr": "sukhaṁ tv idānīṁ tri-vidhaṁ śhṛiṇu me bharatarṣhabha\nabhyāsād ramate yatra duḥkhāntaṁ cha nigachchhati\nyat tad agre viṣham iva pariṇāme ‘mṛitopamam\ntat sukhaṁ sāttvikaṁ proktam ātma-buddhi-prasāda-jam",
   "hi": "हे भरतश्रेष्ठ ! अब तुम त्रिविध सुख को मुझसे सुनो, जिसमें (साधक पुरुष) अभ्यास से रमता है और दु:खों के अन्त को प्राप्त होता है (जहाँ उसके दु:खों का अन्त हो जाता है।)।।",
   "en": "Hear further the three kinds of pleasure. That which increases day by day delivers one from misery.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 37,
   "sa": "यत्तदग्रे विषमिव परिणामेऽमृतोपमम्।तत्सुखं सात्त्विकं प्रोक्तमात्मबुद्धिप्रसादजम्।।18.37।।",
   "tr": "yat  tad agre    viṣam   iva pariṇāme    'mṛtopamam  tat sukhaṁ  sāttvikaṁ   proktam ātma-buddhi-prasāda-jam",
   "hi": "जो सुख प्रथम (प्रारम्भ में) विष के समान (भासता) है, परन्तु परिणाम में अमृत के समान है, वह आत्मबुद्धि के प्रसाद से उत्पन्न सुख सात्त्विक कहा गया है।।",
   "en": "Which at first seems like poison but afterwards acts like nectar—that pleasure is pure, for it is born of wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 38,
   "sa": "विषयेन्द्रियसंयोगाद्यत्तदग्रेऽमृतोपमम्।परिणामे विषमिव तत्सुखं राजसं स्मृतम्।।18.38।।",
   "tr": "viṣhayendriya-sanyogād yat tad agre ’mṛitopamam\npariṇāme viṣham iva tat sukhaṁ rājasaṁ smṛitam",
   "hi": "जो सुख विषयों और इन्द्रियों के संयोग से उत्पन्न होता है, वह प्रथम तो अमृत के समान, परन्तु परिणाम में विष तुल्य होता है, वह सुख राजस कहा गया है।।",
   "en": "That which, at first, is like nectar, as the senses revel in their objects, but in the end acts like poison—that pleasure arises from Passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 39,
   "sa": "यदग्रे चानुबन्धे च सुखं मोहनमात्मनः।निद्रालस्यप्रमादोत्थं तत्तामसमुदाहृतम्।।18.39।।",
   "tr": "yad agre chānubandhe cha sukhaṁ mohanam ātmanaḥ\nnidrālasya-pramādotthaṁ tat tāmasam udāhṛitam",
   "hi": "जो सुख प्रारम्भ में और परिणाम (अनुबन्ध) में भी आत्मा (मनुष्य) को मोहित करने वाला होता है, वह निद्रा, आलस्य और प्रमाद से उत्पन्न सुख तामस कहा जाता है।।",
   "en": "While the pleasure that drugs the senses from start to finish, which springs from indolence, lethargy, and folly—that pleasure flows from Ignorance.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 40,
   "sa": "न तदस्ति पृथिव्यां वा दिवि देवेषु वा पुनः।सत्त्वं प्रकृतिजैर्मुक्तं यदेभिः स्यात्ित्रभिर्गुणैः।।18.40।।",
   "tr": "na tad asti pṛithivyāṁ vā divi deveṣhu vā punaḥ\nsattvaṁ prakṛiti-jair muktaṁ yad ebhiḥ syāt tribhir guṇaiḥ",
   "hi": "पृथ्वी पर अथवा स्वर्ग के देवताओं में ऐसा कोई प्राणी (सत्त्वं अर्थात् विद्यमान वस्तु) नहीं है जो प्रकृति से उत्पन्न इन तीन गुणों से मुक्त (रहित) हो।।",
   "en": "There is nothing anywhere on earth or in the higher worlds that is free from the three Qualities, for they are born of Nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 41,
   "sa": "ब्राह्मणक्षत्रियविशां शूद्राणां च परंतप।कर्माणि प्रविभक्तानि स्वभावप्रभवैर्गुणैः।।18.41।।",
   "tr": "brāhmaṇa-kṣhatriya-viśhāṁ śhūdrāṇāṁ cha parantapa\nkarmāṇi pravibhaktāni svabhāva-prabhavair guṇaiḥ",
   "hi": "हे परन्तप! ब्राह्मणों, क्षत्रियों, वैश्यों और शूद्रों के कर्म, स्वभाव से उत्पन्न गुणों के अनुसार विभक्त किये गये हैं।।",
   "en": "O Arjuna! The duties of spiritual teachers, the soldiers, the traders, and the servants have all been fixed according to the dominant quality in their nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 42,
   "sa": "शमो दमस्तपः शौचं क्षान्तिरार्जवमेव च।ज्ञानं विज्ञानमास्तिक्यं ब्रह्मकर्म स्वभावजम्।।18.42।।",
   "tr": "śhamo damas tapaḥ śhauchaṁ kṣhāntir ārjavam eva cha\njñānaṁ vijñānam āstikyaṁ brahma-karma svabhāva-jam",
   "hi": "शम, दम, तप, शौच, क्षान्ति, आर्जव, ज्ञान, विज्ञान और आस्तिक्य - ये ब्राह्मण के स्वाभाविक कर्म हैं।।",
   "en": "Serenity, self-restraint, austerity, purity, forgiveness, uprightness, knowledge, wisdom, and faith in God—these constitute the duty of a spiritual teacher.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 43,
   "sa": "शौर्यं तेजो धृतिर्दाक्ष्यं युद्धे चाप्यपलायनम्।दानमीश्वरभावश्च क्षात्रं कर्म स्वभावजम्।।18.43।।",
   "tr": "śhauryaṁ tejo dhṛitir dākṣhyaṁ yuddhe chāpy apalāyanam\ndānam īśhvara-bhāvaśh cha kṣhātraṁ karma svabhāva-jam",
   "hi": "शौर्य, तेज, धृति, दाक्ष्य (दक्षता), युद्ध से पलायन न करना, दान और ईश्वर भाव (स्वामी भाव) - ये सब क्षत्रिय के स्वाभाविक कर्म हैं।।",
   "en": "Valor, glory, firmness, skill, generosity, steadiness in battle, and the ability to rule—these constitute the duty of a soldier. They flow from his own nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 44,
   "sa": "कृषिगौरक्ष्यवाणिज्यं वैश्यकर्म स्वभावजम्।परिचर्यात्मकं कर्म शूद्रस्यापि स्वभावजम्।।18.44।।",
   "tr": "kṛiṣhi-gau-rakṣhya-vāṇijyaṁ vaiśhya-karma svabhāva-jam\nparicharyātmakaṁ karma śhūdrasyāpi svabhāva-jam",
   "hi": "कृषि, गौपालन तथा वाणिज्य - ये वैश्य के स्वाभाविक कर्म हैं, और शूद्र का स्वाभाविक कर्म है परिचर्या अर्थात् सेवा करना।।",
   "en": "Agriculture, the protection of cows, and trade are the duties of a trader, in accordance with his nature. The duty of a servant is to serve, which also agrees with his nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 45,
   "sa": "स्वे स्वे कर्मण्यभिरतः संसिद्धिं लभते नरः।स्वकर्मनिरतः सिद्धिं यथा विन्दति तच्छृणु।।18.45।।",
   "tr": "sve sve karmaṇy abhirataḥ sansiddhiṁ labhate naraḥ\nsva-karma-nirataḥ siddhiṁ yathā vindati tach chhṛiṇu",
   "hi": "अपने-अपने स्वाभाविक कर्म में अभिरत मनुष्य संसिद्धि को प्राप्त कर लेता है। स्वकर्म में रत मनुष्य किस प्रकार सिद्धि प्राप्त करता है, उसे तुम सुनो।।",
   "en": "Perfection is attained when one diligently attends to their duty. Listen, and I will tell you how it is attained by one who always minds their own duty.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 46,
   "sa": "यतः प्रवृत्तिर्भूतानां येन सर्वमिदं ततम्।स्वकर्मणा तमभ्यर्च्य सिद्धिं विन्दति मानवः।।18.46।।",
   "tr": "yataḥ pravṛittir bhūtānāṁ yena sarvam idaṁ tatam\nsva-karmaṇā tam abhyarchya siddhiṁ vindati mānavaḥ",
   "hi": "जिस (परमात्मा) से भूतमात्र की प्रवृत्ति अर्थात् उत्पत्ति हुई है और जिससे यह सम्पूर्ण जगत् व्याप्त है, उस (परमात्मा) की स्वकर्म द्वारा पूजा करके मनुष्य सिद्धि को प्राप्त होता है।।",
   "en": "One reaches perfection by dedicating their actions to God, Who is the source of all being and fills everything.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 47,
   "sa": "श्रेयान्स्वधर्मो विगुणः परधर्मात्स्वनुष्ठितात्।स्वभावनियतं कर्म कुर्वन्नाप्नोति किल्बिषम्।।18.47।।",
   "tr": "śhreyān swa-dharmo viguṇaḥ para-dharmāt sv-anuṣhṭhitāt\nsvabhāva-niyataṁ karma kurvan nāpnoti kilbiṣham",
   "hi": "सम्यक् अनुष्ठित परधर्म की अपेक्षा गुणरहित स्वधर्म श्रेष्ठ है। (क्योंकि) स्वभाव से नियत किये गये कर्म को करते हुए मनुष्य पाप को नहीं प्राप्त करता।।",
   "en": "It is better to do one's own duty, however defective it may be, than to follow the duty of another, however well one may perform it. He who does his duty as his own nature reveals it, never commits a sin.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 48,
   "sa": "सहजं कर्म कौन्तेय सदोषमपि न त्यजेत्।सर्वारम्भा हि दोषेण धूमेनाग्निरिवावृताः।।18.48।।",
   "tr": "saha-jaṁ karma kaunteya sa-doṣham api na tyajet\nsarvārambhā hi doṣheṇa dhūmenāgnir ivāvṛitāḥ",
   "hi": "हे कौन्तेय ! दोषयुक्त होने पर भी सहज कर्म को नहीं त्यागना चाहिए; क्योंकि सभी कर्म दोष से आवृत होते है, जैसे धुयें से अग्नि।।",
   "en": "The duty that falls to one's lot of its own accord should not be abandoned, though it may have its defects. All acts are marred by defects, just as fire is obscured by smoke.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 49,
   "sa": "असक्तबुद्धिः सर्वत्र जितात्मा विगतस्पृहः।नैष्कर्म्यसिद्धिं परमां संन्यासेनाधिगच्छति।।18.49।।",
   "tr": "asakta-buddhiḥ sarvatra jitātmā vigata-spṛihaḥ\nnaiṣhkarmya-siddhiṁ paramāṁ sannyāsenādhigachchhati",
   "hi": "सर्वत्र आसक्ति रहित बुद्धि वाला वह पुरुष जो स्पृहारहित तथा जितात्मा है, संन्यास के द्वारा परम नैर्ष्कम्य सिद्धि को प्राप्त होता है।।",
   "en": "He whose mind is entirely detached, who has conquered himself, and whose desires have vanished, reaches that stage of perfect freedom through his renunciation, where action completes itself and leaves no seed.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 50,
   "sa": "सिद्धिं प्राप्तो यथा ब्रह्म तथाप्नोति निबोध मे।समासेनैव कौन्तेय निष्ठा ज्ञानस्य या परा।।18.50।।",
   "tr": "siddhiṁ prāpto yathā brahma tathāpnoti nibodha me\nsamāsenaiva kaunteya niṣhṭhā jñānasya yā parā",
   "hi": "सिद्धि को प्राप्त पुरुष किस प्रकार ब्रह्म को प्राप्त होता है, तथा ज्ञान की परा निष्ठा को भी तुम मुझसे संक्षेप में जानो।।",
   "en": "I will now state briefly how one who has reached perfection finds the Eternal Spirit, the state of Supreme Wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 51,
   "sa": "बुद्ध्या विशुद्धया युक्तो धृत्याऽऽत्मानं नियम्य च।शब्दादीन् विषयांस्त्यक्त्वा रागद्वेषौ व्युदस्य च।।18.51।।",
   "tr": "buddhyā viśhuddhayā yukto dhṛityātmānaṁ niyamya cha\nśhabdādīn viṣhayāns tyaktvā rāga-dveṣhau vyudasya cha",
   "hi": "विशुद्ध बुद्धि से युक्त, धृति से आत्मसंयम कर, शब्दादि विषयों को त्याग कर और राग-द्वेष का परित्याग कर....৷৷৷৷।।",
   "en": "Guided always by pure reason, bravely restraining himself, renouncing the objects of sense and giving up attachment and hatred; he attains peace.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 52,
   "sa": "विविक्तसेवी लघ्वाशी यतवाक्कायमानसः।ध्यानयोगपरो नित्यं वैराग्यं समुपाश्रितः।।18.52।।",
   "tr": "vivikta-sevī laghv-āśhī yata-vāk-kāya-mānasaḥ\ndhyāna-yoga-paro nityaṁ vairāgyaṁ samupāśhritaḥ",
   "hi": "विविक्त सेवी, लघ्वाशी (मिताहारी) जिसने अपने शरीर, वाणी और मन को संयत किया है, ध्यानयोग के अभ्यास में सदैव तत्पर तथा वैराग्य पर समाश्रित।।",
   "en": "Enjoying solitude, being abstemious, having his body, mind, and speech under perfect control, and being absorbed in meditation, he becomes free—always filled with the spirit of renunciation.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 53,
   "sa": "अहङ्कारं बलं दर्पं कामं क्रोधं परिग्रहम्।विमुच्य निर्ममः शान्तो ब्रह्मभूयाय कल्पते।।18.53।।",
   "tr": "ahankāraṁ balaṁ darpaṁ kāmaṁ krodhaṁ parigraham\nvimuchya nirmamaḥ śhānto brahma-bhūyāya kalpate",
   "hi": "अहंकार, बल, दर्प, काम, क्रोध और परिग्रह को त्याग कर ममत्वभाव से रहित और शान्त पुरुष ब्रह्म प्राप्ति के योग्य बन जाता है।।",
   "en": "Having abandoned selfishness, power, arrogance, anger, and desire, possessing nothing of his own, and having attained peace, he is fit to join the Eternal Spirit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 54,
   "sa": "ब्रह्मभूतः प्रसन्नात्मा न शोचति न काङ्क्षति।समः सर्वेषु भूतेषु मद्भक्तिं लभते पराम्।।18.54।।",
   "tr": "brahma-bhūtaḥ prasannātmā na śhochati na kāṅkṣhati\nsamaḥ sarveṣhu bhūteṣhu mad-bhaktiṁ labhate parām",
   "hi": "ब्रह्मभूत (जो साधक ब्रह्म बन गया है), प्रसन्न मन वाला पुरुष न इच्छा करता है और न शोक, समस्त भूतों के प्रति सम होकर वह मेरी परा भक्ति को प्राप्त करता है।।",
   "en": "When he unites with the Eternal and his soul knows the bliss of the Self, he feels no desire or regret, he regards all beings equally, and enjoys the blessing of supreme devotion to Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 55,
   "sa": "भक्त्या मामभिजानाति यावान्यश्चास्मि तत्त्वतः।ततो मां तत्त्वतो ज्ञात्वा विशते तदनन्तरम्।।18.55।।",
   "tr": "bhaktyā mām abhijānāti yāvān yaśh chāsmi tattvataḥ\ntato māṁ tattvato jñātvā viśhate tad-anantaram",
   "hi": "(उस परा) भक्ति के द्वारा मुझे वह तत्त्वत: जानता है कि मैं कितना (व्यापक) हूँ तथा मैं क्या हूँ। (इस प्रकार) तत्त्वत: जानने के पश्चात् तत्काल ही वह मुझमें प्रवेश कर जाता है, अर्थात् मत्स्वरूप बन जाता है।।",
   "en": "By such devotion, he sees Me, who I am and what I am; and thus realizing the truth, he enters into My kingdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 56,
   "sa": "सर्वकर्माण्यपि सदा कुर्वाणो मद्व्यपाश्रयः।मत्प्रसादादवाप्नोति शाश्वतं पदमव्ययम्।।18.56।।",
   "tr": "sarva-karmāṇy api sadā kurvāṇo mad-vyapāśhrayaḥ\nmat-prasādād avāpnoti śhāśhvataṁ padam avyayam",
   "hi": "जो पुरुष मदाश्रित होकर सदैव समस्त कर्मों को करता है, वह मेरे प्रसाद (अनुग्रह) से शाश्वत, अव्यय पद को प्राप्त कर लेता है।।",
   "en": "Relying on Me in all his actions and doing them for My sake, he attains, by My grace, eternal and unchangeable life.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 57,
   "sa": "चेतसा सर्वकर्माणि मयि संन्यस्य मत्परः।बुद्धियोगमुपाश्रित्य मच्चित्तः सततं भव।।18.57।।",
   "tr": "chetasā sarva-karmāṇi mayi sannyasya mat-paraḥ\nbuddhi-yogam upāśhritya mach-chittaḥ satataṁ bhava",
   "hi": "मन से समस्त कर्मों का संन्यास मुझमें करके मत्परायण होकर बुद्धियोग का आश्रय लेकर तुम सतत मच्चित्त बनो।।",
   "en": "Surrender your actions to Me, live in Me, focus your intellect on Me, and always think of Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 58,
   "sa": "मच्चित्तः सर्वदुर्गाणि मत्प्रसादात्तरिष्यसि।अथ चेत्त्वमहङ्कारान्न श्रोष्यसि विनङ्क्ष्यसि।।18.58।।",
   "tr": "mach-chittaḥ sarva-durgāṇi mat-prasādāt tariṣhyasi\natha chet tvam ahankārān na śhroṣhyasi vinaṅkṣhyasi",
   "hi": "मच्चित्त होकर तुम मेरी कृपा से समस्त कठिनाइयों (सर्वदुर्गाणि) को पार कर जाओगे; और यदि अहंकारवश (इस उपदेश को) नहीं सुनोगे, तो तुम नष्ट हो जाओगे।।",
   "en": "Fix your mind on Me, and by My grace you will overcome the obstacles in your path. But if, misled by pride, you do not listen, then you will indeed be lost.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 59,
   "sa": "यदहङ्कारमाश्रित्य न योत्स्य इति मन्यसे।मिथ्यैष व्यवसायस्ते प्रकृतिस्त्वां नियोक्ष्यति।।18.59।।",
   "tr": "yad ahankāram āśhritya na yotsya iti manyase\nmithyaiṣha vyavasāyas te prakṛitis tvāṁ niyokṣhyati",
   "hi": "और अहंकारवश तुम जो यह सोच रहे हो, \"मैं युद्ध नहीं करूंगा\", यह तुम्हारा निश्चय मिथ्या है, (क्योंकि) प्रकृति (तुम्हारा स्वभाव) ही तुम्हें (बलात् कर्म में) प्रवृत्त करेगी।।",
   "en": "If you in your vanity think of avoiding this fight, your will shall not be fulfilled, for Nature herself will compel you.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 60,
   "sa": "स्वभावजेन कौन्तेय निबद्धः स्वेन कर्मणा।कर्तुं नेच्छसि यन्मोहात्करिष्यस्यवशोऽपि तत्।।18.60।।",
   "tr": "swbhāva-jena kaunteya nibaddhaḥ svena karmaṇā\nkartuṁ nechchhasi yan mohāt kariṣhyasy avaśho ’pi tat",
   "hi": "हे कौन्तेय ! तुम अपने स्वाभाविक कर्मों से बंधे हो, (अत:) मोहवशात् जिस कर्म को तुम करना नहीं चाहते हो, वही तुम विवश होकर करोगे।।",
   "en": "O Arjuna! Your duty binds you. It has arisen from your own nature, and that which you do not desire to do in your delusion, you will do that very thing. You are helpless.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 61,
   "sa": "ईश्वरः सर्वभूतानां हृद्देशेऽर्जुन तिष्ठति।भ्रामयन्सर्वभूतानि यन्त्रारूढानि मायया।।18.61।।",
   "tr": "īśhvaraḥ sarva-bhūtānāṁ hṛid-deśhe ‘rjuna tiṣhṭhati\nbhrāmayan sarva-bhūtāni yantrārūḍhāni māyayā",
   "hi": "हे अर्जुन (मानों किसी) यन्त्र पर आरूढ़ समस्त भूतों को ईश्वर अपनी माया से घुमाता हुआ (भ्रामयन्) भूतमात्र के हृदय में स्थित रहता है।।",
   "en": "God dwells in the hearts of all beings, O Arjuna! He causes them to revolve, as it were, on a wheel, by His mystic power.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 62,
   "sa": "तमेव शरणं गच्छ सर्वभावेन भारत।तत्प्रसादात्परां शान्तिं स्थानं प्राप्स्यसि शाश्वतम्।।18.62।।",
   "tr": "tam eva śharaṇaṁ gachchha sarva-bhāvena bhārata\ntat-prasādāt parāṁ śhāntiṁ sthānaṁ prāpsyasi śhāśhvatam",
   "hi": "हे भारत ! तुम सम्पूर्ण भाव से उसी (ईश्वर) की शरण में जाओ। उसके प्रसाद से तुम परम शान्ति और शाश्वत स्थान को प्राप्त करोगे।।",
   "en": "With all your strength, fly to Him and surrender yourself, and by His grace you will attain Supreme Peace and reach the Eternal Home.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 63,
   "sa": "इति ते ज्ञानमाख्यातं गुह्याद्गुह्यतरं मया।विमृश्यैतदशेषेण यथेच्छसि तथा कुरु।।18.63।।",
   "tr": "iti te jñānam ākhyātaṁ guhyād guhyataraṁ mayā\nvimṛiśhyaitad aśheṣheṇa yathechchhasi tathā kuru",
   "hi": "इस प्रकार समस्त गोपनीयों से अधिक गुह्य ज्ञान मैंने तुमसे कहा; इस पर पूर्ण विचार (विमृश्य) करने के पश्चात् तुम्हारी जैसी इच्छा हो, वैसा तुम करो।।",
   "en": "Thus, I have revealed to you the truth, the mystery of mysteries. Having thought it over, you are free to act as you wish.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 64,
   "sa": "सर्वगुह्यतमं भूयः श्रृणु मे परमं वचः।इष्टोऽसि मे दृढमिति ततो वक्ष्यामि ते हितम्।।18.64।।",
   "tr": "sarva-guhyatamaṁ bhūyaḥ śhṛiṇu me paramaṁ vachaḥ\niṣhṭo ‘si me dṛiḍham iti tato vakṣhyāmi te hitam",
   "hi": "पुन: एक बार तुम मुझसे समस्त गुह्यों में गुह्यतम परम वचन (उपदेश) को सुनो। तुम मुझे अतिशय प्रिय हो, इसलिए मैं तुम्हें तुम्हारे हित की बात कहूंगा।।",
   "en": "Listen to My last word once more, the deepest secret of all; you are My beloved, you are My friend, and I speak for your welfare.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 65,
   "sa": "मन्मना भव मद्भक्तो मद्याजी मां नमस्कुरु।मामेवैष्यसि सत्यं ते प्रतिजाने प्रियोऽसि मे।।18.65।।",
   "tr": "man-manā bhava mad-bhakto mad-yājī māṁ namaskuru\nmām evaiṣhyasi satyaṁ te pratijāne priyo ‘si me",
   "hi": "तुम मच्चित, मद्भक्त और मेरे पूजक (मद्याजी) बनो और मुझे नमस्कार करो; (इस प्रकार) तुम मुझे ही प्राप्त होगे; यह मैं तुम्हे सत्य वचन देता हूँ,(क्योंकि) तुम मेरे प्रिय हो।।",
   "en": "Dedicate yourself to Me, worship Me, sacrifice all for Me, prostrate yourself before Me, and you will surely come to Me. I truly pledge to you; you are My beloved.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 66,
   "sa": "सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज।अहं त्वा सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः।।18.66।।",
   "tr": "sarva-dharmān parityajya mām ekaṁ śharaṇaṁ vraja\nahaṁ tvāṁ sarva-pāpebhyo mokṣhayiṣhyāmi mā śhuchaḥ",
   "hi": "सब धर्मों का परित्याग करके तुम एक मेरी ही शरण में आओ, मैं तुम्हें समस्त पापों से मुक्त कर दूँगा, तुम शोक मत करो।।",
   "en": "Give up your earthly duties, surrender yourself to Me alone. Do not be anxious; I will absolve you from all your sins.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 67,
   "sa": "इदं ते नातपस्काय नाभक्ताय कदाचन।न चाशुश्रूषवे वाच्यं न च मां योऽभ्यसूयति।।18.67।।",
   "tr": "idaṁ te nātapaskyāya nābhaktāya kadāchana\nna chāśhuśhruṣhave vāchyaṁ na cha māṁ yo ‘bhyasūtayi",
   "hi": "यह ज्ञान ऐसे पुरुष से नहीं कहना चाहिए, जो अतपस्क (तपरहित) है, और न उसे जो अभक्त है; उसे भी नहीं जो अशुश्रुषु (सेवा में अतत्पर) है और उस पुरुष से भी नहीं कहना चाहिए, जो मुझ (ईश्वर) से असूया करता है, अर्थात् मुझ में दोष देखता है।।",
   "en": "Do not speak this to one who has not practiced austerities, or to one who does not love, or who will not listen, or who mocks.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 68,
   "sa": "य इमं परमं गुह्यं मद्भक्तेष्वभिधास्यति।भक्ितं मयि परां कृत्वा मामेवैष्यत्यसंशयः।।18.68।।",
   "tr": "ya idaṁ paramaṁ guhyaṁ mad-bhakteṣhv abhidhāsyati\nbhaktiṁ mayi parāṁ kṛitvā mām evaiṣhyaty asanśhayaḥ",
   "hi": "जो पुरुष मुझसे परम प्रेम (परा भक्ति) करके इस परम गुह्य ज्ञान का उपदेश मेरे भक्तों को देता है, वह नि:सन्देह मुझे ही प्राप्त होता है।।",
   "en": "But he who teaches this great secret to My devotees, his is the highest devotion, and he shall surely come to Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 69,
   "sa": "न च तस्मान्मनुष्येषु कश्िचन्मे प्रियकृत्तमः।भविता न च मे तस्मादन्यः प्रियतरो भुवि।।18.69।।",
   "tr": "na cha tasmān manuṣhyeṣhu kaśhchin me priya-kṛittamaḥ\nbhavitā na cha me tasmād anyaḥ priyataro bhuvi",
   "hi": "न तो उससे बढ़कर मेरा अतिशय प्रिय कार्य करने वाला मनुष्यों में कोई है और न उससे बढ़कर मेरा प्रिय इस पृथ्वी पर दूसरा कोई होगा।।",
   "en": "There is no one among men who can perform a service dearer to Me than this, nor is there any man on earth more beloved by Me than him.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 70,
   "sa": "अध्येष्यते च य इमं धर्म्यं संवादमावयोः।ज्ञानयज्ञेन तेनाहमिष्टः स्यामिति मे मतिः।।18.70।।",
   "tr": "adhyeṣhyate cha ya imaṁ dharmyaṁ saṁvādam āvayoḥ\njñāna-yajñena tenāham iṣhṭaḥ syām iti me matiḥ",
   "hi": "जो पुरुष, हम दोनों के इस धर्ममय संवाद का पठन करेगा, उसके द्वारा मैं ज्ञानयज्ञ से पूजित होऊँगा - ऐसा मेरा मत है।।",
   "en": "He who will study this spiritual discourse of ours, I assure you, they shall thereby worship Me at the altar of Wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 71,
   "sa": "श्रद्धावाननसूयश्च श्रृणुयादपि यो नरः।सोऽपि मुक्तः शुभाँल्लोकान्प्राप्नुयात्पुण्यकर्मणाम्।।18.71।।",
   "tr": "śhraddhāvān anasūyaśh cha śhṛiṇuyād api yo naraḥ\nso ‘pi muktaḥ śhubhāl lokān prāpnuyāt puṇya-karmaṇām",
   "hi": "तथा जो श्रद्धावान् और अनसुयु (दोषदृष्टि रहित) पुरुष इसका श्रवणमात्र भी करेगा, वह भी (पापों से) मुक्त होकर पुण्यकर्मियों के शुभ (श्रेष्ठ) लोकों को प्राप्त कर लेगा।।",
   "en": "Yes, he who listens to it with faith and without doubt, even he, freed from evil, will rise to the worlds which the virtuous attain through righteous deeds.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 72,
   "sa": "कच्चिदेतच्छ्रुतं पार्थ त्वयैकाग्रेण चेतसा।कच्चिदज्ञानसंमोहः प्रनष्टस्ते धनञ्जय।।18.72।।",
   "tr": "kachchid etach chhrutaṁ pārtha tvayaikāgreṇa chetasā\nkachchid ajñāna-sammohaḥ pranaṣhṭas te dhanañjaya",
   "hi": "हे पार्थ ! क्या इसे (मेरे उपदेश को) तुमने एकाग्रचित्त होकर श्रवण किया ? और हे धनञ्जय ! क्या तुम्हारा अज्ञान जनित संमोह पूर्णतया नष्ट हुआ ?",
   "en": "O Arjuna, have you listened attentively to My words? Has your ignorance and delusion gone?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 73,
   "sa": "अर्जुन उवाचनष्टो मोहः स्मृतिर्लब्धा त्वत्प्रसादान्मयाच्युत।स्थितोऽस्मि गतसन्देहः करिष्ये वचनं तव।।18.73।।",
   "tr": "arjuna uvācha\nnaṣhṭo mohaḥ smṛitir labdhā tvat-prasādān mayāchyuta\nsthito ‘smi gata-sandehaḥ kariṣhye vachanaṁ tava",
   "hi": "अर्जुन ने कहा -- हे अच्युत ! आपके कृपाप्रसाद से मेरा मोह नष्ट हो गया है, और मुझे स्मृति (ज्ञान) प्राप्त हो गयी है? अब मैं संशयरहित हो गया हूँ और मैं आपके वचन (आज्ञा) का पालन करूँगा।।",
   "en": "Arjuna replied: \"My Lord! O Immutable One! My delusion has fled. By Your Grace, O Changeless One, the light has dawned. My doubts have been dispelled, and I stand before You ready to do Your will.\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 74,
   "sa": "सञ्जय उवाचइत्यहं वासुदेवस्य पार्थस्य च महात्मनः।संवादमिममश्रौषमद्भुतं रोमहर्षणम्।।18.74।।",
   "tr": "sañjaya uvācha\nity ahaṁ vāsudevasya pārthasya cha mahātmanaḥ\nsaṁvādam imam aśhrauṣham adbhutaṁ roma-harṣhaṇam",
   "hi": "संजय ने कहा -- इस प्रकार मैंने भगवान् वासुदेव और महात्मा अर्जुन के इस अद्भुत और रोमान्चक संवाद का वर्णन किया।।",
   "en": "Sanjaya said: \"I heard this rare, wonderful, and soul-stirring discourse between Lord Shri Krishna and the great-souled Arjuna.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 75,
   "sa": "व्यासप्रसादाच्छ्रुतवानेतद्गुह्यमहं परम्।योगं योगेश्वरात्कृष्णात्साक्षात्कथयतः स्वयम्।।18.75।।",
   "tr": "vyāsa-prasādāch chhrutavān etad guhyam ahaṁ param\nyogaṁ yogeśhvarāt kṛiṣhṇāt sākṣhāt kathayataḥ svayam",
   "hi": "व्यास जी की कृपा से मैंने इस परम् गुह्य योग को साक्षात् कहते हुए स्वयं योगोश्वर श्रीकृष्ण भगवान् से सुना।।",
   "en": "Through the blessing of the sage Vyasa, I heard this secret and noble science from the lips of its Master, Lord Shri Krishna.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 76,
   "sa": "राजन्संस्मृत्य संस्मृत्य संवादमिममद्भुतम्।केशवार्जुनयोः पुण्यं हृष्यामि च मुहुर्मुहुः।।18.76।।",
   "tr": "rājan sansmṛitya sansmṛitya saṁvādam imam adbhutam\nkeśhavārjunayoḥ puṇyaṁ hṛiṣhyāmi cha muhur muhuḥ",
   "hi": "हे राजन् ! भगवान् केशव और अर्जुन के इस अद्भुत और पुण्य (पवित्र) संवाद को स्मरण करके मैं बारम्बार हर्षित होता हूँ।।",
   "en": "O King! The more I think of that marvelous and holy discourse, the more I lose myself in joy.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 77,
   "sa": "तच्च संस्मृत्य संस्मृत्य रूपमत्यद्भुतं हरेः।\nविस्मयो मे महान् राजन् हृष्यामि च पुनः पुनः।।18.77।।",
   "tr": "tach cha sansmṛitya saṁsmṛitya rūpam aty-adbhutaṁ hareḥ\nvismayo ye mahān rājan hṛiṣhyāmi cha punaḥ punaḥ",
   "hi": "हे राजन ! श्री हरि के अति अद्भुत रूप को भी पुन: पुन: स्मरण करके मुझे महान् विस्मय होता है और मैं बारम्बार हर्षित हो रहा हूँ।।",
   "en": "As I recall again and again the exceeding beauty of the Lord, I am filled with amazement and joy.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 78,
   "sa": "यत्र योगेश्वरः कृष्णो यत्र पार्थो धनुर्धरः।\nतत्र श्रीर्विजयो भूतिर्ध्रुवा नीतिर्मतिर्मम।।18.78।",
   "tr": "yatra yogeśhvaraḥ kṛiṣhṇo yatra pārtho dhanur-dharaḥ\ntatra śhrīr vijayo bhūtir dhruvā nītir matir mama",
   "hi": "जहाँ योगेश्वर श्रीकृष्ण हैं और जहाँ धनुर्धारी अर्जुन है वहीं पर श्री, विजय, विभूति और ध्रुव नीति है, ऐसा मेरा मत है।।",
   "en": "Wherever Lord Shri Krishna, the Prince of Wisdom, and Arjuna, the Great Archer, are, I am certain that good fortune, victory, happiness, and righteousness will follow.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
