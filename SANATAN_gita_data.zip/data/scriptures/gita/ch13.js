// Bhagavad Gita adhyay 13 - Ksetra Ksetrajna Vibhaaga Yoga (35 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch13"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 13,
 "title": "क्षेत्र-क्षेत्रज्ञविभागयोग",
 "illustration": "",
 "illustrationCaption": "Yoga through Distinguishing the Field and the Knower of the Field",
 "imageQuery": "Kurukshetra",
 "summaryHi": "भगवद गीता का तेरवाह अध्याय क्षेत्र-क्षेत्रज्ञविभागयोग है। क्षेत्र शब्द का मतलब भूमि और क्षेत्ररक्षण का मतलब क्षेत्र का जानकार है। हमारा भौतिक शरीर क्षेत्र के सामान है और हमारी अमर आत्मा क्षेत्र के जानकार के सामान है। इस अध्याय में, कृष्ण भौतिक शरीर और अमर आत्मा के बीच भेद करते हैं। वह बताते हैं कि भौतिक शरीर अस्थायी और विनाशकारी है जबकि आत्मा स्थायी और शाश्वत है। भौतिक शरीर नष्ट हो सकता है लेकिन आत्मा कभी भी नष्ट नहीं हो सकती। यह अध्याय फिर भगवान का वर्णन करता है, जो की सर्वोच्च आत्मा हैं। सभी व्यक्तिगत आत्माएं सर्वोच्च आत्मा से उत्पन्न हुई हैं। जो स्पष्ट रूप से शरीर, आत्मा और सर्वोच्च आत्मा के बीच अंतर को समझ लेता है वह परमात्मा को प्राप्त कर लेता है।        ",
 "summaryEn": "The thirteenth chapter of the Bhagavad Gita is \"Ksetra Ksetrajna Vibhaaga Yoga\". The word \"kshetra\" means \"the field\", and the \"kshetrajna\" means \"the knower of the field\". We can think of our material body as the field and our immortal soul as the knower of the field. In this chapter, Krishna discriminates between the physical body and the immortal soul. He explains that the physical body is temporary and perishable whereas the soul is permanent and eternal. The physical body can be destroyed but the soul can never be destroyed. The chapter then describes God, who is the Supreme Soul. All the individual souls have originated from the Supreme Soul. One who clearly understands the difference between the body, the Soul and the Supreme Soul attains the realization of Brahman.",
 "verses": [
  {
   "n": 1,
   "sa": "अर्जुन उवाच\nप्रकृतिं पुरुषं चैव क्षेत्रं क्षेत्रज्ञमेव च।\nएतद्वेदितुमिच्छामि ज्ञानं ज्ञेयं च केशव।।13.1।।",
   "tr": "arjuna uvācha\nprakṛitiṁ puruṣhaṁ chaiva kṣhetraṁ kṣhetra-jñam eva cha\netad veditum ichchhāmi jñānaṁ jñeyaṁ cha keśhava",
   "hi": "अर्जुन ने कहा -- हे केशव ! मैं, प्रकृति और पुरुष, क्षेत्र और क्षेत्रज्ञ तथा ज्ञान और ज्ञेय को जानना चाहता हूँ।।",
   "en": "Arjuna asked, \"My Lord, who is God, what is Nature, what is Matter, and what is the Self? What is Wisdom, and what is worth knowing? I wish to have this explained.\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "श्री भगवानुवाचइदं शरीरं कौन्तेय क्षेत्रमित्यभिधीयते।एतद्यो वेत्ति तं प्राहुः क्षेत्रज्ञ इति तद्विदः।।13.2।।",
   "tr": "śhrī-bhagavān uvācha\nidaṁ śharīraṁ kaunteya kṣhetram ity abhidhīyate\netad yo vetti taṁ prāhuḥ kṣhetra-jña iti tad-vidaḥ",
   "hi": "श्रीभगवान् ने कहा -- हे कौन्तेय ! यह शरीर क्षेत्र कहा जाता है और इसको जो जानता है, उसे तत्त्वज्ञ जन, क्षेत्रज्ञ कहते हैं।।",
   "en": "Lord Shri Krishna replied: O Arjuna! The body of a person is the playground of the Self; and That which knows the activities of Matter, sages call the Self.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "क्षेत्रज्ञं चापि मां विद्धि सर्वक्षेत्रेषु भारत।\nक्षेत्रक्षेत्रज्ञयोर्ज्ञानं यत्तज्ज्ञानं मतं मम।।13.3।।",
   "tr": "kṣhetra-jñaṁ chāpi māṁ viddhi sarva-kṣhetreṣhu bhārata\nkṣhetra-kṣhetrajñayor jñānaṁ yat taj jñānaṁ mataṁ mama",
   "hi": "हे भारत ! तुम समस्त क्षेत्रों में क्षेत्रज्ञ मुझे ही जानो। क्षेत्र और क्षेत्रज्ञ का जो ज्ञान है, वही (वास्तव में) ज्ञान है , ऐसा मेरा मत है।।",
   "en": "I am the omniscient Self that abides in the realm of matter; knowledge of matter and of the all-knowing Self is wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "तत्क्षेत्रं यच्च यादृक् च यद्विकारि यतश्च यत्।स च यो यत्प्रभावश्च तत्समासेन मे श्रृणु।।13.4।।",
   "tr": "tat kṣhetraṁ yach cha yādṛik cha yad-vikāri yataśh cha yat\nsa cha yo yat-prabhāvaśh cha tat samāsena me śhṛiṇu",
   "hi": "इसलिये, वह क्षेत्र जो है और जैसा है तथा जिन विकारों वाला है, और जिस (कारण) से जो (कार्य) हुआ है तथा वह (क्षेत्रज्ञ) भी जो है और जिस प्रभाव वाला है, वह संक्षेप में मुझसे सुनो।।",
   "en": "What is called Matter, of what it is composed, whence it came, and why it changes, what the Self is, and what its power - this I will now briefly set forth.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "ऋषिभिर्बहुधा गीतं छन्दोभिर्विविधैः पृथक्।ब्रह्मसूत्रपदैश्चैव हेतुमद्भिर्विनिश्िचतैः।।13.5।।",
   "tr": "ṛiṣhibhir bahudhā gītaṁ chhandobhir vividhaiḥ pṛithak\nbrahma-sūtra-padaiśh chaiva hetumadbhir viniśhchitaiḥ",
   "hi": "(क्षेत्र-क्षेत्रज्ञ के विषय में) ऋषियों द्वारा विभिन्न और विविध छन्दों में बहुत प्रकार से गाया गया है, तथा सम्यक् प्रकार से निश्चित किये हुये युक्तियुक्त ब्रह्मसूत्र के पदों द्वारा (अर्थात् ब्रह्म के सूचक शब्दों द्वारा) भी (वैसे ही कहा गया है)।।",
   "en": "Seers have sung of it in various ways, in many hymns and sacred Vedic songs, weighty in thought and convincing in their arguments.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "महाभूतान्यहङ्कारो बुद्धिरव्यक्तमेव च।इन्द्रियाणि दशैकं च पञ्च चेन्द्रियगोचराः।।13.6।।",
   "tr": "mahā-bhūtāny ahankāro buddhir avyaktam eva cha\nindriyāṇi daśhaikaṁ cha pañcha chendriya-gocharāḥ",
   "hi": "पंच महाभूत, अहंकार, बुद्धि, अव्यक्त (प्रकृति), दस इन्द्रियाँ, एक मन, इन्द्रियों के पाँच विषय।।",
   "en": "The five great fundamentals—earth, fire, air, water, and ether—personality, intellect, the mysterious life force, the ten organs of perception and action, the mind, and the five domains of sensation—",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "इच्छा द्वेषः सुखं दुःखं सङ्घातश्चेतनाधृतिः।एतत्क्षेत्रं समासेन सविकारमुदाहृतम्।।13.7।।",
   "tr": "ichchhā dveṣhaḥ sukhaṁ duḥkhaṁ saṅghātaśh chetanā dhṛitiḥ\netat kṣhetraṁ samāsena sa-vikāram udāhṛitam",
   "hi": "इच्छा, द्वेष, सुख, दुख, संघात (स्थूलदेह), चेतना (अन्त:करण की चेतन वृत्ति) तथा धृति - इस प्रकार यह क्षेत्र विकारों के सहित संक्षेप में कहा गया है।।",
   "en": "Desire, aversion, pleasure, pain, sympathy, vitality, and the persistent clinging to life—these are, in brief, the constituents of changing matter.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "अमानित्वमदम्भित्वमहिंसा क्षान्तिरार्जवम्।आचार्योपासनं शौचं स्थैर्यमात्मविनिग्रहः।।13.8।।",
   "tr": "amānitvam adambhitvam ahinsā kṣhāntir ārjavam\nāchāryopāsanaṁ śhauchaṁ sthairyam ātma-vinigrahaḥ",
   "hi": "अमानित्व, अदम्भित्व, अहिंसा, क्षमा, आर्जव, आचार्य की सेवा, शुद्धि, स्थिरता और आत्मसंयम।।",
   "en": "Humility, sincerity, harmlessness, forgiveness, rectitude, service to the Master, purity, steadfastness, and self-control;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "इन्द्रियार्थेषु वैराग्यमनहङ्कार एव च।जन्ममृत्युजराव्याधिदुःखदोषानुदर्शनम्।।13.9।।",
   "tr": "indriyārtheṣhu vairāgyam anahankāra eva cha\njanma-mṛityu-jarā-vyādhi-duḥkha-doṣhānudarśhanam",
   "hi": "इन्द्रियों के विषय के प्रति वैराग्य, अहंकार का अभाव, जन्म, मृत्यु, वृद्धवस्था, व्याधि और दुख में दोष दर्शन...৷৷.।।",
   "en": "Renouncing the delights of the senses, being without pride, having a right understanding of the painful problem of birth and death, and of age and sickness;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "असक्ितरनभिष्वङ्गः पुत्रदारगृहादिषु।नित्यं च समचित्तत्वमिष्टानिष्टोपपत्तिषु।।13.10।।",
   "tr": "asaktir anabhiṣhvaṅgaḥ putra-dāra-gṛihādiṣhu\nnityaṁ cha sama-chittatvam iṣhṭāniṣhṭopapattiṣhu",
   "hi": "आसक्ति तथा पुत्र, पत्नी, गृह आदि में अनभिष्वङ्ग (तादात्म्य का अभाव); और इष्ट और अनिष्ट की प्राप्ति में समचित्तता।।",
   "en": "Indifference, non-attachment to sex, progeny, or home, equanimity in both good fortune and bad;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "मयि चानन्ययोगेन भक्ितरव्यभिचारिणी।विविक्तदेशसेवित्वमरतिर्जनसंसदि।।13.11।।",
   "tr": "mayi chānanya-yogena bhaktir avyabhichāriṇī\nvivikta-deśha-sevitvam aratir jana-sansadi",
   "hi": "अनन्ययोग के द्वारा मुझमें अव्यभिचारिणी भक्ति; एकान्त स्थान में रहने का स्वभाव और (असंस्कृत) जनों के समुदाय में अरुचि।।",
   "en": "Unswerving devotion to Me, with concentration on Me and Me alone, a love for solitude, and indifference to social life;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "अध्यात्मज्ञाननित्यत्वं तत्त्वज्ञानार्थदर्शनम्।एतज्ज्ञानमिति प्रोक्तमज्ञानं यदतोन्यथा।।13.12।।",
   "tr": "adhyātma-jñāna-nityatvaṁ tattva-jñānārtha-darśhanam\netaj jñānam iti proktam ajñānaṁ yad ato ’nyathā",
   "hi": "अध्यात्मज्ञान में नित्यत्व अर्थात् स्थिरता तथा तत्त्वज्ञान के अर्थ रूप परमात्मा का दर्शन, यह सब तो ज्ञान कहा गया है, और जो इससे विपरीत है, वह अज्ञान है।।",
   "en": "Constant yearning for the knowledge of the Self, and pondering over the lessons of the great Truth—this is wisdom; all else is ignorance.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "ज्ञेयं यत्तत्प्रवक्ष्यामि यज्ज्ञात्वाऽमृतमश्नुते।अनादिमत्परं ब्रह्म न सत्तन्नासदुच्यते।।13.13।।",
   "tr": "jñeyaṁ yat tat pravakṣhyāmi yaj jñātvāmṛitam aśhnute\nanādi mat-paraṁ brahma na sat tan nāsad uchyate",
   "hi": "मैं उस ज्ञेय वस्तु को स्पष्ट कहूंगा जिसे जानकर मनुष्य अमृतत्व को प्राप्त करता है। वह ज्ञेय है - अनादि, परम ब्रह्म, जो न सत् और न असत् ही कहा जा सकता है।।",
   "en": "I will now speak to you of that great truth which one ought to know, since by it one will attain immortal bliss—that which is without beginning, the eternal spirit which dwells in me, neither with form nor without it.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "सर्वतः पाणिपादं तत्सर्वतोऽक्षिशिरोमुखम्।सर्वतः श्रुतिमल्लोके सर्वमावृत्य तिष्ठति।।13.14।।",
   "tr": "sarvataḥ pāṇi-pādaṁ tat sarvato ’kṣhi-śhiro-mukham\nsarvataḥ śhrutimal loke sarvam āvṛitya tiṣhṭhati",
   "hi": "वह सब ओर हाथ-पैर वाला है और सब ओर से नेत्र, शिर और मुखवाला तथा सब ओर से श्रोत्रवाला है; वह जगत् में सबको व्याप्त करके स्थित है।।",
   "en": "Everywhere are Its hands and feet; everywhere It has eyes that see, heads that think, and mouths that speak; everywhere It listens; It dwells in all the worlds and envelops them all.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "सर्वेन्द्रियगुणाभासं सर्वेन्द्रियविवर्जितम्।असक्तं सर्वभृच्चैव निर्गुणं गुणभोक्तृ च।।13.15।।",
   "tr": "sarvendriya-guṇābhāsaṁ sarvendriya-vivarjitam\nasaktaṁ sarva-bhṛich chaiva nirguṇaṁ guṇa-bhoktṛi cha",
   "hi": "वह समस्त इन्द्रियों के गुणो (कार्यों) के द्वारा प्रकाशित होने वाला, परन्तु (वस्तुत:) समस्त इन्द्रियों से रहित है; आसक्ति रहित तथा गुण रहित होते हुए भी सबको धारणपोषण करने वाला और गुणों का भोक्ता है।।",
   "en": "Beyond the senses, it yet shines through every sense perception; bound to nothing, it yet sustains everything; unaffected by the qualities, it still enjoys them all.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "बहिरन्तश्च भूतानामचरं चरमेव च।सूक्ष्मत्वात्तदविज्ञेयं दूरस्थं चान्तिके च तत्।।13.16।।",
   "tr": "bahir antaśh cha bhūtānām acharaṁ charam eva cha\nsūkṣhmatvāt tad avijñeyaṁ dūra-sthaṁ chāntike cha tat",
   "hi": "(वह ब्रह्म) भूत मात्र के अन्तर्बाह्य स्थित है; वह चर है और अचर भी। सूक्ष्म होने से वह अविज्ञेय है; वह सुदूर और अत्यन्त समीपस्थ भी है।।",
   "en": "It is within all beings, yet outside; motionless yet moving; too subtle to be perceived; far away yet ever near.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "अविभक्तं च भूतेषु विभक्तमिव च स्थितम्।भूतभर्तृ च तज्ज्ञेयं ग्रसिष्णु प्रभविष्णु च।।13.17।।",
   "tr": "avibhaktaṁ cha bhūteṣhu vibhaktam iva cha sthitam\nbhūta-bhartṛi cha taj jñeyaṁ grasiṣhṇu prabhaviṣhṇu cha",
   "hi": "और वह अविभक्त है, तथापि वह भूतों में विभक्त के समान स्थित है। वह ज्ञेय ब्रह्म भूतमात्र का भर्ता, संहारकर्ता और उत्पत्ति कर्ता है।।",
   "en": "In all beings, undivided yet living in division, it is the upholder of all, both creator and destroyer alike.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "ज्योतिषामपि तज्ज्योतिस्तमसः परमुच्यते।ज्ञानं ज्ञेयं ज्ञानगम्यं हृदि सर्वस्य विष्ठितम्।।13.18।।",
   "tr": "jyotiṣhām api taj jyotis tamasaḥ param uchyate\njñānaṁ jñeyaṁ jñāna-gamyaṁ hṛidi sarvasya viṣhṭhitam",
   "hi": "(वह ब्रह्म) ज्योतियों की भी ज्योति और (अज्ञान) अन्धकार से परे कहा जाता है। वह ज्ञान (चैतन्यस्वरूप) ज्ञेय और ज्ञान के द्वारा जानने योग्य (ज्ञानगम्य) है। वह सभी के हृदय में स्थित है।।",
   "en": "It is the light of lights, beyond the reach of darkness; the wisdom, the only thing worth knowing or that wisdom can teach; the presence in the hearts of all.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "इति क्षेत्रं तथा ज्ञानं ज्ञेयं चोक्तं समासतः।मद्भक्त एतद्विज्ञाय मद्भावायोपपद्यते।।13.19।।",
   "tr": "iti kṣhetraṁ tathā jñānaṁ jñeyaṁ choktaṁ samāsataḥ\nmad-bhakta etad vijñāya mad-bhāvāyopapadyate",
   "hi": "इस प्रकार, (मेरे द्वारा) क्षेत्र, ज्ञान और ज्ञेय को संक्षेपत: कहा गया। इसे तत्त्व से जानकर (विज्ञाय) मेरा भक्त मेरे स्वरूप को प्राप्त होता है।।",
   "en": "Thus, I have briefly told you what Matter is, the Self worth realizing, and what Wisdom is. He who is devoted to Me knows, and he will assuredly enter into Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "प्रकृतिं पुरुषं चैव विद्ध्यनादी उभावपि।विकारांश्च गुणांश्चैव विद्धि प्रकृतिसंभवान्।।13.20।।",
   "tr": "prakṛitiṁ puruṣhaṁ chaiva viddhy anādī ubhāv api\nvikārānśh cha guṇānśh chaiva viddhi prakṛiti-sambhavān",
   "hi": "प्रकृति और पुरुष इन दोनों को ही तुम अनादि जानो। और तुम यह भी जानो कि सभी विकार और गुण प्रकृति से ही उत्पन्न हुए हैं।।",
   "en": "Know further that Nature and God have no beginning, and that differences in character and quality originate from Nature only.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "कार्यकारणकर्तृत्वे हेतुः प्रकृतिरुच्यते।पुरुषः सुखदुःखानां भोक्तृत्वे हेतुरुच्यते।।13.21।।",
   "tr": "kārya-kāraṇa-kartṛitve hetuḥ prakṛitir uchyate\npuruṣhaḥ sukha-duḥkhānāṁ bhoktṛitve hetur uchyate",
   "hi": "कार्य और कारण के उत्पन्न करने में हेतु प्रकृति कही जाती है और पुरुष सुख-दु:ख के भोक्तृत्व में हेतु कहा जाता है।।",
   "en": "Nature is the law that generates cause and effect; God is the source of all pleasure and pain.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "पुरुषः प्रकृतिस्थो हि भुङ्क्ते प्रकृतिजान्गुणान्।कारणं गुणसङ्गोऽस्य सदसद्योनिजन्मसु।।13.22।।",
   "tr": "puruṣhaḥ prakṛiti-stho hi bhuṅkte prakṛiti-jān guṇān\nkāraṇaṁ guṇa-saṅgo ’sya sad-asad-yoni-janmasu",
   "hi": "प्रकृति में स्थित पुरुष प्रकृति से उत्पन्न गुणों को भोगता है। इन गुणों का संग ही इस पुरुष (जीव) के शुभ और अशुभ योनियों में जन्म लेने का कारण है।।",
   "en": "God, dwelling in the heart of Nature, experiences the qualities that Nature brings forth; and His affinity towards these qualities is the reason for His living in a good or evil body.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "उपद्रष्टाऽनुमन्ता च भर्ता भोक्ता महेश्वरः।परमात्मेति चाप्युक्तो देहेऽस्मिन्पुरुषः परः।।13.23।।",
   "tr": "upadraṣhṭānumantā cha bhartā bhoktā maheśhvaraḥ\nparamātmeti chāpy ukto dehe ’smin puruṣhaḥ paraḥ",
   "hi": "परम पुरुष ही इस देह में उपद्रष्टा, अनुमन्ता ,भर्ता, भोक्ता, महेश्वर और परमात्मा कहा जाता है।।",
   "en": "Thus, in the body of man dwells the Supreme God; He who sees, permits, upholds, and enjoys is the Highest God and the Highest Self.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "य एवं वेत्ति पुरुषं प्रकृतिं च गुणैःसह।सर्वथा वर्तमानोऽपि न स भूयोऽभिजायते।।13.24।।",
   "tr": "ya evaṁ vetti puruṣhaṁ prakṛitiṁ cha guṇaiḥ saha\nsarvathā vartamāno ’pi na sa bhūyo ’bhijāyate",
   "hi": "इस प्रकार पुरुष और गुणों के सहित प्रकृति को जो मनुष्य जानता है, वह सब प्रकार से रहता हुआ (व्यवहार करता हुआ) भी पुन: नहीं जन्मता है।।",
   "en": "He who understands God and Nature, along with her qualities, whatever his condition in life may be, will not come back to earth.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "ध्यानेनात्मनि पश्यन्ति केचिदात्मानमात्मना।अन्ये सांख्येन योगेन कर्मयोगेन चापरे।।13.25।।",
   "tr": "dhyānenātmani paśhyanti kechid ātmānam ātmanā\nanye sānkhyena yogena karma-yogena chāpare",
   "hi": "कोई पुरुष ध्यान के अभ्यास से आत्मा को आत्मा (हृदय) में आत्मा (शुद्ध बुद्धि) के द्वारा देखते हैं; अन्य लोग सांख्य योग के द्वारा तथा कोई साधक कर्मयोग से (आत्मा को देखते हैं )।।",
   "en": "Some realize the Supreme by meditating, with its aid, on the Self within; others by pure reason; and still others by right action.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "अन्ये त्वेवमजानन्तः श्रुत्वाऽन्येभ्य उपासते।तेऽपि चातितरन्त्येव मृत्युं श्रुतिपरायणाः।।13.26।।",
   "tr": "anye tv evam ajānantaḥ śhrutvānyebhya upāsate\nte ’pi chātitaranty eva mṛityuṁ śhruti-parāyaṇāḥ",
   "hi": "परन्तु, अन्य लोग जो स्वयं इस प्रकार न जानते हुए, दूसरों से (आचार्यों से) सुनकर ही उपासना करते हैं, वे श्रुतिपरायण (अर्थात् श्रवण ही जिनके लिए परम साधन है) लोग भी मृत्यु को नि:सन्देह तर जाते हैं।।",
   "en": "Others, again, having no direct knowledge but only hearing from others, still worship, and, if they are true to the teachings, they too will cross the sea of death.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "यावत्सञ्जायते किञ्चित्सत्त्वं स्थावरजङ्गमम्।क्षेत्रक्षेत्रज्ञसंयोगात्तद्विद्धि भरतर्षभ।।13.27।।",
   "tr": "yāvat sañjāyate kiñchit sattvaṁ sthāvara-jaṅgamam\nkṣhetra-kṣhetrajña-sanyogāt tad viddhi bharatarṣhabha",
   "hi": "हे भरत श्रेष्ठ ! यावन्मात्र जो कुछ भी स्थावर जंगम (चराचर) वस्तु उत्पन्न होती है, उस सबको तुम क्षेत्र और क्षेत्रज्ञ के संयोग से उत्पन्न हुई जानो।।",
   "en": "Wherever life is seen in things movable or immovable, it is the result of the combination of Matter and Spirit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "समं सर्वेषु भूतेषु तिष्ठन्तं परमेश्वरम्।विनश्यत्स्वविनश्यन्तं यः पश्यति स पश्यति।।13.28।।",
   "tr": "samaṁ sarveṣhu bhūteṣhu tiṣhṭhantaṁ parameśhvaram\nvinaśhyatsv avinaśhyantaṁ yaḥ paśhyati sa paśhyati",
   "hi": "जो पुरुष समस्त नश्वर भूतों में अनश्वर परमेश्वर को समभाव से स्थित देखता है, वही (वास्तव में) देखता है।।",
   "en": "He who can see the Supreme Lord in all beings, the Imperishable amidst the perishable, he is the one who truly sees.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "समं पश्यन्हि सर्वत्र समवस्थितमीश्वरम्।न हिनस्त्यात्मनाऽऽत्मानं ततो याति परां गतिम्।।13.29।।",
   "tr": "samaṁ paśhyan hi sarvatra samavasthitam īśhvaram\nna hinasty ātmanātmānaṁ tato yāti parāṁ gatim",
   "hi": "निश्चय ही, वह पुरुष सर्वत्र सम भाव से स्थित परमेश्वर को समान हुआ आत्मा (स्वयं) के द्वारा आत्मा (स्वयं) का नाश नहीं करता है, इससे वह परम गति को प्राप्त होता है।।",
   "en": "Beholding the Lord equally in all things, his actions do not mar his spiritual life but lead him to the heights of bliss.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 30,
   "sa": "प्रकृत्यैव च कर्माणि क्रियमाणानि सर्वशः।यः पश्यति तथाऽऽत्मानमकर्तारं स पश्यति।।13.30।।",
   "tr": "prakṛityaiva cha karmāṇi kriyamāṇāni sarvaśhaḥ\nyaḥ paśhyati tathātmānam akartāraṁ sa paśhyati",
   "hi": "जो पुरुष समस्त कर्मों को सर्वश: प्रकृति द्वारा ही किये गये देखता है तथा आत्मा को अकर्ता देखता है, वही (वास्तव में) देखता है।।",
   "en": "He who understands that it is only the Law of Nature that brings action to fruition, and that the Self never acts, alone knows the Truth.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 31,
   "sa": "यदा भूतपृथग्भावमेकस्थमनुपश्यति।तत एव च विस्तारं ब्रह्म सम्पद्यते तदा।।13.31।।",
   "tr": "yadā bhūta-pṛithag-bhāvam eka-stham anupaśhyati\ntata eva cha vistāraṁ brahma sampadyate tadā",
   "hi": "यह पुरुष जब भूतों के पृथक् भावों को एक (परमात्मा) में स्थित देखता है तथा उस (परमात्मा) से ही यह विस्तार हुआ जानता है, तब वह ब्रह्म को प्राप्त होता है।।",
   "en": "He who sees the diverse forms of life all rooted in One and growing forth from Him, shall indeed find the Absolute.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 32,
   "sa": "अनादित्वान्निर्गुणत्वात्परमात्मायमव्ययः।शरीरस्थोऽपि कौन्तेय न करोति न लिप्यते।।13.32।।",
   "tr": "anāditvān nirguṇatvāt paramātmāyam avyayaḥ\nśharīra-stho ’pi kaunteya na karoti na lipyate",
   "hi": "हे कौन्तेय ! अनादि और निर्गुण होने से यह परमात्मा अव्यय है। शरीर में स्थित हुआ भी, वस्तुत:, वह न (कर्म) करता है और न (फलों से) लिप्त होता है।।",
   "en": "The Supreme Spirit, O Prince, is without beginning, has no qualities, and is imperishable. Though it is within the body, it does not act, nor is it affected by action.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 33,
   "sa": "यथा सर्वगतं सौक्ष्म्यादाकाशं नोपलिप्यते।सर्वत्रावस्थितो देहे तथाऽऽत्मा नोपलिप्यते।।13.33।।",
   "tr": "yathā sarva-gataṁ saukṣhmyād ākāśhaṁ nopalipyate\nsarvatrāvasthito dehe tathātmā nopalipyate",
   "hi": "जिस प्रकार सर्वगत आकाश सूक्ष्म होने के कारण लिप्त नहीं होता, उसी प्रकार सर्वत्र देह में स्थित आत्मा लिप्त नहीं होता।।",
   "en": "As space, though present everywhere, remains unaffected due to its subtlety, so too the Self, though present in all forms, retains its purity unalloyed.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 34,
   "sa": "यथा प्रकाशयत्येकः कृत्स्नं लोकमिमं रविः।क्षेत्रं क्षेत्री तथा कृत्स्नं प्रकाशयति भारत।।13.34।।",
   "tr": "yathā prakāśhayaty ekaḥ kṛitsnaṁ lokam imaṁ raviḥ\nkṣhetraṁ kṣhetrī tathā kṛitsnaṁ prakāśhayati bhārata",
   "hi": "हे भारत ! जिस प्रकार एक ही सूर्य इस सम्पूर्ण लोक को प्रकाशित करता है, उसी प्रकार एक ही क्षेत्री (क्षेत्रज्ञ) सम्पूर्ण क्षेत्र को प्रकाशित करता है।।",
   "en": "As the one Sun illuminates the entire earth, so the Lord illuminates the entire universe.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 35,
   "sa": "क्षेत्रक्षेत्रज्ञयोरेवमन्तरं ज्ञानचक्षुषा।भूतप्रकृतिमोक्षं च ये विदुर्यान्ति ते परम्।।13.35।।",
   "tr": "kṣhetra-kṣhetrajñayor evam antaraṁ jñāna-chakṣhuṣhā\nbhūta-prakṛiti-mokṣhaṁ cha ye vidur yānti te param",
   "hi": "इस प्रकार, जो पुरुष ज्ञानचक्षु के द्वारा क्षेत्र और क्षेत्रज्ञ के भेद को तथा प्रकृति के विकारों से मोक्ष को जानते हैं, वे परम ब्रह्म को प्राप्त होते हैं।।",
   "en": "Those who, with the eyes of wisdom, thus see the difference between Matter and Spirit, and know how to liberate life from the Law of Nature, attain the Supreme.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
