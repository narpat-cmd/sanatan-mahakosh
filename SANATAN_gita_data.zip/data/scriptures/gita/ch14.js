// Bhagavad Gita adhyay 14 - Gunatraya Vibhaga Yoga (27 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch14"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 14,
 "title": "गुणत्रयविभागयोग",
 "illustration": "",
 "illustrationCaption": "Yoga through Understanding the Three Modes of Material Nature",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का चौदहवा अध्याय गुणत्रयविभागयोग है। इस अध्याय में, कृष्ण भौतिक प्रकृति के तीन गुणों का वर्णन करते हैं जिनसे भौतिक संसार में सब कुछ प्रभावित होता है - अच्छाई, लालसा और अज्ञान। आगे वह इन तीनों गुणों के प्रधान अभिलक्षणों अथवा कारणों का वर्णन करते हैं और बताते हैं कि कैसे ये तीनों गुण मनुष्य को प्रभावित करते हैं। फिर वह ऐसे व्यक्तियों की विभिन्न विशेषताओं का वर्णन करते हैं जो कि इन गुणों पर जीत पा चुके हैं। इस अध्याय के अंत में कृष्ण हमें सच्ची भक्ति कि शक्ति का स्मरण कराते हैं और बताते हैं की हम कैसे भगवन के साथ जुड़ कर इन गुणों को पार कर सकते हैं।",
 "summaryEn": "The fourteenth chapter of the Bhagavad Gita is \"Gunatraya Vibhaga Yoga\". In this chapter, Krishna reveals the three gunas (modes) of the material nature - goodness, passion and ignorance which everything in the material existence is influenced by. He further explains the essential characteristics of each of these modes, their cause and how they influence a living entity affected by them. He then reveals the various characteristics of the persons who have gone beyond these gunas. The chapter ends with Krishna reminding us of the power of pure devotion to God and how attachment to God can help us transcend these gunas.",
 "verses": [
  {
   "n": 1,
   "sa": "श्री भगवानुवाचपरं भूयः प्रवक्ष्यामि ज्ञानानां ज्ञानमुत्तमम्।यज्ज्ञात्वा मुनयः सर्वे परां सिद्धिमितो गताः।।14.1।।",
   "tr": "śhrī-bhagavān uvācha\nparaṁ bhūyaḥ pravakṣhyāmi jñānānāṁ jñānam uttamam\nyaj jñātvā munayaḥ sarve parāṁ siddhim ito gatāḥ",
   "hi": "श्री भगवान् ने कहा -- समस्त ज्ञानों में उत्तम परम ज्ञान को मैं पुन: कहूंगा, जिसको जानकर सभी मुनिजन इस (लोक) से जाकर (इस जीवनोपरान्त) परम सिद्धि को प्राप्त हुए हैं।।",
   "en": "Lord Shri Krishna continued: Now I will reveal to you the wisdom that is beyond knowledge, by attaining which the sages have reached perfection.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "इदं ज्ञानमुपाश्रित्य मम साधर्म्यमागताः।सर्गेऽपि नोपजायन्ते प्रलये न व्यथन्ति च।।14.2।।",
   "tr": "idaṁ jñānam upāśhritya mama sādharmyam āgatāḥ\nsarge ’pi nopajāyante pralaye na vyathanti cha",
   "hi": "इस ज्ञान का आश्रय लेकर मेरे स्वरूप (सार्धम्यम्) को प्राप्त पुरुष सृष्टि के आदि में जन्म नहीं लेते और प्रलयकाल में व्याकुल भी नहीं होते हैं।।",
   "en": "Dwelling in wisdom and realizing My divinity, they are not reborn when the universe is recreated at the beginning of every cycle, nor are they affected when it is dissolved.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "मम योनिर्महद्ब्रह्म तस्मिन् गर्भं दधाम्यहम्।संभवः सर्वभूतानां ततो भवति भारत।।14.3।।",
   "tr": "mama yonir mahad brahma tasmin garbhaṁ dadhāmy aham\nsambhavaḥ sarva-bhūtānāṁ tato bhavati bhārata",
   "hi": "हे भारत ! मेरी महद् ब्रह्मरूप प्रकृति, (भूतों की) योनि है, जिसमें मैं गर्भाधान करता हूँ; इससे समस्त भूतों की उत्पत्ति होती है।।",
   "en": "The eternal cosmos is My womb, in which I plant the seed from which all beings are born, O prince!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "सर्वयोनिषु कौन्तेय मूर्तयः सम्भवन्ति याः।तासां ब्रह्म महद्योनिरहं बीजप्रदः पिता।।14.4।।",
   "tr": "sarva-yoniṣhu kaunteya mūrtayaḥ sambhavanti yāḥ\ntāsāṁ brahma mahad yonir ahaṁ bīja-pradaḥ pitā",
   "hi": "हे कौन्तेय ! समस्त योनियों में जितनी मूर्तियाँ (शरीर) उत्पन्न होती हैं, उन सबकी योनि अर्थात् गर्भ है महद्ब्रह्म और मैं बीज की स्थापना करने वाला पिता हूँ।।",
   "en": "O illustrious son of Kunti! Through whatever wombs men are born, it is the Spirit itself that conceives, and I am their father.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "सत्त्वं रजस्तम इति गुणाः प्रकृतिसंभवाः।निबध्नन्ति महाबाहो देहे देहिनमव्ययम्।।14.5।।",
   "tr": "sattvaṁ rajas tama iti guṇāḥ prakṛiti-sambhavāḥ\nnibadhnanti mahā-bāho dehe dehinam avyayam",
   "hi": "हे महाबाहो ! सत्त्व, रज और तम ये प्रकृति से उत्पन्न तीनों गुण देही आत्मा को देह के साथ बांध देते हैं।।",
   "en": "Purity, passion, and ignorance are the qualities that the law of nature brings forth. They fetter the free spirit in all beings.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "तत्र सत्त्वं निर्मलत्वात्प्रकाशकमनामयम्।सुखसङ्गेन बध्नाति ज्ञानसङ्गेन चानघ।।14.6।।",
   "tr": "tatra sattvaṁ nirmalatvāt prakāśhakam anāmayam\nsukha-saṅgena badhnāti jñāna-saṅgena chānagha",
   "hi": "हे निष्पाप अर्जुन ! इन (तीनों) में, सत्त्वगुण निर्मल होने से प्रकाशक और अनामय (निरुपद्रव, निर्विकार या निरोग) है; (वह जीव को) सुख की आसक्ति से और ज्ञान की आसक्ति से बांध देता है।।",
   "en": "O Sinless One! Of these, purity, being luminous, strong, and invulnerable, binds one with its yearning for happiness and illumination.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "रजो रागात्मकं विद्धि तृष्णासङ्गसमुद्भवम्।तन्निबध्नाति कौन्तेय कर्मसङ्गेन देहिनम्।।14.7।।",
   "tr": "rajo rāgātmakaṁ viddhi tṛiṣhṇā-saṅga-samudbhavam\ntan nibadhnāti kaunteya karma-saṅgena dehinam",
   "hi": "हे कौन्तेय ! रजोगुण को रागस्वरूप जानो, जिससे तृष्णा और आसक्ति उत्पन्न होती है। वह देही आत्मा को कर्मों की आसक्ति से बांधता है।।",
   "en": "Passion, engendered by thirst for pleasure and attachment, binds the soul through its fondness for activities.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "तमस्त्वज्ञानजं विद्धि मोहनं सर्वदेहिनाम्।प्रमादालस्यनिद्राभिस्तन्निबध्नाति भारत।।14.8।।",
   "tr": "tamas tv ajñāna-jaṁ viddhi mohanaṁ sarva-dehinām\npramādālasya-nidrābhis tan nibadhnāti bhārata",
   "hi": "और हे भारत ! तमोगुण को अज्ञान से उत्पन्न जानो; जो समस्त देहधारियों (जीवों) को मोहित करने वाला है। वह प्रमाद, आलस्य और निद्रा के द्वारा जीव को बांधता है।।",
   "en": "But Ignorance, the product of darkness, stupefies the senses of all embodied beings, binding them with chains of folly, indolence, and lethargy.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "सत्त्वं सुखे सञ्जयति रजः कर्मणि भारत।ज्ञानमावृत्य तु तमः प्रमादे सञ्जयत्युत।।14.9।।",
   "tr": "sattvaṁ sukhe sañjayati rajaḥ karmaṇi bhārata\njñānam āvṛitya tu tamaḥ pramāde sañjayaty uta",
   "hi": "हे भारत ! सत्त्वगुण सुख में आसक्त कर देता है और रजोगुण कर्म में, किन्तु तमोगुण ज्ञान को आवृत्त करके जीव को प्रमाद से युक्त कर देता है।।",
   "en": "Purity brings happiness, passion brings commotion, and ignorance, which obscures wisdom, leads to a life of failure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "रजस्तमश्चाभिभूय सत्त्वं भवति भारत।रजः सत्त्वं तमश्चैव तमः सत्त्वं रजस्तथा।।14.10।।",
   "tr": "rajas tamaśh chābhibhūya sattvaṁ bhavati bhārata\nrajaḥ sattvaṁ tamaśh chaiva tamaḥ sattvaṁ rajas tathā",
   "hi": "हे भारत ! कभी रज और तम को अभिभूत (दबा) करके सत्त्वगुण की वृद्धि होती है, कभी रज और सत्त्व को दबाकर तमोगुण की वृद्धि होती है, तो कभी तम और सत्त्व को अभिभूत कर रजोगुण की वृद्धि होती है।।",
   "en": "O Prince! Purity prevails when passion and ignorance are overcome; passion, when purity and ignorance are overcome; and ignorance when it is overcome by purity and passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "सर्वद्वारेषु देहेऽस्मिन्प्रकाश उपजायते।ज्ञानं यदा तदा विद्याद्विवृद्धं सत्त्वमित्युत।।14.11।।",
   "tr": "sarva-dvāreṣhu dehe ’smin prakāśha upajāyate\njñānaṁ yadā tadā vidyād vivṛiddhaṁ sattvam ity uta",
   "hi": "जब इस देह के द्वारों अर्थात् समस्त इन्द्रियों में ज्ञानरूप प्रकाश उत्पन्न होता है, तब सत्त्वगुण को प्रवृद्ध हुआ जानो।।",
   "en": "When the light of knowledge gleams forth from all the gates of the body, then be sure that purity prevails.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "लोभः प्रवृत्तिरारम्भः कर्मणामशमः स्पृहा।रजस्येतानि जायन्ते विवृद्धे भरतर्षभ।।14.12।।",
   "tr": "lobhaḥ pravṛittir ārambhaḥ karmaṇām aśhamaḥ spṛihā\nrajasy etāni jāyante vivṛiddhe bharatarṣhabha",
   "hi": "हे भरत-श्रेष्ठ ! रजोगुण के प्रवृद्ध होने पर लोभ, प्रवृत्ति (सामान्य चेष्टा) कर्मों का आरम्भ, शम का अभाव तथा स्पृहा, ये सब उत्पन्न होते हैं।।",
   "en": "O best of Indians! Avarice, the impulse to act, and the beginning of action itself are all due to the dominance of passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "अप्रकाशोऽप्रवृत्तिश्च प्रमादो मोह एव च।तमस्येतानि जायन्ते विवृद्धे कुरुनन्दन।।14.13।।",
   "tr": "aprakāśho ’pravṛittiśh cha pramādo moha eva cha\ntamasy etāni jāyante vivṛiddhe kuru-nandana",
   "hi": "हे कुरुनन्दन ! तमोगुण के प्रवृद्ध होने पर अप्रकाश, अप्रवृत्ति, प्रमाद और मोह ये सब उत्पन्न होते हैं।।",
   "en": "Darkness, stagnation, folly, and infatuation are the results of the dominance of ignorance, O joy of the Kuru clan!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "यदा सत्त्वे प्रवृद्धे तु प्रलयं याति देहभृत्।तदोत्तमविदां लोकानमलान्प्रतिपद्यते।।14.14।।",
   "tr": "yadā sattve pravṛiddhe tu pralayaṁ yāti deha-bhṛit\ntadottama-vidāṁ lokān amalān pratipadyate",
   "hi": "जब यह जीव (देहभृत्) सत्त्वगुण की प्रवृद्धि में मृत्यु को प्राप्त होता है, तब उत्तम कर्म करने वालों के निर्मल अर्थात् स्वर्गादि लोकों को प्राप्त होता है।।",
   "en": "When purity prevails, the soul, upon leaving the body, passes on to the pure regions where those who know the Highest reside.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "रजसि प्रलयं गत्वा कर्मसङ्गिषु जायते।तथा प्रलीनस्तमसि मूढयोनिषु जायते।।14.15।।",
   "tr": "rajasi pralayaṁ gatvā karma-saṅgiṣhu jāyate\ntathā pralīnas tamasi mūḍha-yoniṣhu jāyate",
   "hi": "रजोगुण के प्रवृद्ध काल में मृत्यु को प्राप्त होकर कर्मासक्ति वाले (मनुष्य) लोक में वह जन्म लेता है तथा तमोगुण के प्रवृद्धकाल में (मरण होने पर) मूढ़योनि में जन्म लेता है।।",
   "en": "When passion prevails, the soul is reborn among those who love activity; when ignorance rules, it enters the wombs of the ignorant.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "कर्मणः सुकृतस्याहुः सात्त्विकं निर्मलं फलम्।रजसस्तु फलं दुःखमज्ञानं तमसः फलम्।।14.16।।",
   "tr": "karmaṇaḥ sukṛitasyāhuḥ sāttvikaṁ nirmalaṁ phalam\nrajasas tu phalaṁ duḥkham ajñānaṁ tamasaḥ phalam",
   "hi": "शुभ कर्म का फल सात्विक और निर्मल कहा गया है; रजोगुण का फल दु;ख और तमोगुण का फल अज्ञान है।।",
   "en": "They say the fruit of a meritorious action is spotless and pure; the outcome of passion is misery, and of ignorance, darkness.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "सत्त्वात्सञ्जायते ज्ञानं रजसो लोभ एव च।प्रमादमोहौ तमसो भवतोऽज्ञानमेव च।।14.17।।",
   "tr": "sattvāt sañjāyate jñānaṁ rajaso lobha eva cha\npramāda-mohau tamaso bhavato ’jñānam eva cha",
   "hi": "सत्त्वगुण से ज्ञान उत्पन्न होता है। रजोगुण से लोभ तथा तमोगुण से प्रमाद, मोह और अज्ञान उत्पन्न होता है।।",
   "en": "Purity engenders wisdom, passion avarice, and ignorance folly, infatuation, and darkness.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "ऊर्ध्वं गच्छन्ति सत्त्वस्था मध्ये तिष्ठन्ति राजसाः।जघन्यगुणवृत्तिस्था अधो गच्छन्ति तामसाः।।14.18।।",
   "tr": "ūrdhvaṁ gachchhanti sattva-sthā madhye tiṣhṭhanti rājasāḥ\njaghanya-guṇa-vṛitti-sthā adho gachchhanti tāmasāḥ",
   "hi": "सत्त्वगुण में स्थित पुरुष उच्च (लोकों को) जाते हैं; राजस पुरुष मध्य (मनुष्य लोक) में रहते हैं और तमोगुण की अत्यन्त हीन प्रवृत्तियों में स्थित तामस लोग अधोगति को प्राप्त होते हैं।।",
   "en": "When purity is in the ascendant, the man evolves; when passion is in the ascendant, he neither evolves nor degenerates; when ignorance is in the ascendant, he is lost.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "नान्यं गुणेभ्यः कर्तारं यदा द्रष्टानुपश्यति।गुणेभ्यश्च परं वेत्ति मद्भावं सोऽधिगच्छति।।14.19।।",
   "tr": "nānyaṁ guṇebhyaḥ kartāraṁ yadā draṣhṭānupaśhyati\nguṇebhyaśh cha paraṁ vetti mad-bhāvaṁ so ’dhigachchhati",
   "hi": "जब द्रष्टा (साधक) पुरुष तीनों गुणों के अतिरिक्त किसी अन्य को कर्ता नहीं देखता, अर्थात् नहीं समझता है और तीनों गुणों से परे मेरे तत्व को जानता है, तब वह मेरे स्वरूप को प्राप्त होता है।।",
   "en": "As soon as one understands that it is only the qualities that act and nothing else, and perceives that which is beyond, they attain My divine nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "गुणानेतानतीत्य त्रीन्देही देहसमुद्भवान्।जन्ममृत्युजरादुःखैर्विमुक्तोऽमृतमश्नुते।।14.20।।",
   "tr": "guṇān etān atītya trīn dehī deha-samudbhavān\njanma-mṛityu-jarā-duḥkhair vimukto ’mṛitam aśhnute",
   "hi": "यह देही पुरुष शरीर की उत्पत्ति के कारणरूप तीनों गुणों से अतीत होकर जन्म, मृत्यु, जरा और दु:खों से विमुक्त हुआ अमृतत्व को प्राप्त होता है।।",
   "en": "When the soul transcends the Qualities, which are the real cause of physical existence, then, freed from birth and death, from old age and misery, he drinks the nectar of immortality.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "अर्जुन उवाचकैर्लिंगैस्त्रीन्गुणानेतानतीतो भवति प्रभो।किमाचारः कथं चैतांस्त्रीन्गुणानतिवर्तते।।14.21।।",
   "tr": "arjuna uvācha\nkair liṅgais trīn guṇān etān atīto bhavati prabho\nkim āchāraḥ kathaṁ chaitāns trīn guṇān ativartate",
   "hi": "अर्जुन ने कहा -- हे प्रभो ! इन तीनो गुणों से अतीत हुआ पुरुष किन लक्षणों से युक्त होता है ? वह किस प्रकार के आचरण वाला होता है ? और, वह किस उपाय से इन तीनों गुणों से अतीत होता है।।",
   "en": "Arjuna asked, \"My Lord, how can one recognize someone who has transcended the qualities? How do they act and live beyond them?\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "श्री भगवानुवाचप्रकाशं च प्रवृत्तिं च मोहमेव च पाण्डव।न द्वेष्टि सम्प्रवृत्तानि न निवृत्तानि काङ्क्षति।।14.22।।",
   "tr": "śhrī-bhagavān uvācha\nprakāśhaṁ cha pravṛittiṁ cha moham eva cha pāṇḍava\nna dveṣhṭi sampravṛittāni na nivṛittāni kāṅkṣhati",
   "hi": "श्रीभगवान् ने कहा -- हे पाण्डव ! (ज्ञानी पुरुष) प्रकाश, प्रवृत्ति और मोह के प्रवृत्त होने पर भी उनका द्वेष नहीं करता तथा निवृत्त होने पर उनकी आकांक्षा नहीं करता है।।",
   "en": "Lord Shri Krishna replied: O Prince! He who does not shun the quality that is present and does not long for that which is absent;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "उदासीनवदासीनो गुणैर्यो न विचाल्यते।गुणा वर्तन्त इत्येव योऽवतिष्ठति नेङ्गते।।14.23।।",
   "tr": "udāsīna-vad āsīno guṇair yo na vichālyate\nguṇā vartanta ity evaṁ yo ’vatiṣhṭhati neṅgate",
   "hi": "जो उदासीन के समान आसीन होकर गुणों के द्वारा विचलित नहीं किया जा सकता और \"गुण ही व्यवहार करते हैं\" ऐसा जानकर स्थित रहता है और उस स्थिति से विचलित नहीं होता।।",
   "en": "He who maintains an attitude of indifference, who is not disturbed by the qualities, who realizes that it is only they who act, and remains calm;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "समदुःखसुखः स्वस्थः समलोष्टाश्मकाञ्चनः।तुल्यप्रियाप्रियो धीरस्तुल्यनिन्दात्मसंस्तुतिः।।14.24।।",
   "tr": "sama-duḥkha-sukhaḥ sva-sthaḥ sama-loṣhṭāśhma-kāñchanaḥ\ntulya-priyāpriyo dhīras tulya-nindātma-sanstutiḥ",
   "hi": "जो स्वस्थ (स्वरूप में स्थित), सुख-दु:ख में समान रहता है तथा मिट्टी, पत्थर और स्वर्ण में समदृष्टि रखता है; ऐसा वीर पुरुष प्रिय और अप्रिय को तथा निन्दा और आत्मस्तुति को तुल्य समझता है।।",
   "en": "Who accepts pain and pleasure as they come, is centered in their Self, to whom a piece of clay, stone, or gold are all the same, who neither likes nor dislikes, who is steadfast, indifferent alike to praise or censure;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "मानापमानयोस्तुल्यस्तुल्यो मित्रारिपक्षयोः।सर्वारम्भपरित्यागी गुणातीतः स उच्यते।।14.25।।",
   "tr": "mānāpamānayos tulyas tulyo mitrāri-pakṣhayoḥ\nsarvārambha-parityāgī guṇātītaḥ sa uchyate",
   "hi": "जो मान और अपमान में सम है; शत्रु और मित्र के पक्ष में भी सम है, ऐसा सर्वारम्भ परित्यागी पुरुष गुणातीत कहा जाता है।।",
   "en": "Who looks equally upon honor and dishonor, loves friends and foes alike, and abandons all initiative, such is he who transcends the qualities.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "मां च योऽव्यभिचारेण भक्ितयोगेन सेवते।स गुणान्समतीत्यैतान् ब्रह्मभूयाय कल्पते।।14.26।।",
   "tr": "māṁ cha yo ’vyabhichāreṇa bhakti-yogena sevate\nsa guṇān samatītyaitān brahma-bhūyāya kalpate",
   "hi": "जो पुरुष अव्यभिचारी भक्तियोग के द्वारा मेरी सेवा अर्थात् उपासना करता है, वह इन तीनों गुणों के अतीत होकर ब्रह्म बनने के लिये योग्य हो जाता है।।",
   "en": "And he who serves Me alone, with unwavering devotion, shall overcome the Qualities and become one with the Eternal.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "ब्रह्मणो हि प्रतिष्ठाऽहममृतस्याव्ययस्य च।शाश्वतस्य च धर्मस्य सुखस्यैकान्तिकस्य च।।14.27।।",
   "tr": "brahmaṇo hi pratiṣhṭhāham amṛitasyāvyayasya cha\nśhāśhvatasya cha dharmasya sukhasyaikāntikasya cha",
   "hi": "क्योंकि मैं अमृत, अव्यय, ब्रह्म, शाश्वत धर्म और ऐकान्तिक अर्थात् पारमार्थिक सुख की प्रतिष्ठा हूँ।।",
   "en": "For I am the home of the spirit, the continual source of immortality, eternal righteousness, and infinite joy.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
