// Bhagavad Gita adhyay 9 - Raja Vidya Yoga (34 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch09"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 9,
 "title": "राजविद्याराजगुह्ययोग",
 "illustration": "",
 "illustrationCaption": "Yoga through the King of Sciences",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का नौवां अध्याय राजविद्याराजगुह्ययोग है। इस अध्याय में, कृष्ण समझाते हैं कि वह सर्वोच्च हैं और यह भौतिक संसार उनकी योगमाया द्वारा रचित और खंडित होता रहता है अथवा मनुष्य उनकी देखरेख में आते जाते रहते हैं। वे हमारी आध्यात्मिक जागरूकता के प्रति भक्ति की भूमिका और महत्व का वर्णन करते हैं। ऐसी भक्ति में मनुष्य को भगवन के लिए ही जीवित रहना चाहिए, अपना सर्वस्व भगवन को ही समर्पित करना चाहिए और सबकुछ भगवन के लिए ही करना चाहिए। जो इस प्रकार की भक्ति का अनुसरण करता है वह इस भौतिक संसार के बंधनों से मुक्त हो जाता है और भगवान के साथ एकजुट हो जाता है।",
 "summaryEn": "The ninth chapter of the Bhagavad Gita is \"Raja Vidya Yoga\". In this chapter, Krishna explains that He is Supreme and how this material existence is created, maintained and destroyed by His Yogmaya and all beings come and go under his supervision. He reveals the Role and the Importance of Bhakti (transcendental devotional service) towards our Spiritual Awakening. In such devotion, one must live for the God, offer everything that he possesses to Him and do everything for Him only. One who follows such devotion becomes free from the bonds of this material world and unites with the Lord.",
 "verses": [
  {
   "n": 1,
   "sa": "श्री भगवानुवाच\nइदं तु ते गुह्यतमं प्रवक्ष्याम्यनसूयवे।\nज्ञानं विज्ञानसहितं यज्ज्ञात्वा मोक्ष्यसेऽशुभात्।।9.1।।",
   "tr": "śhrī bhagavān uvācha\nidaṁ tu te guhyatamaṁ pravakṣhyāmyanasūyave\njñānaṁ vijñāna-sahitaṁ yaj jñātvā mokṣhyase ’śhubhāt",
   "hi": "श्रीभगवान् ने कहा -- तुम अनसूयु (दोष दृष्टि रहित) के लिए मैं इस गुह्यतम ज्ञान को विज्ञान के सहित कहूँगा, जिसको जानकर तुम अशुभ (संसार बंधन) से मुक्त हो जाओगे।।",
   "en": "Lord Shri Krishna said: I will now reveal to you, since you do not doubt, that profound mysticism, which, when followed with experience, will liberate you from sin.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "राजविद्या राजगुह्यं पवित्रमिदमुत्तमम्।\nप्रत्यक्षावगमं धर्म्यं सुसुखं कर्तुमव्ययम्।।9.2।।",
   "tr": "rāja-vidyā rāja-guhyaṁ pavitram idam uttamam\npratyakṣhāvagamaṁ dharmyaṁ su-sukhaṁ kartum avyayam",
   "hi": "यह ज्ञान राजविद्या (विद्याओं का राजा) और राजगुह्य (सब गुह्यों अर्थात् रहस्यों का राजा) एवं पवित्र, उत्तम, प्रत्यक्ष ज्ञानवाला और धर्मयुक्त है, तथा करने में सरल और अव्यय है।।",
   "en": "This is the supreme science, the supreme secret, the purest and best; it is intuitive, righteous, and to those who practice it, it is exceedingly pleasant.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "अश्रद्दधानाः पुरुषा धर्मस्यास्य परन्तप।\nअप्राप्य मां निवर्तन्ते मृत्युसंसारवर्त्मनि।।9.3।।",
   "tr": "aśhraddadhānāḥ puruṣhā dharmasyāsya parantapa\naprāpya māṁ nivartante mṛityu-samsāra-vartmani",
   "hi": "हे परन्तप ! इस धर्म में श्रद्धारहित पुरुष मुझे प्राप्त न होकर मृत्युरूपी संसार में रहते हैं (भ्रमण करते हैं)।।",
   "en": "They who have no faith in this teaching cannot find Me; they remain lost in the purlieus of this perishable world.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "मया ततमिदं सर्वं जगदव्यक्तमूर्तिना।\nमत्स्थानि सर्वभूतानि न चाहं तेष्ववस्थितः।।9.4।।",
   "tr": "mayā tatam idaṁ sarvaṁ jagad avyakta-mūrtinā\nmat-sthāni sarva-bhūtāni na chāhaṁ teṣhvavasthitaḥ",
   "hi": "यह सम्पूर्ण जगत् मुझ (परमात्मा) के अव्यक्त स्वरूप से व्याप्त है; भूतमात्र मुझमें स्थित है, परन्तु मैं उनमें स्थित नहीं हूं।।",
   "en": "The whole world is pervaded by Me, yet My form is not visible. All living beings have their being in Me, yet I am not confined by them.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "न च मत्स्थानि भूतानि पश्य मे योगमैश्वरम्।\nभूतभृन्न च भूतस्थो ममात्मा भूतभावनः।।9.5।।",
   "tr": "na cha mat-sthāni bhūtāni paśhya me yogam aiśhwaram\nbhūta-bhṛin na cha bhūta-stho mamātmā bhūta-bhāvanaḥ",
   "hi": "और (वस्तुत:) भूतमात्र मुझ में स्थित नहीं है; मेरे ईश्वरीय योग को देखो कि भूतों को धारण करने वाली और भूतों को उत्पन्न करने वाली मेरी आत्मा उन भूतों में स्थित नहीं है।।",
   "en": "Nevertheless, they do not consciously abide in Me. Such is My Divine Sovereignty that, though I, the Supreme Self, am the cause and upholder of all, yet I remain outside.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "यथाऽऽकाशस्थितो नित्यं वायुः सर्वत्रगो महान्।\nतथा सर्वाणि भूतानि मत्स्थानीत्युपधारय।।9.6।।",
   "tr": "yathākāśha-sthito nityaṁ vāyuḥ sarvatra-go mahān\ntathā sarvāṇi bhūtāni mat-sthānītyupadhāraya",
   "hi": "जैसे सर्वत्र विचरण करने वाली महान् वायु सदा आकाश में स्थित रहती हैं, वैसे ही सम्पूर्ण भूत मुझमें स्थित हैं, ऐसा तुम जानो।।",
   "en": "As the mighty wind, though moving everywhere, has no resting place except in space, so all these beings have no home except in Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "सर्वभूतानि कौन्तेय प्रकृतिं यान्ति मामिकाम्।\nकल्पक्षये पुनस्तानि कल्पादौ विसृजाम्यहम्।।9.7।।",
   "tr": "sarva-bhūtāni kaunteya prakṛitiṁ yānti māmikām\nkalpa-kṣhaye punas tāni kalpādau visṛijāmyaham",
   "hi": "हे कौन्तेय ! (एक) कल्प के अन्त में समस्त भूत मेरी प्रकृति को प्राप्त होते हैं; और (दूसरे) कल्प के प्रारम्भ में उनको मैं फिर रचता हूँ।।",
   "en": "All beings, O Arjuna, return at the end of every cosmic cycle into the realm of Nature, which is a part of Me, and at the start of the next I send them forth again.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "प्रकृतिं स्वामवष्टभ्य विसृजामि पुनः पुनः।\nभूतग्राममिमं कृत्स्नमवशं प्रकृतेर्वशात्।।9.8।।",
   "tr": "prakṛitiṁ svām avaṣhṭabhya visṛijāmi punaḥ punaḥ\nbhūta-grāmam imaṁ kṛitsnam avaśhaṁ prakṛiter vaśhāt",
   "hi": "प्रकृति को अपने वश में करके (अर्थात् उसे चेतनता प्रदान कर) स्वभाव के वश से परतन्त्र (अवश) हुए इस सम्पूर्ण भूत समुदाय को मैं पुन:-पुन: रचता हूँ।।",
   "en": "With the help of Nature, I again and again pour forth the whole multitude of beings, whether they will or not, for they are ruled by My will.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "न च मां तानि कर्माणि निबध्नन्ति धनञ्जय।\nउदासीनवदासीनमसक्तं तेषु कर्मसु।।9.9।।",
   "tr": "na cha māṁ tāni karmāṇi nibadhnanti dhanañjaya\nudāsīna-vad āsīnam asaktaṁ teṣhu karmasu",
   "hi": "हे धनंजय ! उन कर्मों में आसक्ति रहित और उदासीन के समान स्थित मुझ (परमात्मा) को वे कर्म नहीं बांधते हैं।।",
   "en": "But these acts of mine do not bind me; I remain outside and unattached.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "मयाऽध्यक्षेण प्रकृतिः सूयते सचराचरम्।\nहेतुनाऽनेन कौन्तेय जगद्विपरिवर्तते।।9.10।।",
   "tr": "mayādhyakṣheṇa prakṛitiḥ sūyate sa-charācharam\nhetunānena kaunteya jagad viparivartate",
   "hi": "हे कौन्तेय ! मुझ अध्यक्ष के कारण ( अर्थात् मेरी अध्यक्षता में) प्रकृति चराचर जगत् को उत्पन्न करती है; इस कारण यह जगत् घूमता रहता है।।",
   "en": "Under my guidance, Nature produces all movable and immovable things. Thus, O Arjuna, this universe revolves.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "अवजानन्ति मां मूढा मानुषीं तनुमाश्रितम्।\nपरं भावमजानन्तो मम भूतमहेश्वरम्।।9.11।।",
   "tr": "avajānanti māṁ mūḍhā mānuṣhīṁ tanum āśhritam\nparaṁ bhāvam ajānanto mama bhūta-maheśhvaram",
   "hi": "समस्त भूतों के महान् ईश्वर रूप मेरे परम भाव को नहीं जानते हुए मूढ़ लोग मनुष्य शरीरधारी मुझ परमात्मा का अनादर करते हैं।।",
   "en": "Fools disregard Me, seeing Me clad in human form. They do not know that in My higher nature, I am the Lord-God of all.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "मोघाशा मोघकर्माणो मोघज्ञाना विचेतसः।\nराक्षसीमासुरीं चैव प्रकृतिं मोहिनीं श्रिताः।।9.12।।",
   "tr": "moghāśhā mogha-karmāṇo mogha-jñānā vichetasaḥ\nrākṣhasīm āsurīṁ chaiva prakṛitiṁ mohinīṁ śhritāḥ",
   "hi": "वृथा आशा, वृथा कर्म और वृथा ज्ञान वाले अविचारीजन राक्षसों के और असुरों के मोहित करने वाले स्वभाव को धारण किये रहते हैं।।",
   "en": "Their hopes are futile, their actions worthless, their knowledge ineffective; they are without sense, deceitful, barbaric, and godless.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "महात्मानस्तु मां पार्थ दैवीं प्रकृतिमाश्रिताः।\nभजन्त्यनन्यमनसो ज्ञात्वा भूतादिमव्ययम्।।9.13।।",
   "tr": "mahātmānas tu māṁ pārtha daivīṁ prakṛitim āśhritāḥ\nbhajantyananya-manaso jñātvā bhūtādim avyayam",
   "hi": "हे पार्थ ! परन्तु दैवी प्रकृति के आश्रित महात्मा पुरुष मुझे समस्त भूतों का आदिकारण और अव्ययस्वरूप जानकर अनन्यमन से युक्त होकर मुझे भजते हैं।।",
   "en": "But the great souls, O Arjuna! Filled with my divine spirit, they worship me, fix their minds on me alone, for they know that I am the imperishable source of being.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "सततं कीर्तयन्तो मां यतन्तश्च दृढव्रताः।\nनमस्यन्तश्च मां भक्त्या नित्ययुक्ता उपासते।।9.14।।",
   "tr": "satataṁ kīrtayanto māṁ yatantaśh cha dṛiḍha-vratāḥ\nnamasyantaśh cha māṁ bhaktyā nitya-yuktā upāsate",
   "hi": "सतत मेरा कीर्तन करते हुए, प्रयत्नशील, दढ़व्रती पुरुष मुझे नमस्कार करते हुए, नित्ययुक्त होकर भक्तिपूर्वक मेरी उपासना करते हैं।।",
   "en": "Always extolling Me, they are strenuous and firm in their vows, prostrating themselves before Me, and worshiping Me continually with concentrated devotion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "ज्ञानयज्ञेन चाप्यन्ये यजन्तो मामुपासते।\nएकत्वेन पृथक्त्वेन बहुधा विश्वतोमुखम्।।9.15।।",
   "tr": "jñāna-yajñena chāpyanye yajanto mām upāsate\nekatvena pṛithaktvena bahudhā viśhvato-mukham",
   "hi": "कोई मुझे ज्ञानयज्ञ के द्वारा पूजन करते हुए एकत्वभाव से उपासते हैं, कोई पृथक भाव से, कोई बहुत प्रकार से मुझ विराट स्वरूप (विश्वतो मुखम्) को उपासते हैं।।",
   "en": "Others worship Me with full consciousness as the One, the Manifold, the Omnipresent, and the Universal.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "अहं क्रतुरहं यज्ञः स्वधाऽहमहमौषधम्।\nमंत्रोऽहमहमेवाज्यमहमग्निरहं हुतम्।।9.16।।",
   "tr": "ahaṁ kratur ahaṁ yajñaḥ svadhāham aham auṣhadham\nmantro ’ham aham evājyam aham agnir ahaṁ hutam",
   "hi": "मैं ऋक्रतु हूँ; मैं यज्ञ हूँ; स्वधा और औषध मैं हूँ, मैं मन्त्र हूँ, घी हूँ, मैं अग्नि हूँ और हुतं अर्थात् हवन कर्म मैं हूँ।।",
   "en": "I am the oblation, the sacrifice, and the worship; I am the fuel and the chant; I am the butter offered to the fire; I am the fire itself, and I am the act of offering.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "पिताऽहमस्य जगतो माता धाता पितामहः।\nवेद्यं पवित्रमोंकार ऋक् साम यजुरेव च।।9.17।।",
   "tr": "pitāham asya jagato mātā dhātā pitāmahaḥ\nvedyaṁ pavitram oṁkāra ṛik sāma yajur eva cha",
   "hi": "मैं ही इस जगत् का पिता, माता, धाता (धारण करने वाला) और पितामह हूँमैं वेद्य (जानने योग्य) वस्तु हूँ, पवित्र, ओंकार, ऋग्वेद, सामवेद और यजुर्वेद भी मैं ही हूँ।।",
   "en": "I am the Father of the universe, its Mother, Nourisher, and Grandfather; I am the Knowable and the Pure; I am Om, and I am the Sacred Scriptures.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "गतिर्भर्ता प्रभुः साक्षी निवासः शरणं सुहृत्।\nप्रभवः प्रलयः स्थानं निधानं बीजमव्ययम्।।9.18।।",
   "tr": "gatir bhartā prabhuḥ sākṣhī nivāsaḥ śharaṇaṁ suhṛit\nprabhavaḥ pralayaḥ sthānaṁ nidhānaṁ bījam avyayam",
   "hi": "गति (लक्ष्य), भरण-पोषण करने वाला, प्रभु (स्वामी), साक्षी, निवास, शरणस्थान तथा मित्र और उत्पत्ति, प्रलयरूप तथा स्थान (आधार), निधान और अव्यय कारण भी मैं हूँ।।",
   "en": "I am the goal, the sustainer, the Lord, the witness, the home, the shelter, the lover, and the origin; I am life and death; I am the fountain and the imperishable seed.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "तपाम्यहमहं वर्षं निगृह्णाम्युत्सृजामि च।\nअमृतं चैव मृत्युश्च सदसच्चाहमर्जुन।।9.19।।",
   "tr": "tapāmyaham ahaṁ varṣhaṁ nigṛihṇāmyutsṛijāmi cha\namṛitaṁ chaiva mṛityuśh cha sad asach chāham arjuna",
   "hi": "हे अर्जुन ! मैं ही (सूर्य रूप में) तपता हूँ; मैं वर्षा का निग्रह और उत्सर्जन करता हूँ। मैं ही अमृत और मृत्यु एवं सत् और असत् हूँ।।",
   "en": "I am the heat of the sun, I release and withhold the rain. I am death and immortality; I am being and non-being.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "त्रैविद्या मां सोमपाः पूतपापा\nयज्ञैरिष्ट्वा स्वर्गतिं प्रार्थयन्ते।\nते पुण्यमासाद्य सुरेन्द्रलोक\nमश्नन्ति दिव्यान्दिवि देवभोगान्।।9.20।।",
   "tr": "trai-vidyā māṁ soma-pāḥ pūta-pāpā\nyajñair iṣhṭvā svar-gatiṁ prārthayante\nte puṇyam āsādya surendra-lokam\naśhnanti divyān divi deva-bhogān",
   "hi": "तीनों वेदों के ज्ञाता (वेदोक्त सकाम कर्म करने वाले), सोमपान करने वाले एवं पापों से पवित्र हुए पुरुष मुझे यज्ञों के द्वारा पूजकर स्वर्ग प्राप्ति चाहते हैं; वे पुरुष अपने पुण्यों के फलरूप इन्द्रलोक को प्राप्त कर स्वर्ग में दिव्य देवताओं के भोग भोगते हैं।।",
   "en": "Those who are versed in the scriptures, who drink the mystic Soma-juice and are purified from sin, and who, while worshipping Me with sacrifices, pray that I will lead them to heaven; they reach the holy world where the Controller of the Powers of Nature resides, and they enjoy the feasts of Paradise.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "ते तं भुक्त्वा स्वर्गलोकं विशालं\nक्षीणे पुण्ये मर्त्यलोकं विशन्ति।\nएव त्रयीधर्ममनुप्रपन्ना\nगतागतं कामकामा लभन्ते।।9.21।।",
   "tr": "te taṁ bhuktvā swarga-lokaṁ viśhālaṁ\nkṣhīṇe puṇye martya-lokaṁ viśhanti\nevaṁ trayī-dharmam anuprapannā\ngatāgataṁ kāma-kāmā labhante",
   "hi": "वे उस विशाल स्वर्गलोक को भोगकर, पुण्यक्षीण होने पर, मृत्युलोक को प्राप्त होते हैं। इस प्रकार तीनों वेदों में कहे गये कर्म के शरण हुए और भोगों की कामना वाले पुरुष आवागमन (गतागत) को प्राप्त होते हैं।।",
   "en": "Yet, although they enjoy the spacious glories of Paradise, when their merit is exhausted, they are born again into this world of mortals. They have followed the letter of the scriptures, yet, because they have sought to fulfill their own desires, they must depart and return again and again.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "अनन्याश्चिन्तयन्तो मां ये जनाः पर्युपासते।\nतेषां नित्याभियुक्तानां योगक्षेमं वहाम्यहम्।।9.22।।",
   "tr": "ananyāśh chintayanto māṁ ye janāḥ paryupāsate\nteṣhāṁ nityābhiyuktānāṁ yoga-kṣhemaṁ vahāmyaham",
   "hi": "अनन्य भाव से मेरा चिन्तन करते हुए जो भक्तजन मेरी ही उपासना करते हैं, उन नित्ययुक्त पुरुषों का योगक्षेम मैं वहन करता हूँ।।",
   "en": "But if a person meditates on Me and Me alone, worships Me always and everywhere, I will take upon Myself the fulfillment of their aspiration, and I will safeguard whatever they attain.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "येऽप्यन्यदेवता भक्ता यजन्ते श्रद्धयाऽन्विताः।\nतेऽपि मामेव कौन्तेय यजन्त्यविधिपूर्वकम्।।9.23।।",
   "tr": "ye ’pyanya-devatā-bhaktā yajante śhraddhayānvitāḥ\nte ’pi mām eva kaunteya yajantyavidhi-pūrvakam",
   "hi": "हे कौन्तेय ! श्रद्धा से युक्त जो भक्त अन्य देवताओं को पूजते हैं, वे भी मुझे ही अविधिपूर्वक पूजते हैं।।",
   "en": "Even those who worship the lesser powers, if they do so with faith, they are thereby worshipping Me, though not in the correct manner.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "अहं हि सर्वयज्ञानां भोक्ता च प्रभुरेव च।\nन तु मामभिजानन्ति तत्त्वेनातश्च्यवन्ति ते।।9.24।।",
   "tr": "ahaṁ hi sarva-yajñānāṁ bhoktā cha prabhureva cha\nna tu mām abhijānanti tattvenātaśh chyavanti te",
   "hi": "क्योंकि सब यज्ञों का भोक्ता और स्वामी मैं ही हूँ, परन्तु वे मुझे तत्त्वत: नहीं जानते हैं, इसलिए वे गिरते हैं, अर्थात् संसार को प्राप्त होते हैं।।",
   "en": "I am the willing recipient of sacrifice, and I am its true Lord. But they do not know me truly, so they fall back.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "यान्ति देवव्रता देवान् पितृ़न्यान्ति पितृव्रताः।\nभूतानि यान्ति भूतेज्या यान्ति मद्याजिनोऽपि माम्।।9.25।।",
   "tr": "yānti deva-vratā devān pitṝīn yānti pitṛi-vratāḥ\nbhūtāni yānti bhūtejyā yānti mad-yājino ’pi mām",
   "hi": "देवताओं के पूजक देवताओं को प्राप्त होते हैं, पितरपूजक पितरों को जाते हैं, भूतों का यजन करने वाले भूतों को प्राप्त होते हैं और मुझे पूजने वाले भक्त मुझे ही प्राप्त होते हैं।।",
   "en": "The votaries of the lesser powers go to them; the devotees of spirits go to them; they who worship the powers of darkness, to such powers shall they go; and so too, those who worship me shall come to me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "पत्रं पुष्पं फलं तोयं यो मे भक्त्या प्रयच्छति।\nतदहं भक्त्युपहृतमश्नामि प्रयतात्मनः।।9.26।।",
   "tr": "patraṁ puṣhpaṁ phalaṁ toyaṁ yo me bhaktyā prayachchhati\ntadahaṁ bhaktyupahṛitam aśhnāmi prayatātmanaḥ",
   "hi": "जो कोई भी भक्त मेरे लिए पत्र, पुष्प, फल, जल आदि भक्ति से अर्पण करता है, उस शुद्ध मन के भक्त का वह भक्तिपूर्वक अर्पण किया हुआ (पत्र पुष्पादि) मैं भोगता हूँ अर्थात् स्वीकार करता हूँ।।",
   "en": "Whatever a person offers to Me, be it a leaf, flower, fruit, or water, I accept it, for it is offered with devotion and a pure mind.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "यत्करोषि यदश्नासि यज्जुहोषि ददासि यत्।\nयत्तपस्यसि कौन्तेय तत्कुरुष्व मदर्पणम्।।9.27।।",
   "tr": "yat karoṣhi yad aśhnāsi yaj juhoṣhi dadāsi yat\nyat tapasyasi kaunteya tat kuruṣhva mad-arpaṇam",
   "hi": "हे कौन्तेय ! तुम जो कुछ कर्म करते हो, जो कुछ खाते हो, जो कुछ हवन करते हो, जो कुछ दान देते हो और जो कुछ तप करते हो, वह सब तुम मुझे अर्पण करो।।",
   "en": "Whatever you do, whatever you eat, whatever you sacrifice and give, whatever austerities you practice, do all as an offering to Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "शुभाशुभफलैरेवं मोक्ष्यसे कर्मबन्धनैः।\nसंन्यासयोगयुक्तात्मा विमुक्तो मामुपैष्यसि।।9.28।।",
   "tr": "śhubhāśhubha-phalair evaṁ mokṣhyase karma-bandhanaiḥ\nsannyāsa-yoga-yuktātmā vimukto mām upaiṣhyasi",
   "hi": "इस प्रकार तुम शुभाशुभ फलस्वरूप कर्मबन्धनों से मुक्त हो जाओगे; और संन्यासयोग से युक्तचित्त हुए तुम विमुक्त होकर मुझे ही प्राप्त हो जाओगे।।",
   "en": "So, your action will have no result, either good or bad; but, through the spirit of renunciation, you will come to Me and be free.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "समोऽहं सर्वभूतेषु न मे द्वेष्योऽस्ति न प्रियः।\nये भजन्ति तु मां भक्त्या मयि ते तेषु चाप्यहम्।।9.29।।",
   "tr": "samo ’haṁ sarva-bhūteṣhu na me dveṣhyo ’sti na priyaḥ\nye bhajanti tu māṁ bhaktyā mayi te teṣhu chāpyaham",
   "hi": "मैं समस्त भूतों में सम हूँ; न कोई मुझे अप्रिय है और न प्रिय; परन्तु जो मुझे भक्तिपूर्वक भजते हैं, वे मुझमें और मैं भी उनमें हूँ।।",
   "en": "I am the same to all beings; I do not favour any, nor do I hate any. However, those who worship Me devotedly, they live in Me and I in them.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 30,
   "sa": "अपि चेत्सुदुराचारो भजते मामनन्यभाक्।\nसाधुरेव स मन्तव्यः सम्यग्व्यवसितो हि सः।।9.30।।",
   "tr": "api chet su-durāchāro bhajate mām ananya-bhāk\nsādhur eva sa mantavyaḥ samyag vyavasito hi saḥ",
   "hi": "यदि कोई अतिशय दुराचारी भी अनन्यभाव से मेरा भक्त होकर मुझे भजता है, वह साधु ही मानने योग्य है, क्योंकि वह यथार्थ निश्चय वाला है।।",
   "en": "Even the most sinful, if he worships Me with his whole heart, shall be considered righteous, for he is treading the right path.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 31,
   "sa": "क्षिप्रं भवति धर्मात्मा शश्वच्छान्तिं निगच्छति।\nकौन्तेय प्रतिजानीहि न मे भक्तः प्रणश्यति।।9.31।।",
   "tr": "kṣhipraṁ bhavati dharmātmā śhaśhvach-chhāntiṁ nigachchhati\nkaunteya pratijānīhi na me bhaktaḥ praṇaśhyati",
   "hi": "हे कौन्तेय, वह शीघ्र ही धर्मात्मा बन जाता है और शाश्वत शान्ति को प्राप्त होता है। तुम निश्चयपूर्वक सत्य जानो कि मेरा भक्त कभी नष्ट नहीं होता।।",
   "en": "He will soon attain spirituality and eternal peace. O Arjuna! Believe me, my devotee is never lost.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 32,
   "sa": "मां हि पार्थ व्यपाश्रित्य येऽपि स्युः पापयोनयः।\nस्त्रियो वैश्यास्तथा शूद्रास्तेऽपि यान्ति परां गतिम्।।9.32।।",
   "tr": "māṁ hi pārtha vyapāśhritya ye ’pi syuḥ pāpa-yonayaḥ\nstriyo vaiśhyās tathā śhūdrās te ’pi yānti parāṁ gatim",
   "hi": "हे पार्थ ! स्त्री, वैश्य और शूद्र ये जो कोई पापयोनि वाले हों, वे भी मुझ पर आश्रित (मेरे शरण) होकर परम गति को प्राप्त होते हैं।।",
   "en": "Even the children of sinful parents, those miscalled the weaker sex, merchants, and laborers, if they make Me their refuge, they shall attain the highest.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 33,
   "sa": "किं पुनर्ब्राह्मणाः पुण्या भक्ता राजर्षयस्तथा।\nअनित्यमसुखं लोकमिमं प्राप्य भजस्व माम्।।9.33।।",
   "tr": "kiṁ punar brāhmaṇāḥ puṇyā bhaktā rājarṣhayas tathā\nanityam asukhaṁ lokam imaṁ prāpya bhajasva mām",
   "hi": "फिर क्या कहना है कि पुण्यशील ब्राह्मण और राजर्षि भक्तजन (परम गति को प्राप्त होते हैं); (इसलिए) इस अनित्य और सुखरहित लोक को प्राप्त होकर (अब) तुम भक्तिपूर्वक मेरी ही पूजा करो।।",
   "en": "What need is there, then, to mention the holy ministers of God, the devotees, and the saintly rulers? Therefore, do you, born in this changing and miserable world, also worship Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 34,
   "sa": "मन्मना भव मद्भक्तो मद्याजी मां नमस्कुरु।\nमामेवैष्यसि युक्त्वैवमात्मानं मत्परायणः।।9.34।।",
   "tr": "man-manā bhava mad-bhakto mad-yājī māṁ namaskuru\nmām evaiṣhyasi yuktvaivam ātmānaṁ mat-parāyaṇaḥ",
   "hi": "(तुम) मुझमें स्थिर मन वाले बनो; मेरे भक्त और मेरे पूजन करने वाले बनो; मुझे नमस्कार करो; इस प्रकार मत्परायण (अर्थात् मैं ही जिसका परम लक्ष्य हूँ ऐसे) होकर आत्मा को मुझसे युक्त करके तुम मुझे ही प्राप्त होओगे।।",
   "en": "Fix your mind on Me, devote yourself to Me, sacrifice for Me, surrender to Me, make Me the object of your aspirations, and you shall assuredly become one with Me, Who am your own Self.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
