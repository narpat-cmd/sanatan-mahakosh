// Bhagavad Gita adhyay 11 - Vishwaroopa Darshana Yoga (55 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch11"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 11,
 "title": "विश्वरूपदर्शनयोग",
 "illustration": "",
 "illustrationCaption": "Yoga through Beholding the Cosmic Form of God",
 "imageQuery": "Vishvarupa Krishna",
 "summaryHi": "भगवद गीता का ग्यारहवा अध्याय विश्वरूपदर्शनयोग है। इस अध्याय में, अर्जुन कृष्ण को अपने विश्व रूप को प्रकट करने का अनुरोध करते हैं जो की सारे विश्वों अथवा संपूर्ण अस्तित्व का स्त्रोत है। भगवान कृष्ण के शरीर में पूरी सृष्टि को देखने में सक्षम होने के लिए अर्जुन को दिव्य दृष्टि दी जाती है।",
 "summaryEn": "The eleventh chapter of the Bhagavad Gita is \"Vishwaroopa Darshana Yoga\". In this chapter, Arjuna requests Krishna to reveal His Universal Cosmic Form that encompasses all the universes, the entire existence. Arjuna is granted divine vision to be able to see the entirety of creation in the body of the Supreme Lord Krishna.",
 "verses": [
  {
   "n": 1,
   "sa": "अर्जुन उवाच\nमदनुग्रहाय परमं गुह्यमध्यात्मसंज्ञितम्।\nयत्त्वयोक्तं वचस्तेन मोहोऽयं विगतो मम।।11.1।।",
   "tr": "arjuna uvācha\nmad-anugrahāya paramaṁ guhyam adhyātma-sanjñitam\nyat tvayoktaṁ vachas tena moho ’yaṁ vigato mama",
   "hi": "अर्जुन ने कहा -- मुझ पर अनुग्रह करने के लिए जो परम गोपनीय, अध्यात्मविषयक वचन (उपदेश) आपके द्वारा कहा गया, उससे मेरा मोह दूर हो गया है।।",
   "en": "Arjuna said: My Lord! Your words concerning the Supreme Secret of Self, given for my blessing, have dispelled the illusions that surrounded me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "भवाप्ययौ हि भूतानां श्रुतौ विस्तरशो मया।\nत्वत्तः कमलपत्राक्ष माहात्म्यमपि चाव्ययम्।।11.2।।",
   "tr": "bhavāpyayau hi bhūtānāṁ śhrutau vistaraśho mayā\ntvattaḥ kamala-patrākṣha māhātmyam api chāvyayam",
   "hi": "हे कमलनयन ! मैंने भूतों की उत्पत्ति और प्रलय आपसे विस्तारपूर्वक सुने हैं तथा आपका अव्यय माहात्म्य (प्रभाव) भी सुना है।।",
   "en": "O Lord, whose eyes are like the lotus petal! You have described in detail the origin and dissolution of beings, and Your own Eternal Majesty.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "एवमेतद्यथात्थ त्वमात्मानं परमेश्वर।\nद्रष्टुमिच्छामि ते रूपमैश्वरं पुरुषोत्तम।।11.3।।",
   "tr": "evam etad yathāttha tvam ātmānaṁ parameśhvara\ndraṣhṭum ichchhāmi te rūpam aiśhwaraṁ puruṣhottama",
   "hi": "हे परमेश्वर ! आप अपने को जैसा कहते हो, यह ठीक ऐसा ही है। (परन्तु) हे पुरुषोत्तम ! मैं आपके ईश्वरीय रूप को प्रत्यक्ष देखना चाहता हूँ।।",
   "en": "I believe all as you have declared it. I now long to have a vision of your divine form, O Most High!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "मन्यसे यदि तच्छक्यं मया द्रष्टुमिति प्रभो।\nयोगेश्वर ततो मे त्वं दर्शयाऽत्मानमव्ययम्।।11.4।।",
   "tr": "manyase yadi tach chhakyaṁ mayā draṣhṭum iti prabho\nyogeśhvara tato me tvaṁ darśhayātmānam avyayam",
   "hi": "हे प्रभो ! यदि आप मानते हैं कि मेरे द्वारा वह आपका रूप देखा जाना संभव है, तो हे योगेश्वर ! आप अपने अव्यय रूप का दर्शन कराइये।।",
   "en": "If you think it is possible for me to see it, show me, O Lord of Lords, your eternal self.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "श्री भगवानुवाच\nपश्य मे पार्थ रूपाणि शतशोऽथ सहस्रशः।\nनानाविधानि दिव्यानि नानावर्णाकृतीनि च।।11.5।।",
   "tr": "śhrī-bhagavān uvācha\npaśhya me pārtha rūpāṇi śhataśho ’tha sahasraśhaḥ\nnānā-vidhāni divyāni nānā-varṇākṛitīni cha",
   "hi": "श्रीभगवान् ने कहा -- हे पार्थ ! मेरे सैकड़ों तथा सहस्रों नाना प्रकार के और नाना वर्ण तथा आकृति वाले दिव्य रूपों को देखो।।",
   "en": "Lord Shri Krishna replied: \"Behold, O Arjuna! My celestial forms, by the hundreds and thousands, various in kind, color, and shape.\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "पश्यादित्यान्वसून्रुद्रानश्िवनौ मरुतस्तथा।\nबहून्यदृष्टपूर्वाणि पश्याऽश्चर्याणि भारत।।11.6।।",
   "tr": "paśhyādityān vasūn rudrān aśhvinau marutas tathā\nbahūny adṛiṣhṭa-pūrvāṇi paśhyāśhcharyāṇi bhārata",
   "hi": "हे भारत ! (मुझमें) आदित्यों, वसुओं, रुद्रों तथा अश्विनीकुमारों और मरुद्गणों को देखो, तथा और भी अनेक इसके पूर्व कभी न देखे हुए आश्चर्यों को देखो।।",
   "en": "Behold, thou seest the powers of Nature: fire, earth, wind, and sky; the sun, the heavens, the moon, the stars; all forces of vitality and healing; and the roving winds. Behold, thou seest the myriad wonders revealed to none but thee.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "इहैकस्थं जगत्कृत्स्नं पश्याद्य सचराचरम्।\nमम देहे गुडाकेश यच्चान्यद्द्रष्टुमिच्छसि।।11.7।।",
   "tr": "ihaika-sthaṁ jagat kṛitsnaṁ paśhyādya sa-charācharam\nmama dehe guḍākeśha yach chānyad draṣhṭum ichchhasi",
   "hi": "हे गुडाकेश ! आज (अब) इस मेरे शरीर में एक स्थान पर स्थित हुए चराचर सहित सम्पूर्ण जगत् को देखो तथा और भी जो कुछ तुम देखना चाहते हो, उसे भी देखो।।",
   "en": "Here, living in Me, O Arjuna, behold the entire universe, both movable and immovable, and anything else you would like to see!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "न तु मां शक्यसे द्रष्टुमनेनैव स्वचक्षुषा।\nदिव्यं ददामि ते चक्षुः पश्य मे योगमैश्वरम्।।11.8।।",
   "tr": "na tu māṁ śhakyase draṣhṭum anenaiva sva-chakṣhuṣhā\ndivyaṁ dadāmi te chakṣhuḥ paśhya me yogam aiśhwaram",
   "hi": "परन्तु तुम अपने इन्हीं (प्राकृत) नेत्रों के द्वारा मुझे देखने में समर्थ नहीं हो; (इसलिए) मैं तुम्हें दिव्यचक्षु देता हूँ, जिससे तुम मेरे ईश्वरीय 'योग' को देखो।।",
   "en": "Yet, since you cannot see Me with mortal eyes, behold, I give you divine sight. Now, see the glory of My sovereignty.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "सञ्जय उवाच\nएवमुक्त्वा ततो राजन्महायोगेश्वरो हरिः।\nदर्शयामास पार्थाय परमं रूपमैश्वरम्।।11.9।।",
   "tr": "sañjaya uvācha\nevam uktvā tato rājan mahā-yogeśhvaro hariḥ\ndarśhayām āsa pārthāya paramaṁ rūpam aiśhwaram",
   "hi": "संजय ने कहा -- हे राजन् ! महायोगेश्वर हरि ने इस प्रकार कहकर फिर अर्जुन के लिए परम ऐश्वर्ययुक्त रूप को दर्शाया।।",
   "en": "Sanjaya continued: \"Having thus spoken, O King, the Lord Shri Krishna, the Almighty Prince of Wisdom, showed Arjuna the Supreme Form of the Great God.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "अनेकवक्त्रनयनमनेकाद्भुतदर्शनम्।\nअनेकदिव्याभरणं दिव्यानेकोद्यतायुधम्।।11.10।।",
   "tr": "aneka-vaktra-nayanam anekādbhuta-darśhanam\naneka-divyābharaṇaṁ divyānekodyatāyudham",
   "hi": "उस अनेक मुख और नेत्रों से युक्त तथा अनेक अद्भुत दर्शनों वाले एवं बहुत से दिव्य भूषणों से युक्त और बहुत से दिव्य शस्त्रों को हाथों में उठाये हुये।।",
   "en": "There were countless eyes, mouths, and innumerable mystic forms, with shining ornaments and flaming celestial weapons.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "दिव्यमाल्याम्बरधरं दिव्यगन्धानुलेपनम्।\nसर्वाश्चर्यमयं देवमनन्तं विश्वतोमुखम्।।11.11।।",
   "tr": "divya-mālyāmbara-dharaṁ divya-gandhānulepanam\nsarvāśhcharya-mayaṁ devam anantaṁ viśhvato-mukham",
   "hi": "दिव्य माला और वस्त्रों को धारण किये हुये और दिव्य गन्ध का लेपन किये हुये एवं समस्त प्रकार के आश्चर्यों से युक्त अनन्त, विश्वतोमुख (विराट् स्वरूप) परम देव (को अर्जुन ने देखा)।।",
   "en": "Crowned with heavenly garlands, clothed in shining garments, anointed with divine unguents, He showed Himself as the Resplendent One, Marvelous, Boundless, and Omnipresent.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "दिवि सूर्यसहस्रस्य भवेद्युगपदुत्थिता।\nयदि भाः सदृशी सा स्याद्भासस्तस्य महात्मनः।।11.12।।",
   "tr": "divi sūrya-sahasrasya bhaved yugapad utthitā\nyadi bhāḥ sadṛiśhī sā syād bhāsas tasya mahātmanaḥ",
   "hi": "आकाश में सहस्र सूर्यों के एक साथ उदय होने से उत्पन्न जो प्रकाश होगा, वह उस (विश्वरूप) परमात्मा के प्रकाश के सदृश होगा।।",
   "en": "Could a thousand suns blaze forth together, it would be but a faint reflection of the radiance of the Lord God.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "तत्रैकस्थं जगत्कृत्स्नं प्रविभक्तमनेकधा।\nअपश्यद्देवदेवस्य शरीरे पाण्डवस्तदा।।11.13।।",
   "tr": "tatraika-sthaṁ jagat kṛitsnaṁ pravibhaktam anekadhā\napaśhyad deva-devasya śharīre pāṇḍavas tadā",
   "hi": "पाण्डुपुत्र अर्जुन ने उस समय अनेक प्रकार से विभक्त हुए सम्पूर्ण जगत् को देवों के देव श्रीकृष्ण के शरीर में एक स्थान पर स्थित देखा।।",
   "en": "In that vision, Arjuna saw the universe, with its manifold shapes, all embraced in one, its Supreme Lord.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "ततः स विस्मयाविष्टो हृष्टरोमा धनञ्जयः।\nप्रणम्य शिरसा देवं कृताञ्जलिरभाषत।।11.14।।",
   "tr": "tataḥ sa vismayāviṣhṭo hṛiṣhṭa-romā dhanañjayaḥ\npraṇamya śhirasā devaṁ kṛitāñjalir abhāṣhata",
   "hi": "उसके उपरान्त वह आश्चर्यचकित हुआ हर्षित रोमों वाला (जिसे रोमांच का अनुभव हो रहा हो) धनंजय अर्जुन विश्वरूप देव को (श्रद्धा भक्ति सहित) शिर से प्रणाम करके हाथ जोड़कर बोला।।",
   "en": "Then, Arjuna, filled with awe, his hair standing on end, bowing his head, and clasping his hands in reverence, spoke to the Lord:",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "अर्जुन उवाच\nपश्यामि देवांस्तव देव देहे\nसर्वांस्तथा भूतविशेषसङ्घान्।\nब्रह्माणमीशं कमलासनस्थ\nमृषींश्च सर्वानुरगांश्च दिव्यान्।।11.15।।",
   "tr": "arjuna uvācha\npaśhyāmi devāns tava deva dehe\nsarvāns tathā bhūta-viśheṣha-saṅghān\nbrahmāṇam īśhaṁ kamalāsana-stham\nṛiṣhīnśh cha sarvān uragānśh cha divyān",
   "hi": "अर्जुन ने कहा -- हे देव! मैं आपके शरीर में समस्त देवों को तथा अनेक भूतविशेषों के समुदायों को और कमलासन पर स्थित सृष्टि के स्वामी ब्रह्माजी को, ऋषियों को और दिव्य सर्पों को देख रहा हूँ।।",
   "en": "Arjuna said: O Almighty God! I see in You the powers of Nature, the various creatures of the world, the Progenitor on His lotus throne, the Sages, and the shining angels.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "अनेकबाहूदरवक्त्रनेत्रं\nपश्यामि त्वां सर्वतोऽनन्तरूपम्।\nनान्तं न मध्यं न पुनस्तवादिं\nपश्यामि विश्वेश्वर विश्वरूप।।11.16।।",
   "tr": "aneka-bāhūdara-vaktra-netraṁ\npaśhyāmi tvāṁ sarvato ’nanta-rūpam\nnāntaṁ na madhyaṁ na punas tavādiṁ\npaśhyāmi viśhveśhvara viśhva-rūpa",
   "hi": "हे विश्वेश्वर! मैं आपकी अनेक बाहु, उदर, मुख और नेत्रों से युक्त तथा सब ओर से अनन्त रूपों वाला देखता हूँ। हे विश्वरूप! मैं आपके न अन्त को देखता हूँ और न मध्य को और न आदि को।।",
   "en": "I see You, infinite in form, with faces, eyes, and limbs everywhere; with no beginning, middle, or end. O You, Lord of the Universe, whose form is universal!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "किरीटिनं गदिनं चक्रिणं च\nतेजोराशिं सर्वतोदीप्तिमन्तम्।\nपश्यामि त्वां दुर्निरीक्ष्यं समन्ता\nद्दीप्तानलार्कद्युतिमप्रमेयम्।।11.17।।",
   "tr": "kirīṭinaṁ gadinaṁ chakriṇaṁ cha\ntejo-rāśhiṁ sarvato dīptimantam\npaśhyāmi tvāṁ durnirīkṣhyaṁ samantād\ndīptānalārka-dyutim aprameyam",
   "hi": "मैं आपका मुकुटयुक्त, गदायुक्त और चक्रधारण किये हुये तथा सब ओर से प्रकाशमान् तेज का पुंज, दीप्त अग्नि और सूर्य के समान ज्योतिर्मय, देखने में अति कठिन और अप्रमेयस्वरूप सब ओर से देखता हूँ।।",
   "en": "I see you with the crown, the scepter, and the discus; a blaze of splendor. Scarcely can I gaze upon you, so radiant you are, glowing like a blazing fire, brilliant as the sun, immeasurable.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "त्वमक्षरं परमं वेदितव्यं\nत्वमस्य विश्वस्य परं निधानम्।\nत्वमव्ययः शाश्वतधर्मगोप्ता\nसनातनस्त्वं पुरुषो मतो मे।।11.18।।",
   "tr": "tvam akṣharaṁ paramaṁ veditavyaṁ\ntvam asya viśhvasya paraṁ nidhānam\ntvam avyayaḥ śhāśhvata-dharma-goptā\nsanātanas tvaṁ puruṣho mato me",
   "hi": "आप ही जानने योग्य (वेदितव्यम्) परम अक्षर हैं; आप ही इस विश्व के परम आश्रय (निधान) हैं ! आप ही शाश्वत धर्म के रक्षक हैं और आप ही सनातन पुरुष हैं,ऐसा मेरा मत है।।",
   "en": "You are imperishable, the only one worthy of being known, the priceless treasure-house of the universe, the immortal guardian of eternal life, and the everlasting spirit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "अनादिमध्यान्तमनन्तवीर्य\nमनन्तबाहुं शशिसूर्यनेत्रम्।\nपश्यामि त्वां दीप्तहुताशवक्त्रम्\nस्वतेजसा विश्वमिदं तपन्तम्।।11.19।।",
   "tr": "स्वतेजसा विश्वमिदं तपन्तम् || 19||",
   "hi": "मैं आपको आदि, अन्त और मध्य से रहित तथा अनंत सार्मथ्य से युक्त और अनंत बाहुओं वाला तथा चन्द्रसूर्यरूपी नेत्रों वाला और दीप्त अग्निरूपी मुख वाला तथा अपने तेज से इस विश्व को तपाते हुए देखता हूँ।।",
   "en": "Without beginning, without middle, and without end, infinite in power, with arms all-embracing, the sun and moon as Your eyes, Your face beaming with the fire of sacrifice, flooding the whole universe with light.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "द्यावापृथिव्योरिदमन्तरं हि\nव्याप्तं त्वयैकेन दिशश्च सर्वाः।\nदृष्ट्वाऽद्भुतं रूपमुग्रं तवेदं\nलोकत्रयं प्रव्यथितं महात्मन्।।11.20।।",
   "tr": "dyāv ā-pṛithivyor idam antaraṁ hi\nvyāptaṁ tvayaikena diśhaśh cha sarvāḥ\ndṛiṣhṭvādbhutaṁ rūpam ugraṁ tavedaṁ\nloka-trayaṁ pravyathitaṁ mahātman",
   "hi": "हे महात्मन् ! स्वर्ग और पृथ्वी के मध्य का यह आकाश तथा समस्त दिशाएं अकेले आप से ही व्याप्त हैं; आपके इस अद्भुत और उग्र रूप को देखकर तीनों लोक अतिव्यथा (भय) को प्राप्त हो रहे हैं।।",
   "en": "Alone, you fill all the quarters of the sky, earth, and heaven, and the regions between. O Almighty Lord! Seeing your marvelous and awe-inspiring form, the spheres tremble with fear.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "अमी हि त्वां सुरसङ्घाः विशन्ति\nकेचिद्भीताः प्राञ्जलयो गृणन्ति।\nस्वस्तीत्युक्त्वा महर्षिसिद्धसङ्घाः\nस्तुवन्ति त्वां स्तुतिभिः पुष्कलाभिः।।11.21।।",
   "tr": "amī hi tvāṁ sura-saṅghā viśhanti\nkechid bhītāḥ prāñjalayo gṛiṇanti\nsvastīty uktvā maharṣhi-siddha-saṅghāḥ\nstuvanti tvāṁ stutibhiḥ puṣhkalābhiḥ",
   "hi": "ये समस्त देवताओं के समूह आप में ही प्रवेश कर रहे हैं और कई एक भयभीत होकर हाथ जोड़े हुए आप की स्तुति करते हैं; महर्षि और सिद्धों के समुदाय 'कल्याण होवे' (स्वस्तिवाचन करते हुए) ऐसा कहकर, उत्तम (या सम्पूर्ण) स्रोतों द्वारा आपकी स्तुति करते हैं।।",
   "en": "The troops of celestial beings enter into You, some invoking You in fear, with folded palms; the great seers and adepts sing hymns to Your glory, saying, \"All hail!\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "रुद्रादित्या वसवो ये च साध्या\nविश्वेऽश्िवनौ मरुतश्चोष्मपाश्च।\nगन्धर्वयक्षासुरसिद्धसङ्घा\nवीक्षन्ते त्वां विस्मिताश्चैव सर्वे।।11.22।।",
   "tr": "rudrādityā vasavo ye cha sādhyā\nviśhve ’śhvinau marutaśh choṣhmapāśh cha\ngandharva-yakṣhāsura-siddha-saṅghā\nvīkṣhante tvāṁ vismitāśh chaiva sarve",
   "hi": "रुद्रगण, आदित्य, वसु और साध्यगण, विश्वेदेव तथा दो अश्विनीकुमार, मरुद्गण और उष्मपा, गन्धर्व, यक्ष, असुर और सिद्धगणों के समुदाय- ये सब ही विस्मित होते हुए आपको देखते हैं।।",
   "en": "The vital forces, major stars, fire, earth, air, sky, sun, heaven, moon, and planets; the angels, guardians of the universe, divine healers, winds, fathers, heavenly singers, and hosts of mammon-worshippers, demons, and saints are all amazed.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "रूपं महत्ते बहुवक्त्रनेत्रं\nमहाबाहो बहुबाहूरुपादम्।\nबहूदरं बहुदंष्ट्राकरालं\nदृष्ट्वा लोकाः प्रव्यथितास्तथाऽहम्।।11.23।।",
   "tr": "rūpaṁ mahat te bahu-vaktra-netraṁ\nmahā-bāho bahu-bāhūru-pādam\nbahūdaraṁ bahu-danṣhṭrā-karālaṁ\ndṛiṣhṭvā lokāḥ pravyathitās tathāham",
   "hi": "हे महाबाहो! आपके बहुत मुख तथा नेत्र वाले, बहुत बाहु, उरु (जंघा) तथा पैरों वाले, बहुत-ंंसी उदरों वाले तथा बहुतसी विकराल दाढ़ों वाले महान् रूप को देखकर सब लोग व्यथित हो रहे हैं और उसी प्रकार मैं भी (व्याकुल हो रहा हूँ)।।",
   "en": "Seeing Thy stupendous Form, O Most Mighty One, with its myriad faces, its innumerable eyes, limbs, and terrible jaws, I myself and all the worlds are overwhelmed with awe.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "नभःस्पृशं दीप्तमनेकवर्णं\nव्यात्ताननं दीप्तविशालनेत्रम्।\nदृष्ट्वा हि त्वां प्रव्यथितान्तरात्मा\nधृतिं न विन्दामि शमं च विष्णो।।11.24।।",
   "tr": "nabhaḥ-spṛiśhaṁ dīptam aneka-varṇaṁ\nvyāttānanaṁ dīpta-viśhāla-netram\ndṛiṣhṭvā hi tvāṁ pravyathitāntar-ātmā\ndhṛitiṁ na vindāmi śhamaṁ cha viṣhṇo",
   "hi": "हे विष्णो! आकाश के साथ स्पर्श किये हुए देदीप्यमान अनेक रूपों से युक्त तथा विस्तरित मुख और प्रकाशमान विशाल नेत्रों से युक्त आपको देखकर भयभीत हुआ मैं धैर्य और शान्ति को नहीं प्राप्त हो रहा हूँ।।",
   "en": "When I see You, touching the heavens, glowing with color, with open mouth and wide, fiery eyes, I am terrified. O my Lord! My courage and peace of mind abandon me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "दंष्ट्राकरालानि च ते मुखानि\nदृष्ट्वैव कालानलसन्निभानि।\nदिशो न जाने न लभे च शर्म\nप्रसीद देवेश जगन्निवास।।11.25।।",
   "tr": "danṣhṭrā-karālāni cha te mukhāni\ndṛiṣhṭvaiva kālānala-sannibhāni\ndiśho na jāne na labhe cha śharma\nprasīda deveśha jagan-nivāsa",
   "hi": "आपके विकराल दाढ़ों वाले और प्रलयाग्नि के समान प्रज्वलित मुखों को देखकर, मैं न दिशाओं को जान पा रहा हूँ और न शान्ति को प्राप्त हो रहा हूँ; इसलिए हे देवेश! हे जगन्निवास! आप प्रसन्न हो जाइए।।",
   "en": "When I see Thy mouths with their fearful jaws, like glowing fires at the dissolution of creation, I lose all sense of place and find no rest. Be merciful, O Lord, in whom this universe abides!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "अमी च त्वां धृतराष्ट्रस्य पुत्राः\nसर्वे सहैवावनिपालसङ्घैः।\nभीष्मो द्रोणः सूतपुत्रस्तथाऽसौ\nसहास्मदीयैरपि योधमुख्यैः।।11.26।।",
   "tr": "amī cha tvāṁ dhṛitarāśhtrasya putrāḥ\nsarve sahaivāvani-pāla-saṅghaiḥ\nbhīṣhmo droṇaḥ sūta-putras tathāsau\nsahāsmadīyair api yodha-mukhyaiḥ\nvaktrāṇi te tvaramāṇā viśhanti\ndanṣhṭrā-karālāni bhayānakāni\nkechid vilagnā daśhanāntareṣhu\nsandṛiśhyante chūrṇitair uttamāṅgaiḥ",
   "hi": "और ये समस्त धृतराष्ट्र के पुत्र राजाओं के समुदाय सहित आप में प्रवेश करते हैं। भीष्म, द्रोण तथा कर्ण और हमारे पक्ष के भी प्रधान योद्धाओं के सहित.।।",
   "en": "All these sons of Dhritarashtra, along with the hosts of princes, Bheeshma, Drona, and Karna, as well as the other warrior chiefs on our side;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "वक्त्राणि ते त्वरमाणा विशन्ति\nदंष्ट्राकरालानि भयानकानि।\nकेचिद्विलग्ना दशनान्तरेषु\nसंदृश्यन्ते चूर्णितैरुत्तमाङ्गैः।।11.27।।",
   "tr": "vaktrāṇi te  tvaramāṇā   viśanti daṁṣṭrā-karālāni    bhayānakāni kecid   vilagnā daśanāntareṣu   sandṛśyante cūrṇitair   uttamāṅgaiḥ",
   "hi": "तीव्र वेग से आपके विकराल दाढ़ों वाले भयानक मुखों में प्रवेश करते हैं और कई एक चूर्णित शिरों सहित आपके दांतों के बीच में फँसे हुए दिख रहे हैं।।",
   "en": "1\tSee them all rushing headlong into Thy mouths, with terrible tusks, horrible to behold. Some are mangled between Thy jaws, with their heads crushed to atoms.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "यथा नदीनां बहवोऽम्बुवेगाः\nसमुद्रमेवाभिमुखाः द्रवन्ति।\nतथा तवामी नरलोकवीरा\nविशन्ति वक्त्राण्यभिविज्वलन्ति।।11.28।।",
   "tr": "yathā nadīnāṁ bahavo ’mbu-vegāḥ\nsamudram evābhimukhā dravanti\ntathā tavāmī nara-loka-vīrā\nviśhanti vaktrāṇy abhivijvalanti",
   "hi": "जैसे नदियों के बहुत से जलप्रवाह समुद्र की ओर वेग से बहते हैं, वैसे ही मनुष्यलोक के ये वीर योद्धागण आपके प्रज्वलित मुखों में प्रवेश करते हैं।।",
   "en": "As rivers in flood surge furiously towards the ocean, so these heroes, the greatest among men, fling themselves into Thy flaming mouths.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "यथा प्रदीप्तं ज्वलनं पतङ्गा\nविशन्ति नाशाय समृद्धवेगाः।\nतथैव नाशाय विशन्ति लोका\nस्तवापि वक्त्राणि समृद्धवेगाः।।11.29।।",
   "tr": "yathā pradīptaṁ jvalanaṁ pataṅgā\nviśhanti nāśhāya samṛiddha-vegāḥ\ntathaiva nāśhāya viśhanti lokās\ntavāpi vaktrāṇi samṛiddha-vegāḥ",
   "hi": "जैसे पतंगे अपने नाश के लिए प्रज्वलित अग्नि में अतिवेग से प्रवेश करते हैं, वैसे ही ये लोग भी अपने नाश के लिए आपके मुखों में अतिवेग से प्रवेश करते हैं।।",
   "en": "As moths impetuously fly towards the flame, only to be killed, so these men rush into Your mouths to court their own destruction.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 30,
   "sa": "लेलिह्यसे ग्रसमानः समन्ता\nल्लोकान्समग्रान्वदनैर्ज्वलद्भिः।\nतेजोभिरापूर्य जगत्समग्रं\nभासस्तवोग्राः प्रतपन्ति विष्णो।।11.30।।",
   "tr": "lelihyase grasamānaḥ samantāl\nlokān samagrān vadanair jvaladbhiḥ\ntejobhir āpūrya jagat samagraṁ\nbhāsas tavogrāḥ pratapanti viṣhṇo",
   "hi": "हे विष्णो! आप प्रज्वलित मुखों के द्वारा इन समस्त लोकों का ग्रसन करते हुए आस्वाद ले रहे हैं, आपका उग्र प्रकाश सम्पूर्ण जगत् को तेज के द्वारा परिपूर्ण करके तपा रहा है।।",
   "en": "You seem to swallow up the worlds, lapping them in flame. Your glory fills the universe. Your fierce rays beat down upon it irresistibly.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 31,
   "sa": "आख्याहि मे को भवानुग्ररूपो\nनमोऽस्तु ते देववर प्रसीद।\nविज्ञातुमिच्छामि भवन्तमाद्यं\nन हि प्रजानामि तव प्रवृत्तिम्।।11.31।।",
   "tr": "ākhyāhi me ko bhavān ugra-rūpo\nnamo ’stu te deva-vara prasīda\nvijñātum ichchhāmi bhavantam ādyaṁ\nna hi prajānāmi tava pravṛittim",
   "hi": "(कृपया) मेरे प्रति कहिये, कि उग्ररूप वाले आप कौन हैं? हे देवों में श्रेष्ठ! आपको नमस्कार है, आप प्रसन्न होइये। आदि स्वरूप आपको मैं (तत्त्व से) जानना चाहता हूँ, क्योंकि आपकी प्रवृत्ति (अर्थात् प्रयोजन को) को मैं नहीं समझ पा रहा हूँ।।",
   "en": "Tell me then, who are You, who wears this dreadful form? I bow before You, O Mighty One! Have mercy, I pray, and let me see You as You were at first. I do not know what Your intentions are.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 32,
   "sa": "श्री भगवानुवाच\nकालोऽस्मि लोकक्षयकृत्प्रवृद्धो\nलोकान्समाहर्तुमिह प्रवृत्तः।\nऋतेऽपि त्वां न भविष्यन्ति सर्वे\nयेऽवस्थिताः प्रत्यनीकेषु योधाः।।11.32।।",
   "tr": "śhrī-bhagavān uvācha\nkālo ’smi loka-kṣhaya-kṛit pravṛiddho\nlokān samāhartum iha pravṛittaḥ\nṛite ’pi tvāṁ na bhaviṣhyanti sarve\nye ’vasthitāḥ pratyanīkeṣhu yodhāḥ",
   "hi": "श्रीभगवान् ने कहा -- मैं लोकों का नाश करने वाला प्रवृद्ध काल हूँ। इस समय, मैं इन लोकों का संहार करने में प्रवृत्त हूँ। जो प्रतिपक्षियों की सेना में स्थित योद्धा हैं, वे सब तुम्हारे बिना भी नहीं रहेंगे।।",
   "en": "Lord Shri Krishna replied: I have shown myself to you as the Destroyer who lays waste the world and whose purpose is destruction. In spite of your efforts, all these warriors gathered for battle shall not escape death.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 33,
   "sa": "तस्मात्त्वमुत्तिष्ठ यशो लभस्व\nजित्वा शत्रून् भुङ्क्ष्व राज्यं समृद्धम्।\nमयैवैते निहताः पूर्वमेव\nनिमित्तमात्रं भव सव्यसाचिन्।।11.33।।",
   "tr": "tasmāt tvam uttiṣhṭha yaśho labhasva\njitvā śhatrūn bhuṅkṣhva rājyaṁ samṛiddham\nmayaivaite nihatāḥ pūrvam eva\nnimitta-mātraṁ bhava savya-sāchin",
   "hi": "इसलिए तुम उठ खड़े हो जाओ और यश को प्राप्त करो; शत्रुओं को जीतकर समृद्ध राज्य को भोगो। ये सब पहले से ही मेरे द्वारा मारे जा चुके हैं। हे सव्यसाचिन्! तुम केवल निमित्त ही बनो।।",
   "en": "Then gird up your loins and conquer. Subdue your foes and enjoy the kingdom in prosperity. I have already doomed them. Be thou my instrument, Arjuna!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 34,
   "sa": "द्रोणं च भीष्मं च जयद्रथं च\nकर्णं तथाऽन्यानपि योधवीरान्।\nमया हतांस्त्वं जहि मा व्यथिष्ठा\nयुध्यस्व जेतासि रणे सपत्नान्।।11.34।।",
   "tr": "droṇaṁ cha bhīṣhmaṁ cha jayadrathaṁ cha\nkarṇaṁ tathānyān api yodha-vīrān\nmayā hatāṁs tvaṁ jahi mā vyathiṣhṭhā\nyudhyasva jetāsi raṇe sapatnān",
   "hi": "द्रोण, भीष्म, जयद्रथ, कर्ण तथा और भी बहुत से मेरे द्वारा मारे गये वीर योद्धाओं को तुम मारो; भय मत करो; युद्ध करो; तुम युद्ध में शत्रुओं को जीतोगे।।",
   "en": "Drona, Bheeshma, Jayadratha, Karna, and other brave warriors - I have condemned them all. Destroy them; fight without fear. Your foes shall be crushed.\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 35,
   "sa": "सञ्जय उवाच\nएतच्छ्रुत्वा वचनं केशवस्य\nकृताञ्जलिर्वेपमानः किरीटी।\nनमस्कृत्वा भूय एवाह कृष्णं\nसगद्गदं भीतभीतः प्रणम्य।।11.35।।",
   "tr": "sañjaya uvācha\netach chhrutvā vachanaṁ keśhavasya\nkṛitāñjalir vepamānaḥ kirīṭī\nnamaskṛitvā bhūya evāha kṛiṣhṇaṁ\nsa-gadgadaṁ bhīta-bhītaḥ praṇamya",
   "hi": "संजय ने कहा -- केशव भगवान् के इस वचन को सुनकर मुकुटधारी अर्जुन हाथ जोड़े हुए, कांपता हुआ नमस्कार करके पुन: भयभीत हुआ श्रीकृष्ण के प्रति गद्गद् वाणी से बोला।।",
   "en": "Sanjaya continued: \"Having heard these words from the Lord Shri Krishna, the Prince Arjuna, with folded hands trembling, prostrated himself and with a choked voice, bowing down again and again, and overwhelmed with awe, once more addressed the Lord.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 36,
   "sa": "अर्जुन उवाच\nस्थाने हृषीकेश तव प्रकीर्त्या\nजगत् प्रहृष्यत्यनुरज्यते च।\nरक्षांसि भीतानि दिशो द्रवन्ति\nसर्वे नमस्यन्ति च सिद्धसङ्घाः।।11.36।।",
   "tr": "arjuna uvācha\nsthāne hṛiṣhīkeśha tava prakīrtyā\njagat prahṛiṣhyaty anurajyate cha\nrakṣhānsi bhītāni diśho dravanti\nsarve namasyanti cha siddha-saṅghāḥ",
   "hi": "अर्जुन ने कहा -- यह योग्य ही है कि आपके कीर्तन से जगत् अति हर्षित होता है और अनुराग को भी प्राप्त होता है। भयभीत राक्षस लोग समस्त दिशाओं में भागते हैं और समस्त सिद्धगणों के समुदाय आपको नमस्कार करते हैं।।",
   "en": "Arjuna said: My Lord! It is natural for the world to revel and rejoice when singing praises of Your glory; the demons fly in fear and the saints offer You their salutations.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 37,
   "sa": "कस्माच्च ते न नमेरन्महात्मन्\nगरीयसे ब्रह्मणोऽप्यादिकर्त्रे।\nअनन्त देवेश जगन्निवास\nत्वमक्षरं सदसत्तत्परं यत्।।11.37।।",
   "tr": "kasmāch cha te na nameran mahātman\ngarīyase brahmaṇo ’py ādi-kartre\nananta deveśha jagan-nivāsa\ntvam akṣharaṁ sad-asat tat paraṁ yat",
   "hi": "हे महात्मन् ! ब्रह्मा के भी आदि कर्ता और सबसे श्रेष्ठ आपके लिए वे कैसे नमस्कार नहीं करें? (क्योंकि) हे अनन्त! हे देवेश! हे जगन्निवास! जो सत् असत् और इन दोनों से परे अक्षरतत्त्व है, वह आप ही हैं।।",
   "en": "How else should they do? O Supreme Self, greater than the powers of creation, the first cause, infinite, the Lord of Lords, the home of the universe, imperishable, being and non-being, yet transcending both.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 38,
   "sa": "त्वमादिदेवः पुरुषः पुराण\nस्त्वमस्य विश्वस्य परं निधानम्।\nवेत्तासि वेद्यं च परं च धाम\nत्वया ततं विश्वमनन्तरूप।।11.38।।",
   "tr": "tvam ādi-devaḥ puruṣhaḥ purāṇas\ntvam asya viśhvasya paraṁ nidhānam\nvettāsi vedyaṁ cha paraṁ cha dhāma\ntvayā tataṁ viśhvam ananta-rūpa",
   "hi": "आप आदिदेव और पुराण (सनातन) पुरुष हैं। आप इस जगत् के परम आश्रय, ज्ञाता, ज्ञेय, (जानने योग्य) और परम धाम हैं। हे अनन्तरूप आपसे ही यह विश्व व्याप्त है।।",
   "en": "You are the Primal God, the Ancient One, the Supreme Abode of this universe, the Knower, the Knowledge, and the Final Home. You fill everything. Your form is infinite.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 39,
   "sa": "वायुर्यमोऽग्निर्वरुणः शशाङ्कः\nप्रजापतिस्त्वं प्रपितामहश्च।\nनमो नमस्तेऽस्तु सहस्रकृत्वः\nपुनश्च भूयोऽपि नमो नमस्ते।।11.39।।",
   "tr": "vāyur yamo ’gnir varuṇaḥ śhaśhāṅkaḥ\nprajāpatis tvaṁ prapitāmahaśh cha\nnamo namas te ’stu sahasra-kṛitvaḥ\npunaśh cha bhūyo ’pi namo namas te",
   "hi": "आप वायु, यम, अग्नि, वरुण, चन्द्रमा, प्रजापति (ब्रह्मा) और प्रपितामह (ब्रह्मा के भी कारण) हैं; आपके लिए सहस्र बार नमस्कार, नमस्कार है, पुन: आपको बारम्बार नमस्कार, नमस्कार है।।",
   "en": "You are the wind, you are death, you are the fire, the water, the moon, the father, and the grandfather. Honor and glory to you a thousand and a thousand times! Again and again, salutations to you, O my Lord!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 40,
   "sa": "नमः पुरस्तादथ पृष्ठतस्ते\nनमोऽस्तु ते सर्वत एव सर्व।\nअनन्तवीर्यामितविक्रमस्त्वं\nसर्वं समाप्नोषि ततोऽसि सर्वः।।11.40।।",
   "tr": "namaḥ purastād atha pṛiṣhṭhatas te\nnamo ’stu te sarvata eva sarva\nananta-vīryāmita-vikramas tvaṁ\nsarvaṁ samāpnoṣhi tato ’si sarvaḥ",
   "hi": "हे अनन्तसार्मथ्य वाले भगवन्! आपके लिए अग्रत: और पृष्ठत: नमस्कार है, हे सर्वात्मन्! आपको सब ओर से नमस्कार है। आप अमित विक्रमशाली हैं और आप सबको व्याप्त किये हुए हैं, इससे आप सर्वरूप हैं।।",
   "en": "Salutations to Thee in front and on all sides, Thou who encompasseth me round about. Thy power is infinite; Thy majesty immeasurable; Thou upholdest all things; indeed, Thou Thyself art All.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 41,
   "sa": "सखेति मत्वा प्रसभं यदुक्तं\nहे कृष्ण हे यादव हे सखेति।\nअजानता महिमानं तवेदं\nमया प्रमादात्प्रणयेन वापि।।11.41।।",
   "tr": "sakheti matvā prasabhaṁ yad uktaṁ\nhe kṛiṣhṇa he yādava he sakheti\najānatā mahimānaṁ tavedaṁ\nmayā pramādāt praṇayena vāpi",
   "hi": "हे भगवन्! आपको सखा मानकर आपकी इस महिमा को न जानते हुए मेरे द्वारा प्रमाद से अथवा प्रेम से भी \"हे कृष्ण हे! यादव हे सखे!\" इस प्रकार जो कुछ बलात् कहा गया है।।",
   "en": "Whatever I have said to you in rashness, taking you only as a friend and addressing you as “O Krishna! O Yadava! O Friend!” in thoughtless familiarity, without understanding your greatness;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 42,
   "sa": "यच्चावहासार्थमसत्कृतोऽसि\nविहारशय्यासनभोजनेषु।\nएकोऽथवाप्यच्युत तत्समक्षं\nतत्क्षामये त्वामहमप्रमेयम्।।11.42।।",
   "tr": "yach chāvahāsārtham asat-kṛito ’si\nvihāra-śhayyāsana-bhojaneṣhu\neko ’tha vāpy achyuta tat-samakṣhaṁ\ntat kṣhāmaye tvām aham aprameyam",
   "hi": "और, हे अच्युत! जो आप मेरे द्वारा हँसी के लिये बिहार, शय्या, आसन और भोजन के समय अकेले में अथवा अन्यों के समक्ष भी अपमानित किये गये हैं, उन सब के लिए अप्रमेय स्वरूप आप से मैं क्षमायाचना करता हूँ।।",
   "en": "Whatever insults I have offered to You in jest, in sport, in repose, in conversation, or at a banquet, alone or in a crowd, I ask for Your forgiveness for them all, O You Who are without equal!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 43,
   "sa": "पितासि लोकस्य चराचरस्य\nत्वमस्य पूज्यश्च गुरुर्गरीयान्।\nन त्वत्समोऽस्त्यभ्यधिकः कुतोऽन्यो\nलोकत्रयेऽप्यप्रतिमप्रभाव।।11.43।।",
   "tr": "pitāsi lokasya charācharasya\ntvam asya pūjyaśh cha gurur garīyān\nna tvat-samo ’sty abhyadhikaḥ kuto ’nyo\nloka-traye ’py apratima-prabhāva",
   "hi": "आप इस चराचर जगत् के पिता, पूजनीय और सर्वश्रेष्ठ गुरु हैं। हे अप्रितम प्रभाव वाले भगवन्! तीनों लोकों में आपके समान भी कोई नहीं हैं, तो फिर आपसे अधिक श्रेष्ठ कैसे होगा?।।",
   "en": "For you are the Father of all things movable and immovable, the Worshipful, the Master of Masters! In all the worlds, there is none equal to you; how then could there be one superior, O you who stand alone, Supreme?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 44,
   "sa": "तस्मात्प्रणम्य प्रणिधाय कायं\nप्रसादये त्वामहमीशमीड्यम्।\nपितेव पुत्रस्य सखेव सख्युः\nप्रियः प्रियायार्हसि देव सोढुम्।।11.44।।",
   "tr": "tasmāt praṇamya praṇidhāya kāyaṁ\nprasādaye tvām aham īśham īḍyam\npiteva putrasya sakheva sakhyuḥ\npriyaḥ priyāyārhasi deva soḍhum",
   "hi": "इसलिये हे भगवन्! मैं शरीर के द्वारा साष्टांग प्रणिपात करके स्तुति के योग्य आप ईश्वर को प्रसन्न होने के लिये प्रार्थना करता हूँ। हे देव! जैसे पिता पुत्र के, मित्र अपने मित्र के और प्रिय अपनी प्रिया के(अपराध को क्षमा करता है), वैसे ही आप भी मेरे अपराधों को क्षमा कीजिये।।",
   "en": "Therefore, I prostrate myself before You, O Lord! Most Adorable! I salute You, and I ask for Your blessing. Only You can be trusted to bear with me, like a father to a son, like a friend to a friend, and like a lover to his beloved.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 45,
   "sa": "अदृष्टपूर्वं हृषितोऽस्मि दृष्ट्वा\nभयेन च प्रव्यथितं मनो मे।\nतदेव मे दर्शय देव रूपं\nप्रसीद देवेश जगन्निवास।।11.45।।",
   "tr": "adṛiṣhṭa-pūrvaṁ hṛiṣhito ’smi dṛiṣhṭvā\nbhayena cha pravyathitaṁ mano me\ntad eva me darśhaya deva rūpaṁ\nprasīda deveśha jagan-nivāsa",
   "hi": "मैं आपके इस अदृष्टपूर्व रूप को देखकर हर्षित हो रहा हूँ और मेरा मन भय से अतिव्याकुल भी हो रहा हैं। इसलिए हे देव! आप उस पूर्वकाल को ही मुझे दिखाइये। हे देवेश! हे जगन्निवास! आप प्रसन्न होइये।।",
   "en": "I rejoice that I have seen what no man has ever seen before; yet, O Lord! I am overwhelmed with fear. Please take on the form I know. Be merciful, O Lord! You who are the home of the entire universe.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 46,
   "sa": "किरीटिनं गदिनं चक्रहस्त\nमिच्छामि त्वां द्रष्टुमहं तथैव।\nतेनैव रूपेण चतुर्भुजेन\nसहस्रबाहो भव विश्वमूर्ते।।11.46।।",
   "tr": "kirīṭinaṁ gadinaṁ chakra-hastam\nichchhāmi tvāṁ draṣhṭum ahaṁ tathaiva\ntenaiva rūpeṇa chatur-bhujena\nsahasra-bāho bhava viśhva-mūrte",
   "hi": "मैं आपको उसी प्रकार मुकुटधारी, गदा और चक्र हाथ में लिए हुए देखना चाहता हूँ। हे विश्वमूर्ते! हे सहस्रबाहो! आप उस चतुर्भुजरूप के ही बन जाइए।।",
   "en": "I long to see Thee as Thou wert before, with the crown, the scepter, and the discus in Thy hands; in Thy other form, with Thy four hands, O Thou whose arms are countless and whose forms are infinite.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 47,
   "sa": "श्री भगवानुवाच\nमया प्रसन्नेन तवार्जुनेदं\nरूपं परं दर्शितमात्मयोगात्।\nतेजोमयं विश्वमनन्तमाद्यं\nयन्मे त्वदन्येन न दृष्टपूर्वम्।।11.47।।",
   "tr": "śhrī-bhagavān uvācha\nmayā prasannena tavārjunedaṁ\nrūpaṁ paraṁ darśhitam ātma-yogāt\ntejo-mayaṁ viśhvam anantam ādyaṁ\nyan me tvad anyena na dṛiṣhṭa-pūrvam",
   "hi": "हे अर्जुन! तुम पर प्रसन्न होकर मैंने अपनी योगशक्ति (आत्मयोगात्) के प्रभाव से यह अपना परम तेजोमय, सबका आदि और अनन्त विश्वरूप तुझे दर्शाया है, जिसे तुम्हारे पूर्व किसी ने नहीं देखा है।।",
   "en": "Lord Shri Krishna replied: My beloved friend! It is only through My grace and power that you have been able to see this vision of splendour, the Universal, the Infinite, the Original. Never has it been seen by anyone else.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 48,
   "sa": "न वेदयज्ञाध्ययनैर्न दानै\nर्न च क्रियाभिर्न तपोभिरुग्रैः।\nएवंरूपः शक्य अहं नृलोके\nद्रष्टुं त्वदन्येन कुरुप्रवीर।।11.48।।",
   "tr": "na veda-yajñādhyayanair na dānair\nna cha kriyābhir na tapobhir ugraiḥ\nevaṁ-rūpaḥ śhakya ahaṁ nṛi-loke\ndraṣhṭuṁ tvad anyena kuru-pravīra",
   "hi": "हे कुरुप्रवीर! तुम्हारे अतिरिक्त इस मनुष्य लोक में किसी अन्य के द्वारा मैं इस रूप में, न वेदाध्ययन और न यज्ञ, न दान और न (धार्मिक) क्रियायों के द्वारा और न उग्र तपों के द्वारा ही देखा जा सकता हूँ।।",
   "en": "It is not possible for man on earth to see what thou hast seen, O thou foremost hero of the Kuru-clan, through study of the scriptures, sacrifice or gift, ritual or rigorous austerity!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 49,
   "sa": "मा ते व्यथा मा च विमूढभावो\nदृष्ट्वा रूपं घोरमीदृङ्ममेदम्।\nव्यपेतभीः प्रीतमनाः पुनस्त्वं\nतदेव मे रूपमिदं प्रपश्य।।11.49।।",
   "tr": "mā te vyathā mā cha vimūḍha-bhāvo\ndṛiṣhṭvā rūpaṁ ghoram īdṛiṅ mamedam\nvyapeta-bhīḥ prīta-manāḥ punas tvaṁ\ntad eva me rūpam idaṁ prapaśhya",
   "hi": "इस प्रकार मेरे इस घोर रूप को देखकर तुम व्यथा और मूढ़भाव को मत प्राप्त हो। निर्भय और प्रसन्नचित्त होकर तुम पुन: मेरे उसी (पूर्व के) रूप को देखो।।",
   "en": "Do not be afraid or confused by the terrible vision. Put away your fear and, with a joyful mind, see Me again in My usual form.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 50,
   "sa": "सञ्जय उवाच\nइत्यर्जुनं वासुदेवस्तथोक्त्वा\nस्वकं रूपं दर्शयामास भूयः।\nआश्वासयामास च भीतमेनं\nभूत्वा पुनः सौम्यवपुर्महात्मा।।11.50।।",
   "tr": "sañjaya uvācha\nity arjunaṁ vāsudevas tathoktvā\nsvakaṁ rūpaṁ darśhayām āsa bhūyaḥ\nāśhvāsayām āsa cha bhītam enaṁ\nbhūtvā punaḥ saumya-vapur mahātmā",
   "hi": "संजय ने कहा -- भगवान् वासुदेव ने अर्जुन से इस प्रकार कहकर, पुन: अपने (पूर्व) रूप को दर्शाया, और फिर, सौम्यरूप महात्मा श्रीकृष्ण ने इस भयभीत अर्जुन को आश्वस्त किया।।",
   "en": "Sanjaya continued: \"Having thus spoken to Arjuna, Lord Shri Krishna showed Himself again in His accustomed form; and the Mighty Lord, in gentle tones, softly consoled him who had recently trembled with fear.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 51,
   "sa": "अर्जुन उवाच\nदृष्ट्वेदं मानुषं रूपं तवसौम्यं जनार्दन।\nइदानीमस्मि संवृत्तः सचेताः प्रकृतिं गतः।।11.51।।",
   "tr": "arjuna uvācha\ndṛiṣhṭvedaṁ mānuṣhaṁ rūpaṁ tava saumyaṁ janārdana\nidānīm asmi saṁvṛittaḥ sa-chetāḥ prakṛitiṁ gataḥ",
   "hi": "अर्जुन ने कहा -- हे जनार्दन! आपके इस सौम्य मनुष्य रूप को देखकर अब मैं शांतचित्त हुआ अपने स्वभाव को प्राप्त हो गया हूँ।।",
   "en": "Arjuna said: Seeing You in Your gentle human form, my Lord, I am myself again, calm once more.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 52,
   "sa": "श्री भगवानुवाच\nसुदुर्दर्शमिदं रूपं दृष्टवानसि यन्मम।\nदेवा अप्यस्य रूपस्य नित्यं दर्शनकाङ्क्षिणः।।11.52।।",
   "tr": "śhrī-bhagavān uvācha\nsu-durdarśham idaṁ rūpaṁ dṛiṣhṭavān asi yan mama\ndevā apy asya rūpasya nityaṁ darśhana-kāṅkṣhiṇaḥ",
   "hi": "श्रीभगवान् ने कहा -- मेरा यह रूप देखने को मिलना अति दुर्लभ है, जिसको कि तुमने देखा है। देवतागण भी सदा इस रूप के दर्शन के इच्छुक रहते हैं।।",
   "en": "Lord Shri Krishna replied: It is difficult to see the vision of Me that thou hast seen. Even the most powerful have longed for it in vain.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 53,
   "sa": "नाहं वेदैर्न तपसा न दानेन न चेज्यया।\nशक्य एवंविधो द्रष्टुं दृष्टवानसि मां यथा।।11.53।।",
   "tr": "nāhaṁ vedair na tapasā na dānena na chejyayā\nśhakya evaṁ-vidho draṣhṭuṁ dṛiṣhṭavān asi māṁ yathā",
   "hi": "न वेदों से, न तप से, न दान से और न यज्ञ से ही मैं इस प्रकार देखा जा सकता हूँ, जैसा कि तुमने मुझे देखा है।।",
   "en": "It is not possible to see Me as you have done through studying the scriptures, performing austerities, giving gifts, or making sacrifices.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 54,
   "sa": "भक्त्या त्वनन्यया शक्यमहमेवंविधोऽर्जुन।\nज्ञातुं दृष्टुं च तत्त्वेन प्रवेष्टुं च परंतप।।11.54।।",
   "tr": "bhaktyā tv ananyayā śhakya aham evaṁ-vidho ’rjuna\njñātuṁ draṣhṭuṁ cha tattvena praveṣhṭuṁ cha parantapa",
   "hi": "परन्तु हे परन्तप अर्जुन! अनन्य भक्ति के द्वारा मैं तत्त्वत: 'जानने', 'देखने' और 'प्रवेश' करने के लिए (एकी भाव से प्राप्त होने के लिए) भी, शक्य हूँ!।।",
   "en": "Only through tireless devotion can I be seen and known; only in this way can a person become one with Me, O Arjuna!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 55,
   "sa": "मत्कर्मकृन्मत्परमो मद्भक्तः सङ्गवर्जितः।\nनिर्वैरः सर्वभूतेषु यः स मामेति पाण्डव।।11.55।।",
   "tr": "mat-karma-kṛin mat-paramo mad-bhaktaḥ saṅga-varjitaḥ\nnirvairaḥ sarva-bhūteṣhu yaḥ sa mām eti pāṇḍava",
   "hi": "हे पाण्डव! जो पुरुष मेरे लिए ही कर्म करने वाला है, और मुझे ही परम लक्ष्य मानता है, जो मेरा भक्त है तथा संगरहित है, जो भूतमात्र के प्रति निर्वैर है, वह मुझे प्राप्त होता है।।",
   "en": "He who does every action for My sake, to whom I am the final goal, who loves Me alone and hates no one—O My dearest son, only he can realize Me!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
