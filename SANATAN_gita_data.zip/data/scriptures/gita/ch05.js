// Bhagavad Gita adhyay 5 - Karma Sanyasa Yoga (29 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch05"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 5,
 "title": "कर्मसंन्यासयोग",
 "illustration": "",
 "illustrationCaption": "Path of Renunciation",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का पांचवा अध्याय कर्मसन्यासयोग योग है। इस अध्याय में श्रीकृष्ण ने कर्मयोग और कर्मसन्यासयोग कि तुलना करते हुआ यह बतलाया है कि यह दोनों मार्ग एक ही लक्ष्य तक पहुँचने के माध्यम हैं। इसलिए हम इनमें से किसी भी मार्ग का चुनाव कर सकते हैं। एक बुद्धिमान व्यक्ति को अपने कर्मों को भगवान को समर्पित करते हुए अथवा उनके फल कि चिंता करे बिना अपने सांसारिक कर्तव्यों का पालन करते रहना चाहिए। इस तरह वे पाप से अप्रभावित रहते हैं और अंततः मुक्ति प्राप्त करते हैं।",
 "summaryEn": "The fifth chapter of the Bhagavad Gita is \"Karma Sanyasa Yoga\". In this chapter, Krishna compares the paths of renunciation in actions (Karma Sanyas) and actions with detachment (Karma Yoga) and explains that both are means to reach the same goal and we can choose either. A wise person should perform his/her worldly duties without attachment to the fruits of his/her actions and dedicate them to God. This way they remain unaffected by sin and eventually attain liberation.",
 "verses": [
  {
   "n": 1,
   "sa": "अर्जुन उवाच\nसंन्यासं कर्मणां कृष्ण पुनर्योगं च शंससि।\nयच्छ्रेय एतयोरेकं तन्मे ब्रूहि सुनिश्िचतम्।।5.1।।",
   "tr": "arjuna uvācha\nsannyāsaṁ karmaṇāṁ kṛiṣhṇa punar yogaṁ cha śhansasi\nyach chhreya etayor ekaṁ tan me brūhi su-niśhchitam",
   "hi": "अर्जुन ने कहा हे -- कृष्ण ! आप कर्मों के संन्यास की और फिर योग (कर्म के आचरण) की प्रशंसा करते हैं। इन दोनों में एक जो निश्चय पूर्वक श्रेयस्कर है, उसको मेरे लिए कहिये।।",
   "en": "Arjuna said: My Lord! At one moment, You praise renunciation of action; at another, You praise right action. Tell me truly, I pray, which of these is more conducive to my highest welfare?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "श्री भगवानुवाच\nसंन्यासः कर्मयोगश्च निःश्रेयसकरावुभौ।\nतयोस्तु कर्मसंन्यासात्कर्मयोगो विशिष्यते।।5.2।।",
   "tr": "śhrī bhagavān uvācha\nsannyāsaḥ karma-yogaśh cha niḥśhreyasa-karāvubhau\ntayos tu karma-sannyāsāt karma-yogo viśhiṣhyate",
   "hi": "श्रीभगवान् ने कहा -- कर्मसंन्यास और कर्मयोग ये दोनों ही परम कल्याणकारक हैं; परन्तु उन दोनों में कर्मसंन्यास से कर्मयोग श्रेष्ठ है।।",
   "en": "Lord Shri Krishna replied: Both renunciation of action and the path of right action lead to the highest; however, right action is the better of the two.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "ज्ञेयः स नित्यसंन्यासी यो न द्वेष्टि न काङ्क्षति।\nनिर्द्वन्द्वो हि महाबाहो सुखं बन्धात्प्रमुच्यते।।5.3।।",
   "tr": "jñeyaḥ sa nitya-sannyāsī yo na dveṣhṭi na kāṅkṣhati\nnirdvandvo hi mahā-bāho sukhaṁ bandhāt pramuchyate",
   "hi": "जो पुरुष न किसी से द्वेष करता है और न किसी की आकांक्षा, वह सदा संन्यासी ही समझने योग्य है; क्योंकि, हे महाबाहो ! द्वन्द्वों से रहित पुरुष सहज ही बन्धन मुक्त हो जाता है।।",
   "en": "He is a true ascetic who never desires nor dislikes, who is unaffected by the opposites and is easily freed from bondage.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "सांख्ययोगौ पृथग्बालाः प्रवदन्ति न पण्डिताः।\nएकमप्यास्थितः सम्यगुभयोर्विन्दते फलम्।।5.4।।",
   "tr": "sānkhya-yogau pṛithag bālāḥ pravadanti na paṇḍitāḥ\nekamapyāsthitaḥ samyag ubhayor vindate phalam",
   "hi": "बालक अर्थात् बालबुद्धि के लोग सांख्य (संन्यास) और योग को परस्पर भिन्न समझते हैं; किसी एक में भी सम्यक् प्रकार से स्थित हुआ पुरुष दोनों के फल को प्राप्त कर लेता है।।",
   "en": "Only the unenlightened speak of wisdom and right action as separate; the wise do not. If anyone knows one, they enjoy the fruit of both.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "यत्सांख्यैः प्राप्यते स्थानं तद्योगैरपि गम्यते।\nएकं सांख्यं च योगं च यः पश्यति स पश्यति।।5.5।।",
   "tr": "yat sānkhyaiḥ prāpyate sthānaṁ tad yogair api gamyate\nekaṁ sānkhyaṁ cha yogaṁ cha yaḥ paśhyati sa paśhyati",
   "hi": "जो स्थान ज्ञानियों द्वारा प्राप्त किया जाता है, उसी स्थान पर कर्मयोगी भी पहुँचते हैं। इसलिए जो पुरुष सांख्य और योग को (फलरूप से) एक ही देखता है, वही (वास्तव में) देखता है।।",
   "en": "The level which is attained through wisdom is also reached through right action. He who perceives that the two are one, knows the truth.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "संन्यासस्तु महाबाहो दुःखमाप्तुमयोगतः।\nयोगयुक्तो मुनिर्ब्रह्म नचिरेणाधिगच्छति।।5.6।।",
   "tr": "sannyāsas tu mahā-bāho duḥkham āptum ayogataḥ\nyoga-yukto munir brahma na chireṇādhigachchhati",
   "hi": "परन्तु, हे महाबाहो ! योग के बिना संन्यास प्राप्त होना कठिन है; योगयुक्त मननशील पुरुष परमात्मा को शीघ्र ही प्राप्त होता है।।",
   "en": "Without concentration, O Mighty One, renunciation is difficult. But the sage who is always meditating on the Divine, shall soon attain the Absolute.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "योगयुक्तो विशुद्धात्मा विजितात्मा जितेन्द्रियः।\nसर्वभूतात्मभूतात्मा कुर्वन्नपि न लिप्यते।।5.7।।",
   "tr": "yoga-yukto viśhuddhātmā vijitātmā jitendriyaḥ\nsarva-bhūtātma-bhūtātmā kurvann api na lipyate",
   "hi": "जो पुरुष योगयुक्त, विशुद्ध अन्तकरण वाला, शरीर को वश में किये हुए, जितेन्द्रिय तथा भूतमात्र में स्थित आत्मा के साथ एकत्व अनुभव किये हुए है वह कर्म करते हुए भी उनसे लिप्त नहीं होता।।",
   "en": "He who is spiritual, pure, has overcome his senses and his personal self, and has realized his highest Self as the Self of all—even though he acts, he is not bound by his actions.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "नैव किंचित्करोमीति युक्तो मन्येत तत्त्ववित्।\nपश्यन् श्रृणवन्स्पृशञ्जिघ्रन्नश्नन्गच्छन्स्वपन् श्वसन्।।5.8।।",
   "tr": "naiva kiñchit karomīti yukto manyeta tattva-vit\npaśhyañ śhṛiṇvan spṛiśhañjighrann aśhnangachchhan svapañśhvasan\npralapan visṛijan gṛihṇann unmiṣhan nimiṣhann api\nindriyāṇīndriyārtheṣhu vartanta iti dhārayan",
   "hi": "तत्त्ववित् युक्त पुरुष यह सोचेगा (अर्थात् जानता है) कि \"मैं किंचित् मात्र कर्म नहीं करता हूँ\" देखता हुआ, सुनता हुआ, स्पर्श करता हुआ, सूंघता हुआ, खाता हुआ, चलता हुआ, सोता हुआ, श्वास लेता हुआ,।।",
   "en": "Though the saint sees, hears, touches, smells, eats, moves, sleeps, and breathes, yet he knows the truth and knows that it is not he who acts.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "प्रलपन्विसृजन्गृह्णन्नुन्मिषन्निमिषन्नपि।\nइन्द्रियाणीन्द्रियार्थेषु वर्तन्त इति धारयन्।।5.9।।",
   "tr": "pralapan visṛjan gṛhṇann unmiṣan nimiṣann api indriyāṇīndriyārtheṣu vartanta iti dhārayan",
   "hi": "बोलता हुआ, त्यागता हुआ, ग्रहण करता हुआ तथा आँखों को खोलता और बन्द करता हुआ (वह) निश्चयात्मक रूप से जानता है कि सब इन्द्रियाँ अपने-अपने विषयों में विचरण कर रही हैं।।",
   "en": "Though he talks, gives, receives, opens his eyes, and shuts them, he still knows that his senses are merely disporting themselves among the objects of perception.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "ब्रह्मण्याधाय कर्माणि सङ्गं त्यक्त्वा करोति यः।\nलिप्यते न स पापेन पद्मपत्रमिवाम्भसा।।5.10।।",
   "tr": "brahmaṇyādhāya karmāṇi saṅgaṁ tyaktvā karoti yaḥ\nlipyate na sa pāpena padma-patram ivāmbhasā",
   "hi": "जो पुरुष सब कर्म ब्रह्म में अर्पण करके और आसक्ति को त्यागकर करता है, वह पुरुष कमल के पत्ते के सदृश पाप से लिप्त नहीं होता।।",
   "en": "He who dedicates his actions to the Spirit, without any personal attachment to them, is no more tainted by sin than the water lily is wetted by water.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "कायेन मनसा बुद्ध्या केवलैरिन्द्रियैरपि।\nयोगिनः कर्म कुर्वन्ति सङ्गं त्यक्त्वाऽऽत्मशुद्धये।।5.11।।",
   "tr": "kāyena manasā buddhyā kevalair indriyair api\nyoginaḥ karma kurvanti saṅgaṁ tyaktvātma-śhuddhaye",
   "hi": "योगीजन, शरीर, मन, बुद्धि और इन्द्रियों द्वारा आसक्ति को त्याग कर आत्मशुद्धि (चित्तशुद्धि) के लिए कर्म करते हैं।।",
   "en": "The sage performs his action dispassionately, using his body, mind, intellect, and even his senses, always as a means for purification.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "युक्तः कर्मफलं त्यक्त्वा शान्तिमाप्नोति नैष्ठिकीम्।\nअयुक्तः कामकारेण फले सक्तो निबध्यते।।5.12।।",
   "tr": "yuktaḥ karma-phalaṁ tyaktvā śhāntim āpnoti naiṣhṭhikīm\nayuktaḥ kāma-kāreṇa phale sakto nibadhyate",
   "hi": "युक्त पुरुष कर्मफल का त्याग करके परम शान्ति को प्राप्त होता है; और अयुक्त पुरुष फल में आसक्त हुआ कामना के द्वारा बँधता है।।",
   "en": "Having abandoned the fruit of action, he wins eternal peace. Others, unacquainted with spirituality, led by desire and clinging to the benefit they think will follow their actions, become entangled in them.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "सर्वकर्माणि मनसा संन्यस्यास्ते सुखं वशी।\nनवद्वारे पुरे देही नैव कुर्वन्न कारयन्।।5.13।।",
   "tr": "sarva-karmāṇi manasā sannyasyāste sukhaṁ vaśhī\nnava-dvāre pure dehī naiva kurvan na kārayan",
   "hi": "सब कर्मों का मन से संन्यास करके संयमी पुरुष नवद्वार वाली शरीर रूप नगरी में सुख से रहता हुआ न कर्म करता है और न करवाता है।।",
   "en": "Mentally renouncing all actions, the self-controlled soul enjoys bliss in this body, the city of the nine gates, neither doing anything themselves nor causing anything to be done.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "न कर्तृत्वं न कर्माणि लोकस्य सृजति प्रभुः।\nन कर्मफलसंयोगं स्वभावस्तु प्रवर्तते।।5.14।।",
   "tr": "na kartṛitvaṁ na karmāṇi lokasya sṛijati prabhuḥ\nna karma-phala-saṅyogaṁ svabhāvas tu pravartate",
   "hi": "लोकमात्र के लिए प्रभु (ईश्वर) न कर्तृत्व, न कर्म और न कर्मफल के संयोग को रचता है। परन्तु प्रकृति (सब कुछ) करती है।।",
   "en": "The Lord of this universe has not ordained activity, nor any incentive thereto, nor any relation between an act and its consequences; all this is the work of Nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "नादत्ते कस्यचित्पापं न चैव सुकृतं विभुः।\nअज्ञानेनावृतं ज्ञानं तेन मुह्यन्ति जन्तवः।।5.15।।",
   "tr": "nādatte kasyachit pāpaṁ na chaiva sukṛitaṁ vibhuḥ\najñānenāvṛitaṁ jñānaṁ tena muhyanti jantavaḥ",
   "hi": "विभु परमात्मा न किसी के पापकर्म को और न पुण्यकर्म को ही ग्रहण करता है; (किन्तु) अज्ञान से ज्ञान ढका हुआ है, इससे सब जीव मोहित होते हैं।।",
   "en": "The Lord does not accept responsibility for any person's sin or merit; they are deluded, for wisdom is submerged in ignorance within them.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "ज्ञानेन तु तदज्ञानं येषां नाशितमात्मनः।\nतेषामादित्यवज्ज्ञानं प्रकाशयति तत्परम्।।5.16।।",
   "tr": "jñānena tu tad ajñānaṁ yeṣhāṁ nāśhitam ātmanaḥ\nteṣhām āditya-vaj jñānaṁ prakāśhayati tat param",
   "hi": "परन्तु जिनका वह अज्ञान आत्मज्ञान से नष्ट हो जाता है, उनके लिए वह ज्ञान, सूर्य के सदृश, परमात्मा को प्रकाशित करता है।।",
   "en": "Surely, wisdom is like the sun, revealing the supreme truth to those whose ignorance has been dispelled by the wisdom of the Self.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "तद्बुद्धयस्तदात्मानस्तन्निष्ठास्तत्परायणाः।\nगच्छन्त्यपुनरावृत्तिं ज्ञाननिर्धूतकल्मषाः।।5.17।।",
   "tr": "tad-buddhayas tad-ātmānas tan-niṣhṭhās tat-parāyaṇāḥ\ngachchhantyapunar-āvṛittiṁ jñāna-nirdhūta-kalmaṣhāḥ",
   "hi": "जिनकी बुद्धि उस (परमात्मा) में स्थित है, जिनका मन तद्रूप हुआ है, उसमें ही जिनकी निष्ठा है, वह (ब्रह्म) ही जिनका परम लक्ष्य है, ज्ञान के द्वारा पापरहित पुरुष अपुनरावृत्ति को प्राप्त होते हैं, अर्थात् उनका पुनर्जन्म नहीं होता है।।",
   "en": "Meditating on the divine, having faith in the divine, concentrating on the divine, and losing themselves in the divine, their sins dissolve in wisdom, and they go from whence there is no return.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "विद्याविनयसंपन्ने ब्राह्मणे गवि हस्तिनि।\nशुनि चैव श्वपाके च पण्डिताः समदर्शिनः।।5.18।।",
   "tr": "vidyā-vinaya-sampanne brāhmaṇe gavi hastini\nśhuni chaiva śhva-pāke cha paṇḍitāḥ sama-darśhinaḥ",
   "hi": "(ऐसे वे) ज्ञानीजन विद्या और विनय से सम्पन्न ब्राह्मण, तथा गाय, हाथी, श्वान और चाण्डाल में भी सम तत्त्व को देखते हैं।।",
   "en": "Sages look upon all equally, whether they be a minister of learning and humility, an infidel, a cow, an elephant, or a dog.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "इहैव तैर्जितः सर्गो येषां साम्ये स्थितं मनः।\nनिर्दोषं हि समं ब्रह्म तस्माद्ब्रह्मणि ते स्थिताः।।5.19।।",
   "tr": "ihaiva tair jitaḥ sargo yeṣhāṁ sāmye sthitaṁ manaḥ\nnirdoṣhaṁ hi samaṁ brahma tasmād brahmaṇi te sthitāḥ",
   "hi": "जिनका मन समत्वभाव में स्थित है, उनके द्वारा यहीं पर यह सर्ग जीत लिया जाता है; क्योंकि ब्रह्म निर्दोष और सम है इसलिये वे ब्रह्म में ही स्थित हैं।।",
   "en": "Even in this world, those whose minds remain always balanced, fixed on the Supreme, conquer their earthly life; for the Supreme has neither blemish nor bias.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "न प्रहृष्येत्प्रियं प्राप्य नोद्विजेत्प्राप्य चाप्रियम्।\nस्थिरबुद्धिरसम्मूढो ब्रह्मविद्ब्रह्मणि स्थितः।।5.20।।",
   "tr": "na prahṛiṣhyet priyaṁ prāpya nodvijet prāpya chāpriyam\nsthira-buddhir asammūḍho brahma-vid brahmaṇi sthitaḥ",
   "hi": "जो स्थिरबुद्धि, संमोहरहित ब्रह्मवित् पुरुष ब्रह्म में स्थित है, वह प्रिय वस्तु को प्राप्त होकर हर्षित नहीं होता और अप्रिय को पाकर उद्विग्न नहीं होता।।",
   "en": "He who knows and lives in the Absolute remains unmoved and unperturbed; he is not elated by pleasure nor depressed by pain.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "बाह्यस्पर्शेष्वसक्तात्मा विन्दत्यात्मनि यत्सुखम्।\nस ब्रह्मयोगयुक्तात्मा सुखमक्षयमश्नुते।।5.21।।",
   "tr": "bāhya-sparśheṣhvasaktātmā vindatyātmani yat sukham\nsa brahma-yoga-yuktātmā sukham akṣhayam aśhnute",
   "hi": "बाह्य विषयों में आसक्तिरहित अन्त:करण वाला पुरुष आत्मा में ही सुख प्राप्त करता है; ब्रह्म के ध्यान में समाहित चित्त वाला पुरुष अक्षय सुख प्राप्त करता है।।",
   "en": "He finds happiness in his own Self and enjoys eternal bliss, whose heart does not yearn for the contacts of the earth and whose Self is one with the Everlasting.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "ये हि संस्पर्शजा भोगा दुःखयोनय एव ते।\nआद्यन्तवन्तः कौन्तेय न तेषु रमते बुधः।।5.22।।",
   "tr": "ye hi sansparśha-jā bhogā duḥkha-yonaya eva te\nādyantavantaḥ kaunteya na teṣhu ramate budhaḥ",
   "hi": "हे कौन्तेय (इन्द्रिय तथा विषयों के) संयोग से उत्पन्न होने वाले जो भोग हैं वे दु:ख के ही हेतु हैं, क्योंकि वे आदि-अन्त वाले हैं। बुद्धिमान् पुरुष उनमें नहीं रमता।।",
   "en": "The joys that spring from external associations bring pain; they have their beginnings and their endings. The wise person does not rejoice in them.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "शक्नोतीहैव यः सोढुं प्राक्शरीरविमोक्षणात्।\nकामक्रोधोद्भवं वेगं स युक्तः स सुखी नरः।।5.23।।",
   "tr": "śhaknotīhaiva yaḥ soḍhuṁ prāk śharīra-vimokṣhaṇāt\nkāma-krodhodbhavaṁ vegaṁ sa yuktaḥ sa sukhī naraḥ",
   "hi": "जो मनुष्य इसी लोक में शरीर त्यागने के पूर्व ही काम और क्रोध से उत्पन्न हुए वेग को सहन करने में समर्थ है, वह योगी (युक्त) और सुखी मनुष्य है।।",
   "en": "He who, before leaving his body, learns to overcome the promptings of desire and anger, is a saint and is happy.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "योऽन्तःसुखोऽन्तरारामस्तथान्तर्ज्योतिरेव यः।\nस योगी ब्रह्मनिर्वाणं ब्रह्मभूतोऽधिगच्छति।।5.24।।",
   "tr": "yo 'ntaḥ-sukho 'ntar-ārāmas tathāntar-jyotir eva yaḥ\nsa yogī brahma-nirvāṇaṁ brahma-bhūto 'dhigachchhati",
   "hi": "जो पुरुष अन्तरात्मा में ही सुख वाला, आत्मा में ही आराम वाला तथा आत्मा में ही ज्ञान वाला है, वह योगी ब्रह्मरूप बनकर ब्रह्मनिर्वाण अर्थात् परम मोक्ष को प्राप्त होता है।।",
   "en": "He who is happy within himself and has found its peace, and in whom the inner light shines, that sage attains eternal bliss and becomes one with the spirit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "लभन्ते ब्रह्मनिर्वाणमृषयः क्षीणकल्मषाः।\nछिन्नद्वैधा यतात्मानः सर्वभूतहिते रताः।।5.25।।",
   "tr": "labhante brahma-nirvāṇam ṛiṣhayaḥ kṣhīṇa-kalmaṣhāḥ\nchhinna-dvaidhā yatātmānaḥ sarva-bhūta-hite ratāḥ",
   "hi": "वे ऋषिगण मोक्ष को प्राप्त होते हैं - जिनके पाप नष्ट हो गये हैं, जो छिन्नसंशय, संयमी और भूतमात्र के हित में रमने वाले हैं।।",
   "en": "Sages whose sins have been washed away, whose sense of separateness has dissipated, who have subdued themselves, and seek only the welfare of all, come to the Eternal Spirit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "कामक्रोधवियुक्तानां यतीनां यतचेतसाम्।\nअभितो ब्रह्मनिर्वाणं वर्तते विदितात्मनाम्।।5.26।।",
   "tr": "kāma-krodha-viyuktānāṁ yatīnāṁ yata-chetasām\nabhito brahma-nirvāṇaṁ vartate viditātmanām",
   "hi": "काम और क्रोध से रहित, संयतचित्त वाले तथा आत्मा को जानने वाले यतियों के लिए सब ओर मोक्ष (या ब्रह्मानन्द) विद्यमान रहता है।।",
   "en": "Saints who know themselves, who control their minds, and feel neither desire nor anger, find eternal bliss everywhere.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "स्पर्शान्कृत्वा बहिर्बाह्यांश्चक्षुश्चैवान्तरे भ्रुवोः।\nप्राणापानौ समौ कृत्वा नासाभ्यन्तरचारिणौ।।5.27।।",
   "tr": "sparśhān kṛitvā bahir bāhyānśh chakṣhuśh chaivāntare bhruvoḥ\nprāṇāpānau samau kṛitvā nāsābhyantara-chāriṇau\nyatendriya-mano-buddhir munir mokṣha-parāyaṇaḥ\nvigatechchhā-bhaya-krodho yaḥ sadā mukta eva saḥ",
   "hi": "बाह्य विषयों को बाहर ही रखकर नेत्रों की दृष्टि को भृकुटि के बीच में स्थित करके तथा नासिका में विचरने वाले प्राण और अपानवायु को सम करके,।।",
   "en": "Excluding external objects, with his gaze fixed between the eyebrows, and the inward and outward breathings passing equally through his nostrils;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "यतेन्द्रियमनोबुद्धिर्मुनिर्मोक्षपरायणः।\nविगतेच्छाभयक्रोधो यः सदा मुक्त एव सः।।5.28।।",
   "tr": "yatendriya-mano-buddhir  munir   mokṣa-parāyaṇaḥ vigatecchā-bhaya-krodho yaḥ sadā    mukta   eva saḥ",
   "hi": "जिस पुरुष की इन्द्रियाँ, मन और बुद्धि संयत हैं, ऐसा मोक्ष परायण मुनि इच्छा, भय और क्रोध से रहित है, वह सदा मुक्त ही है।।",
   "en": "Governing sense, mind, and intellect, intent on liberation, free from desire, fear, and anger, the sage is eternally free.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "भोक्तारं यज्ञतपसां सर्वलोकमहेश्वरम्।\nसुहृदं सर्वभूतानां ज्ञात्वा मां शान्तिमृच्छति।।5.29।।",
   "tr": "bhoktāraṁ yajña-tapasāṁ sarva-loka-maheśhvaram\nsuhṛidaṁ sarva-bhūtānāṁ jñātvā māṁ śhāntim ṛichchhati",
   "hi": "(साधक भक्त) मुझे यज्ञ और तपों का भोक्ता और सम्पूर्ण लोकों का महान् ईश्वर तथा भूतमात्र का सुहृद् (मित्र) जानकर शान्ति को प्राप्त होता है।।",
   "en": "Knowing Me as the One who gladly receives all offerings of austerity and sacrifice, as the Mighty Ruler of all the Worlds and the Friend of all beings, he passes to Eternal Peace.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
