// Bhagavad Gita adhyay 8 - Akshara Brahma Yoga (28 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch08"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 8,
 "title": "अक्षरब्रह्मयोग",
 "illustration": "",
 "illustrationCaption": "Path of the Eternal God",
 "imageQuery": "Vishnu Ananta Shesha",
 "summaryHi": "भगवद गीता का आठवां अध्याय अक्षरब्रह्मयोग है। इस अध्याय में, कृष्ण मृत्यु से पहले अंतिम विचार का महत्व बताते हैं। अगर हम मृत्यु के समय कृष्ण को याद कर लें तो हम निश्चित रूप से उन्हें प्राप्त करेंगे। इसलिए हर समय प्रभु के बारे में जागरूकता रखना, उनके बारे में सोचना और हर समय उनके नामों का जप करना बहुत महत्वपूर्ण है। अपने मन को पूरी तरह से कृष्ण की निरंतर भक्ति में समाहित करके हम इस भौतिक संसार से परे भगवान के सर्वोच्च निवास तक जा सकते हैं।",
 "summaryEn": "The eighth chapter of the Bhagavad Gita is \"Akshara Brahma Yoga\". In this chapter, Krishna reveals the importance of the last thought before death. If we can remember Krishna at the time of death, we will certainly attain him. Thus, it is very important to be in constant awareness of the Lord at all times, thinking of Him and chanting His names at all times. By perfectly absorbing their mind in Him through constant devotion, one can go beyond this material existence to Lord's Supreme abode.",
 "verses": [
  {
   "n": 1,
   "sa": "अर्जुन उवाच\nकिं तद्ब्रह्म किमध्यात्मं किं कर्म पुरुषोत्तम।\nअधिभूतं च किं प्रोक्तमधिदैवं किमुच्यते।।8.1।।",
   "tr": "arjuna uvācha\nkiṁ tad brahma kim adhyātmaṁ kiṁ karma puruṣhottama\nadhibhūtaṁ cha kiṁ proktam adhidaivaṁ kim uchyate",
   "hi": "अर्जुन ने कहा -हे पुरुषोत्तम ! वह ब्रह्म क्या है अध्यात्म क्या है? तथा कर्म क्या है? और अधिभूत नाम से क्या कहा गया है? तथा अधिदैव नाम से क्या कहा जाता है,",
   "en": "Arjuna asked: O Lord of Lords! What is that which people call the Supreme Spirit, what is humanity's spiritual nature, and what is the law? What is matter and what is divinity?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "अधियज्ञः कथं कोऽत्र देहेऽस्मिन्मधुसूदन।\nप्रयाणकाले च कथं ज्ञेयोऽसि नियतात्मभिः।।8.2।।",
   "tr": "adhiyajñaḥ kathaṁ ko ’tra dehe ’smin madhusūdana\nprayāṇa-kāle cha kathaṁ jñeyo ’si niyatātmabhiḥ",
   "hi": "और हे मधुसूदन ! यहाँ अधियज्ञ कौन है? और वह इस शरीर में कैसे है? और संयत चित्त वाले पुरुषों द्वारा अन्त समय में आप किस प्रकार जाने जाते हैं,",
   "en": "Who rules the spirit sacrifice in many, and how may those who have learned self-control come to the knowledge of Thee at the time of death?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "श्री भगवानुवाच\nअक्षरं ब्रह्म परमं स्वभावोऽध्यात्ममुच्यते।\nभूतभावोद्भवकरो विसर्गः कर्मसंज्ञितः।।8.3।।",
   "tr": "śhrī bhagavān uvācha\nakṣharaṁ brahma paramaṁ svabhāvo ’dhyātmam uchyate\nbhūta-bhāvodbhava-karo visargaḥ karma-sanjñitaḥ",
   "hi": "श्रीभगवान् ने कहा -- परम अक्षर (अविनाशी) तत्त्व ब्रह्म है; स्वभाव (अपना स्वरूप) अध्यात्म कहा जाता है; भूतों के भावों को उत्पन्न करने वाला विसर्ग (यज्ञ, प्रेरक बल) कर्म नाम से जाना जाता है।।",
   "en": "The Lord Shri Krishna replied: The Supreme Spirit is the Highest Imperishable Self, and Its nature is spiritual consciousness. The worlds have been created and are sustained by an emanation from the Spirit, which is called the Law.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "अधिभूतं क्षरो भावः पुरुषश्चाधिदैवतम्।\nअधियज्ञोऽहमेवात्र देहे देहभृतां वर।।8.4।।",
   "tr": "adhibhūtaṁ kṣharo bhāvaḥ puruṣhaśh chādhidaivatam\nadhiyajño ’ham evātra dehe deha-bhṛitāṁ vara",
   "hi": "हे देहधारियों में श्रेष्ठ अर्जुन ! नश्वर वस्तु (पंचमहाभूत) अधिभूत और पुरुष अधिदैव है; इस शरीर में मैं ही अधियज्ञ हूँ।।",
   "en": "Matter consists of forms that perish; Divinity is the Supreme Self; and He who inspires the spirit of sacrifice in man, O noblest of their race, is I Myself, Who now stand in human form before thee.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "अन्तकाले च मामेव स्मरन्मुक्त्वा कलेवरम्।\nयः प्रयाति स मद्भावं याति नास्त्यत्र संशयः।।8.5।।",
   "tr": "anta-kāle cha mām eva smaran muktvā kalevaram\nyaḥ prayāti sa mad-bhāvaṁ yāti nāstyatra sanśhayaḥ",
   "hi": "और जो कोई पुरुष अन्तकाल में मुझे ही स्मरण करता हुआ शरीर को त्याग कर जाता है, वह मेरे स्वरूप को प्राप्त होता है, इसमें कुछ भी संशय नहीं।।",
   "en": "Whosoever, at the time of death, thinks only of Me and, thinking thus, leaves the body and goes forth, will assuredly know Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "यं यं वापि स्मरन्भावं त्यजत्यन्ते कलेवरम्।\nतं तमेवैति कौन्तेय सदा तद्भावभावितः।।8.6।।",
   "tr": "yaṁ yaṁ vāpi smaran bhāvaṁ tyajatyante kalevaram\ntaṁ tam evaiti kaunteya sadā tad-bhāva-bhāvitaḥ",
   "hi": "हे कौन्तेय ! (यह जीव) अन्तकाल में जिस किसी भी भाव को स्मरण करता हुआ शरीर को त्यागता है, वह सदैव उस भाव के चिन्तन के फलस्वरूप उसी भाव को ही प्राप्त होता है।।",
   "en": "Whatever sphere of being the mind of a man is intent on at the time of death, to that he will go.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "तस्मात्सर्वेषु कालेषु मामनुस्मर युध्य च।\nमय्यर्पितमनोबुद्धिर्मामेवैष्यस्यसंशयम्।।8.7।।",
   "tr": "tasmāt sarveṣhu kāleṣhu mām anusmara yudhya cha\nmayyarpita-mano-buddhir mām evaiṣhyasyasanśhayam",
   "hi": "इसलिए, तुम सब काल में मेरा निरन्तर स्मरण करो; और युद्ध करो मुझमें अर्पण किये मन, बुद्धि से युक्त हुए निःसन्देह तुम मुझे ही प्राप्त होओगे।।",
   "en": "Therefore, always meditate on Me and fight; if your mind and reason are fixed on Me, you will surely come to Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "अभ्यासयोगयुक्तेन चेतसा नान्यगामिना।\nपरमं पुरुषं दिव्यं याति पार्थानुचिन्तयन्।।8.8।।",
   "tr": "abhyāsa-yoga-yuktena chetasā nānya-gāminā\nparamaṁ puruṣhaṁ divyaṁ yāti pārthānuchintayan",
   "hi": "हे पार्थ ! अभ्यासयोग से युक्त अन्यत्र न जाने वाले चित्त से निरन्तर चिन्तन करता हुआ (साधक) परम दिव्य पुरुष को प्राप्त होता है।।",
   "en": "He whose mind does not wander, and who is engaged in constant meditation, attains the Supreme Spirit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "कविं पुराणमनुशासितार\nमणोरणीयांसमनुस्मरेद्यः।\nसर्वस्य धातारमचिन्त्यरूप\nमादित्यवर्णं तमसः परस्तात्।।8.9।।",
   "tr": "kaviṁ purāṇam anuśhāsitāram\naṇor aṇīyānsam anusmared yaḥ\nsarvasya dhātāram achintya-rūpam\nāditya-varṇaṁ tamasaḥ parastāt",
   "hi": "जो पुरुष सर्वज्ञ, प्राचीन (पुराण), सबके नियन्ता, सूक्ष्म से भी सूक्ष्मतर, सब के धाता, अचिन्त्यरूप, सूर्य के समान प्रकाश रूप और (अविद्या) अन्धकार से परे तत्त्व का अनुस्मरण करता है।।",
   "en": "Whoso meditates on the Omniscient, the Ancient, more minute than an atom, yet the Ruler and Upholder of all, Unimaginable, Brilliant like the Sun, Beyond the reach of darkness;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "प्रयाणकाले मनसाऽचलेन\nभक्त्या युक्तो योगबलेन चैव।\nभ्रुवोर्मध्ये प्राणमावेश्य सम्यक्\nस तं परं पुरुषमुपैति दिव्यम्।।8.10।।",
   "tr": "prayāṇa-kāle manasāchalena\nbhaktyā yukto yoga-balena chaiva\nbhruvor madhye prāṇam āveśhya samyak\nsa taṁ paraṁ puruṣham upaiti divyam",
   "hi": "वह (साधक) अन्तकाल में योगबल से प्राण को भ्रकुटि के मध्य सम्यक् प्रकार स्थापन करके निश्चल मन से भक्ति युक्त होकर उस परम दिव्य पुरुष को प्राप्त होता है।।",
   "en": "He who leaves the body with an unmoved mind, filled with devotion, and by the power of his meditation gathers his whole vital energy between his eyebrows, attains the Supreme.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "यदक्षरं वेदविदो वदन्ति\nविशन्ति यद्यतयो वीतरागाः।\nयदिच्छन्तो ब्रह्मचर्यं चरन्ति\nतत्ते पदं संग्रहेण प्रवक्ष्ये।।8.11।।",
   "tr": "yad akṣharaṁ veda-vido vadanti\nviśhanti yad yatayo vīta-rāgāḥ\nyad ichchhanto brahmacharyaṁ charanti\ntat te padaṁ saṅgraheṇa pravakṣhye",
   "hi": "वेद के जानने वाले विद्वान जिसे अक्षर कहते हैं; रागरहित यत्नशील पुरुष जिसमें प्रवेश करते हैं; जिसकी इच्छा से (साधक गण) ब्रह्मचर्य का पालन करते हैं - उस पद (लक्ष्य) को मैं तुम्हें संक्षेप में कहूँगा।।",
   "en": "Now, I will briefly speak of the imperishable goal, proclaimed by those who are versed in the scriptures, which the mystic attains when free from passion, and for which they are content to undergo the vow of continence.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "सर्वद्वाराणि संयम्य मनो हृदि निरुध्य च।\nमूर्ध्न्याधायात्मनः प्राणमास्थितो योगधारणाम्।।8.12।।",
   "tr": "sarva-dvārāṇi sanyamya mano hṛidi nirudhya cha\nmūrdhnyādhāyātmanaḥ prāṇam āsthito yoga-dhāraṇām",
   "hi": "सब (इन्द्रियों के) द्वारों को संयमित कर मन को हृदय में स्थिर करके और प्राण को मस्तक में स्थापित करके योगधारणा में स्थित हुआ।।",
   "en": "Closing the gates of the body, drawing the forces of his mind into the heart, and, by the power of meditation, concentrating his vital energy in the brain;",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "ओमित्येकाक्षरं ब्रह्म व्याहरन्मामनुस्मरन्।\nयः प्रयाति त्यजन्देहं स याति परमां गतिम्।।8.13।।",
   "tr": "oṁ ityekākṣharaṁ brahma vyāharan mām anusmaran\nyaḥ prayāti tyajan dehaṁ sa yāti paramāṁ gatim",
   "hi": "जो पुरुष ओऽम् इस एक अक्षर ब्रह्म का उच्चारण करता हुआ और मेरा स्मरण करता हुआ शरीर का त्याग करता है, वह परम गति को प्राप्त होता है।।",
   "en": "Repeating Om, the symbol of eternity, and holding Me always in remembrance, he who thus leaves his body and goes forth reaches the Supreme Spirit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "अनन्यचेताः सततं यो मां स्मरति नित्यशः।\nतस्याहं सुलभः पार्थ नित्ययुक्तस्य योगिनः।।8.14।।",
   "tr": "ananya-chetāḥ satataṁ yo māṁ smarati nityaśhaḥ\ntasyāhaṁ sulabhaḥ pārtha nitya-yuktasya yoginaḥ",
   "hi": "हे पार्थ ! जो अनन्यचित्त वाला पुरुष मेरा स्मरण करता है, उस नित्ययुक्त योगी के लिए मैं सुलभ हूँ अर्थात् सहज ही प्राप्त हो जाता हूँ।।",
   "en": "To him who constantly thinks of Me and nothing else, to such an ever-faithful devotee, O Arjuna, I am ever accessible.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "मामुपेत्य पुनर्जन्म दुःखालयमशाश्वतम्।\nनाप्नुवन्ति महात्मानः संसिद्धिं परमां गताः।।8.15।।",
   "tr": "mām upetya punar janma duḥkhālayam aśhāśhvatam\nnāpnuvanti mahātmānaḥ sansiddhiṁ paramāṁ gatāḥ",
   "hi": "परम सिद्धि को प्राप्त हुये महात्माजन मुझे प्राप्त कर अनित्य दुःख के आलयरूप (गृहरूप) पुनर्जन्म को नहीं प्राप्त होते हैं।।",
   "en": "Coming to Me in this way, these great souls no longer go to the misery and death of earthly life, for they have achieved perfection.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "आब्रह्मभुवनाल्लोकाः पुनरावर्तिनोऽर्जुन।\nमामुपेत्य तु कौन्तेय पुनर्जन्म न विद्यते।।8.16।।",
   "tr": "ā-brahma-bhuvanāl lokāḥ punar āvartino ’rjuna\nmām upetya tu kaunteya punar janma na vidyate",
   "hi": "हे अर्जुन ! ब्रह्म लोक तक के सब लोग पुनरावर्ती स्वभाव वाले हैं। परन्तु, हे कौन्तेय ! मुझे प्राप्त होने पर पुनर्जन्म नहीं होता।।",
   "en": "The worlds, along with the entire realm of creation, come and go; but, O Arjuna, whoever comes to Me, for them there is no rebirth.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "सहस्रयुगपर्यन्तमहर्यद्ब्रह्मणो विदुः।\nरात्रिं युगसहस्रान्तां तेऽहोरात्रविदो जनाः।।8.17।।",
   "tr": "sahasra-yuga-paryantam ahar yad brahmaṇo viduḥ\nrātriṁ yuga-sahasrāntāṁ te ’ho-rātra-vido janāḥ",
   "hi": "जो लोग ब्रह्मा जी के एक दिन की अवधि जानते हैं जो कि सहस्र वर्ष की है तथा एक सहस्र वर्ष की अवधि की एक रात्रि को जानते हैं वे दिन और रात्रि को जानने वाले पुरुष हैं।।",
   "en": "Those who understand the cosmic day and night know that one day of creation is a thousand cycles, and that the night is of equal length.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "अव्यक्ताद्व्यक्तयः सर्वाः प्रभवन्त्यहरागमे।\nरात्र्यागमे प्रलीयन्ते तत्रैवाव्यक्तसंज्ञके।।8.18।।",
   "tr": "avyaktād vyaktayaḥ sarvāḥ prabhavantyahar-āgame\nrātryāgame pralīyante tatraivāvyakta-sanjñake",
   "hi": "(ब्रह्माजी के) दिन का उदय होने पर अव्यक्त से (यह) व्यक्त (चराचर जगत्) उत्पन्न होता है; और (ब्रह्माजी की) रात्रि के आगमन पर उसी अव्यक्त में लीन हो जाता है।।",
   "en": "At the dawn of that day, all objects in manifestation stream forth from the Unmanifest, and when evening falls, they are dissolved back into it again.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "भूतग्रामः स एवायं भूत्वा भूत्वा प्रलीयते।\nरात्र्यागमेऽवशः पार्थ प्रभवत्यहरागमे।।8.19।।",
   "tr": "bhūta-grāmaḥ sa evāyaṁ bhūtvā bhūtvā pralīyate\nrātryāgame ’vaśhaḥ pārtha prabhavatyahar-āgame",
   "hi": "हे पार्थ ! वही यह भूतसमुदाय, है जो पुनः पुनः उत्पन्न होकर लीन होता है। अवश हुआ (यह भूतग्राम) रात्रि के आगमन पर लीन तथा दिन के उदय होने पर व्यक्त होता है।।",
   "en": "The same multitude of beings, which have lived on earth so often, all are dissolved as the night of the universe approaches, to issue forth anew when morning breaks. Thus, it is ordained.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "परस्तस्मात्तु भावोऽन्योऽव्यक्तोऽव्यक्तात्सनातनः।\nयः स सर्वेषु भूतेषु नश्यत्सु न विनश्यति।।8.20।।",
   "tr": "paras tasmāt tu bhāvo ’nyo ’vyakto ’vyaktāt sanātanaḥ\nyaḥ sa sarveṣhu bhūteṣhu naśhyatsu na vinaśhyati",
   "hi": "परन्तु उस अव्यक्त से परे अन्य जो सनातन अव्यक्त भाव है, वह समस्त भूतों के नष्ट होने पर भी नष्ट नहीं होता।।",
   "en": "In truth, therefore, there is the eternal, unmanifest, which is beyond and above the unmanifest spirit of creation, and which is never destroyed when all these beings perish.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "अव्यक्तोऽक्षर इत्युक्तस्तमाहुः परमां गतिम्।\nयं प्राप्य न निवर्तन्ते तद्धाम परमं मम।।8.21।।",
   "tr": "avyakto ’kṣhara ityuktas tam āhuḥ paramāṁ gatim\nyaṁ prāpya na nivartante tad dhāma paramaṁ mama",
   "hi": "जो अव्यक्त अक्षर कहा गया है, वही परम गति (लक्ष्य) है। जिसे प्राप्त होकर (साधकगण) पुनः (संसार को) नहीं लौटते, वह मेरा परम धाम है।।",
   "en": "The wise say that the Unmanifest and Indestructible is the highest goal of all; when once that is reached, there is no returning. That is my blessed home.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "पुरुषः स परः पार्थ भक्त्या लभ्यस्त्वनन्यया।\nयस्यान्तःस्थानि भूतानि येन सर्वमिदं ततम्।।8.22।।",
   "tr": "puruṣhaḥ sa paraḥ pārtha bhaktyā labhyas tvananyayā\nyasyāntaḥ-sthāni bhūtāni yena sarvam idaṁ tatam",
   "hi": "हे पार्थ ! जिस (परमात्मा) के अन्तर्गत समस्त भूत हैं और जिससे यह सम्पूर्ण (जगत्) व्याप्त है, वह परम पुरुष अनन्य भक्ति से ही प्राप्त करने योग्य है।।",
   "en": "O Arjuna! That Highest God, in Whom all beings abide, and Who pervades the entire universe, is reached only by wholehearted devotion. *He is the one who determines the course of worldly events and the destiny of all living beings.*",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "यत्र काले त्वनावृत्तिमावृत्तिं चैव योगिनः।\nप्रयाता यान्ति तं कालं वक्ष्यामि भरतर्षभ।।8.23।।",
   "tr": "yatra kāle tvanāvṛittim āvṛittiṁ chaiva yoginaḥ\nprayātā yānti taṁ kālaṁ vakṣhyāmi bharatarṣhabha",
   "hi": "हे भरतश्रेष्ठ ! जिस काल में (मार्ग में) शरीर त्याग कर गये हुए योगीजन अपुनरावृत्ति को, और (या) पुनरावृत्ति को प्राप्त होते हैं, वह काल (मार्ग) मैं तुम्हें बताऊँगा।।",
   "en": "Now, I will tell you, O Arjuna, the times at which, if the mystics go forth, they do not return, and at which they go forth only to return.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "अग्निर्ज्योतिरहः शुक्लः षण्मासा उत्तरायणम्।\nतत्र प्रयाता गच्छन्ति ब्रह्म ब्रह्मविदो जनाः।।8.24।।",
   "tr": "agnir jyotir ahaḥ śhuklaḥ ṣhaṇ-māsā uttarāyaṇam\ntatra prayātā gachchhanti brahma brahma-vido janāḥ",
   "hi": "जो ब्रह्मविद् साधकजन मरणोपरान्त अग्नि, ज्योति, दिन, शुक्लपक्ष और उत्तरायण के छः मास वाले मार्ग से जाते हैं, वे ब्रह्म को प्राप्त होते हैं।।",
   "en": "If the sage, knowing the Supreme Spirit, goes forth with fire and light during the day, in the fortnight of the waxing moon, and in the six months before the Northern summer solstice, he will attain the Supreme.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "धूमो रात्रिस्तथा कृष्णः षण्मासा दक्षिणायनम्।\nतत्र चान्द्रमसं ज्योतिर्योगी प्राप्य निवर्तते।।8.25।।",
   "tr": "dhūmo rātris tathā kṛiṣhṇaḥ ṣhaṇ-māsā dakṣhiṇāyanam\ntatra chāndramasaṁ jyotir yogī prāpya nivartate",
   "hi": "धूम, रात्रि, कृष्णपक्ष और दक्षिणायन के छः मास वाले मार्ग से चन्द्रमा की ज्योति को प्राप्त कर, योगी (संसार को) लौटता है।।",
   "en": "But if he departs in gloom, at night, during the fortnight of the waning moon and in the six months before the winter solstice, then he reaches only lunar light and he will be reborn.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "शुक्लकृष्णे गती ह्येते जगतः शाश्वते मते।\nएकया यात्यनावृत्तिमन्ययाऽऽवर्तते पुनः।।8.26।।",
   "tr": "śhukla-kṛiṣhṇe gatī hyete jagataḥ śhāśhvate mate\nekayā yātyanāvṛittim anyayāvartate punaḥ",
   "hi": "जगत् के ये दो प्रकार के शुक्ल और कृष्ण मार्ग सनातन माने गये हैं । इनमें एक (शुक्ल) के द्वारा (साधक) अपुनरावृत्ति को तथा अन्य (कृष्ण) के द्वारा पुनरावृत्ति को प्राप्त होता है।।",
   "en": "These bright and dark paths out of the world have always existed. Whoever takes the former, does not return; he who chooses the latter, returns.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "नैते सृती पार्थ जानन्योगी मुह्यति कश्चन।\nतस्मात्सर्वेषु कालेषु योगयुक्तो भवार्जुन।।8.27।।",
   "tr": "naite sṛitī pārtha jānan yogī muhyati kaśhchana\ntasmāt sarveṣhu kāleṣhu yoga-yukto bhavārjuna",
   "hi": "हे पार्थ इन दो मार्गों को (तत्त्व से) जानने वाला कोई भी योगी मोहित नहीं होता। इसलिए, हे अर्जुन ! तुम सब काल में योगयुक्त बनो।।",
   "en": "O Arjuna! The saint, knowing these paths, is not confused; therefore, meditate perpetually.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "वेदेषु यज्ञेषु तपःसु चैव\nदानेषु यत्पुण्यफलं प्रदिष्टम्।\nअत्येति तत्सर्वमिदं विदित्वा\nयोगी परं स्थानमुपैति चाद्यम्।।8.28।।",
   "tr": "vedeṣhu yajñeṣhu tapaḥsu chaiva\ndāneṣhu yat puṇya-phalaṁ pradiṣhṭam\natyeti tat sarvam idaṁ viditvā\nyogī paraṁ sthānam upaiti chādyam",
   "hi": "योगी पुरुष यह सब (दोनों मार्गों के तत्त्व को) जानकर वेदाध्ययन, यज्ञ, तप और दान करने में जो पुण्य फल कहा गया है, उस सबका उल्लंघन कर जाता है और आद्य (सनातन), परम स्थान को प्राप्त होता है।।",
   "en": "The sage who knows this passes beyond all merit that comes from the study of the scriptures, from sacrifice, from austerities, and from charity, and reaches the Supreme Primeval Abode.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
