// Bhagavad Gita adhyay 15 - Purushottama Yoga (20 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch15"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 15,
 "title": "पुरुषोत्तमयोग",
 "illustration": "",
 "illustrationCaption": "The Yoga of the Supreme Divine Personality",
 "imageQuery": "Ashvattha tree Bhagavad Gita",
 "summaryHi": "भगवद गीता का पंद्रहवा अध्याय पुरुषोत्तमयोग है। संस्कृत में, पुरूष का मतलब सर्वव्यापी भगवान है, और पुरुषोत्तम का मतलब है ईश्वर का कालातीत और पारस्परिक पहलू। कृष्णा बताते हैं कि ईश्वर के इस महान ज्ञान का उद्देश्य भौतिक संसार के बंधन से खुद को अलग करना है और कृष्ण को सर्वोच्च दिव्य व्यक्तित्व के रूप में समझना है, जो विश्व के शाश्वत नियंत्रक और निर्वाहक हैं। जो इस परम सत्य को समझता है वह प्रभु को समर्पण करता है और उनकी भक्ति सेवा में संलग्न हो जाता है।        ",
 "summaryEn": "The fifteenth chapter of the Bhagavad Gita is \"Purushottama Yoga\". In Sanskrit, Purusha means the \"All-pervading God\", and Purushottam means the timeless & transcendental aspect of God.        Krishna reveals that the purpose of this Transcendental knowledge of the God is to detach ourselves from the bondage of the material world and to understand Krishna as the Supreme Divine Personality, who is the eternal controller and sustainer of the world. One who understands this Ultimate Truth surrenders to Him and engages in His devotional service.",
 "verses": [
  {
   "n": 1,
   "sa": "श्री भगवानुवाचऊर्ध्वमूलमधःशाखमश्वत्थं प्राहुरव्ययम्।छन्दांसि यस्य पर्णानि यस्तं वेद स वेदवित्।।15.1।।",
   "tr": "śhrī-bhagavān uvācha\nūrdhva-mūlam adhaḥ-śhākham aśhvatthaṁ prāhur avyayam\nchhandānsi yasya parṇāni yas taṁ veda sa veda-vit",
   "hi": "श्री भगवान् ने कहा -- (ज्ञानी पुरुष इस संसार वृक्ष को) ऊर्ध्वमूल और अध:शाखा वाला अश्वत्थ और अव्यय कहते हैं; जिसके पर्ण छन्द अर्थात् वेद हैं, ऐसे (संसार वृक्ष) को जो जानता है, वह वेदवित् है।।",
   "en": "Lord Shri Krishna continued: This phenomenal creation, which is both ephemeral and eternal, is like a tree, with its seed above in the Highest and its ramifications below on this earth. The scriptures are its leaves, and he who understands this knows.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "अधश्चोर्ध्वं प्रसृतास्तस्य शाखा     गुणप्रवृद्धा विषयप्रवालाः।अधश्च मूलान्यनुसन्ततानि     कर्मानुबन्धीनि मनुष्यलोके।।15.2।।",
   "tr": "adhaśh chordhvaṁ prasṛitās tasya śhākhā\nguṇa-pravṛiddhā viṣhaya-pravālāḥ\nadhaśh cha mūlāny anusantatāni\nkarmānubandhīni manuṣhya-loke",
   "hi": "उस वृक्ष की शाखाएं गुणों से प्रवृद्ध हुईं नीचे और ऊपर फैली हुईं हैं; (पंच) विषय इसके अंकुर हैं; मनुष्य लोक में कर्मों का अनुसरण करने वाली इसकी अन्य जड़ें नीचे फैली हुईं हैं।।",
   "en": "Its branches shoot upwards and downwards, deriving their nourishment from the qualities; its buds are the objects of sense; and its roots, which follow the law, causing man's regeneration and degeneration, pierce downwards into the soil.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "न रूपमस्येह तथोपलभ्यते    नान्तो न चादिर्न च संप्रतिष्ठा।अश्वत्थमेनं सुविरूढमूल    मसङ्गशस्त्रेण दृढेन छित्त्वा।।15.3।।",
   "tr": "na rūpam asyeha tathopalabhyate\nnānto na chādir na cha sampratiṣhṭhā\naśhvattham enaṁ su-virūḍha-mūlam\nasaṅga-śhastreṇa dṛiḍhena chhittvā",
   "hi": "इस (संसार वृक्ष) का स्वरूप जैसा कहा गया है वैसा यहाँ उपलब्ध नहीं होता है, क्योंकि इसका न आदि है और न अंत और न प्रतिष्ठा ही है। इस अति दृढ़ मूल वाले अश्वत्थ वृक्ष को दृढ़ असङ्ग शस्त्र से काटकर ...৷৷৷৷।।",
   "en": "In this world, its true form is not known, neither its origin nor its end, and its strength is not understood—until the tree, with its roots striking deep into the earth, is hewn down by the sharp axe of non-attachment.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "ततः पदं तत्परिमार्गितव्य    यस्मिन्गता न निवर्तन्ति भूयः।तमेव चाद्यं पुरुषं प्रपद्ये    यतः प्रवृत्तिः प्रसृता पुराणी।।15.4।।",
   "tr": "tataḥ padaṁ tat parimārgitavyaṁ\nyasmin gatā na nivartanti bhūyaḥ\ntam eva chādyaṁ puruṣhaṁ prapadye\nyataḥ pravṛittiḥ prasṛitā purāṇī",
   "hi": "(तदुपरान्त) उस पद का अन्वेषण करना चाहिए जिसको प्राप्त हुए पुरुष पुन: संसार में नहीं लौटते हैं। \"मैं उस आदि पुरुष की शरण हूँ, जिससे यह पुरातन प्रवृत्ति प्रसृत हुई है\"।।",
   "en": "Beyond lies the path, from which, once found, there is no return. This is the Primal God from whom this ancient creation has sprung.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "निर्मानमोहा जितसङ्गदोषा    अध्यात्मनित्या विनिवृत्तकामाः।द्वन्द्वैर्विमुक्ताः सुखदुःखसंज्ञै    र्गच्छन्त्यमूढाः पदमव्ययं तत्।।15.5।।",
   "tr": "nirmāna-mohā jita-saṅga-doṣhā\nadhyātma-nityā vinivṛitta-kāmāḥ\ndvandvair vimuktāḥ sukha-duḥkha-sanjñair\ngachchhanty amūḍhāḥ padam avyayaṁ tat",
   "hi": "जिनका मान और मोह निवृत्त हो गया है, जिन्होंने संगदोष को जीत लिया है, जो अध्यात्म में स्थित हैं जिनकी कामनाएं निवृत्त हो चुकी हैं और जो सुख-दु:ख नामक द्वन्द्वों से विमुक्त हो गये हैं, ऐसे सम्मोह रहित ज्ञानीजन उस अव्यय पद को प्राप्त होते हैं।।",
   "en": "The wise attain Eternity when, freed from pride and delusion, they have conquered their love for the things of sense; when, renouncing desire and fixing their gaze on the Self, they cease to be tossed to and fro by the opposing sensations, such as pleasure and pain.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "न तद्भासयते सूर्यो न शशाङ्को न पावकः।यद्गत्वा न निवर्तन्ते तद्धाम परमं मम।।15.6।।",
   "tr": "na tad bhāsayate sūryo na śhaśhāṅko na pāvakaḥ\nyad gatvā na nivartante tad dhāma paramaṁ mama",
   "hi": "उसे न सूर्य प्रकाशित कर सकता है और न चन्द्रमा और न अग्नि। जिसे प्राप्त कर मनुष्य पुन: (संसार को) नहीं लौटते हैं, वह मेरा परम धाम है।।",
   "en": "Neither the sun, nor the moon, nor fire shines there. Those who go there never come back. For, O Arjuna, that is my celestial home!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "ममैवांशो जीवलोके जीवभूतः सनातनः।मनःषष्ठानीन्द्रियाणि प्रकृतिस्थानि कर्षति।।15.7।।",
   "tr": "mamaivānśho jīva-loke jīva-bhūtaḥ sanātanaḥ\nmanaḥ-ṣhaṣhṭhānīndriyāṇi prakṛiti-sthāni karṣhati",
   "hi": "इस जीव लोक में मेरा ही एक सनातन अंश जीव बना है। वह प्रकृति में स्थित हुआ (देहत्याग के समय) पाँचो इन्द्रियों तथा मन को अपनी ओर खींच लेता है अर्थात् उन्हें एकत्रित कर लेता है।।",
   "en": "It is only a very small part of My Eternal Self, which is the life of the universe, that draws around itself the six senses, with the mind being the last, which have their source in Nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "शरीरं यदवाप्नोति यच्चाप्युत्क्रामतीश्वरः।गृहीत्वैतानि संयाति वायुर्गन्धानिवाशयात्।।15.8।।",
   "tr": "śharīraṁ yad avāpnoti yach chāpy utkrāmatīśhvaraḥ\ngṛihītvaitāni sanyāti vāyur gandhān ivāśhayāt",
   "hi": "जब (देहादि का) ईश्वर (जीव) (एक शरीर से) उत्क्रमण करता है, तब इन (इन्द्रियों और मन) को ग्रहण कर अन्य शरीर में इस प्रकार ले जाता है, जैसे गन्ध के आश्रय (फूलादि) से गन्ध को वायु ले जाता है।।",
   "en": "When the Supreme Lord enters a body or leaves it, He gathers these senses together and travels with them, as the wind gathers perfume while passing through the flowers.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "श्रोत्रं चक्षुः स्पर्शनं च रसनं घ्राणमेव च।अधिष्ठाय मनश्चायं विषयानुपसेवते।।15.9।।",
   "tr": "śhrotraṁ chakṣhuḥ sparśhanaṁ cha rasanaṁ ghrāṇam eva cha\nadhiṣhṭhāya manaśh chāyaṁ viṣhayān upasevate",
   "hi": "(यह जीव) श्रोत्र, चक्षु, स्पर्शेन्द्रिय, रसना और घ्राण (नाक) इन इन्द्रियों तथा मन को आश्रय करके अर्थात् इनके द्वारा विषयों का सेवन करता है।।",
   "en": "He is the perception of the ear, the eye, the touch, the taste, the smell, and the mind; and the enjoyment of the things they perceive is also His.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "उत्क्रामन्तं स्थितं वापि भुञ्जानं वा गुणान्वितम्।विमूढा नानुपश्यन्ति पश्यन्ति ज्ञानचक्षुषः।।15.10।।",
   "tr": "utkrāmantaṁ sthitaṁ vāpi bhuñjānaṁ vā guṇānvitam\nvimūḍhā nānupaśhyanti paśhyanti jñāna-chakṣhuṣhaḥ",
   "hi": "शरीर को त्यागते हुये, उसमें स्थित हुये अथवा (विषयों को) भोगते हुये, गुणों से समन्वित आत्मा को विमूढ़ लोग नहीं देखते हैं; (परन्तु) ज्ञानचक्षु वाले पुरुष उसे देखते हैं।।",
   "en": "The ignorant do not see that it is He who is present in life and departs at death, or even that it is He who enjoys pleasure through the qualities. Only the eye of wisdom sees this.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "यतन्तो योगिनश्चैनं पश्यन्त्यात्मन्यवस्थितम्।यतन्तोऽप्यकृतात्मानो नैनं पश्यन्त्यचेतसः।।15.11।।",
   "tr": "yatanto yoginaśh chainaṁ paśhyanty ātmany avasthitam\nyatanto ‘py akṛitātmāno nainaṁ paśhyanty achetasaḥ",
   "hi": "योगीजन प्रयत्न करते हुये ही अपने हृदय में स्थित आत्मा को देखते हैं, जब कि अशुद्ध अन्त:करण वाले (अकृतात्मान:) और अविवेकी (अचेतस:) लोग यत्न करते हुये भी इसे नहीं देखते हैं।।",
   "en": "The saints, with great effort, find Him within themselves; however, the unintelligent, despite their efforts, cannot control their minds.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "यदादित्यगतं तेजो जगद्भासयतेऽखिलम्।यच्चन्द्रमसि यच्चाग्नौ तत्तेजो विद्धि मामकम्।।15.12।।",
   "tr": "yad āditya-gataṁ tejo jagad bhāsayate ’khilam\nyach chandramasi yach chāgnau tat tejo viddhi māmakam",
   "hi": "जो तेज सूर्य में स्थित होकर सम्पूर्ण जगत् को प्रकाशित करता है तथा जो तेज चन्द्रमा में है और अग्नि में है, उस तेज को तुम मेरा ही जानो।।",
   "en": "Remember that the light which proceeds from the sun, illuminating the whole world, and the light which is in the moon, and that which is in the fire, all are born of me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "गामाविश्य च भूतानि धारयाम्यहमोजसा।पुष्णामि चौषधीः सर्वाः सोमो भूत्वा रसात्मकः।।15.13।।",
   "tr": "gām āviśhya cha bhūtāni dhārayāmy aham ojasā\npuṣhṇāmi chauṣhadhīḥ sarvāḥ somo bhūtvā rasātmakaḥ",
   "hi": "मैं ही पृथ्वी में प्रवेश करके अपने ओज से भूतमात्र को धारण करता हूँ और रसस्वरूप चन्द्रमा बनकर समस्त औषधियों का अर्थात् वनस्पतियों का पोषण करता हूँ।।",
   "en": "I enter this world and animate all My creatures with My vitality; and by My cool moonbeams, I nourish the plants.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "अहं वैश्वानरो भूत्वा प्राणिनां देहमाश्रितः।प्राणापानसमायुक्तः पचाम्यन्नं चतुर्विधम्।।15.14।।",
   "tr": "ahaṁ vaiśhvānaro bhūtvā prāṇināṁ deham āśhritaḥ\nprāṇāpāna-samāyuktaḥ pachāmy annaṁ chatur-vidham",
   "hi": "मैं ही समस्त प्राणियों के देह में स्थित वैश्वानर अग्निरूप होकर प्राण और अपान से युक्त चार प्रकार के अन्न को पचाता हूँ।।",
   "en": "Becoming the fire of life, I pass into their bodies and, uniting with the vital streams of Prāṇa and Apāna, I digest the various kinds of food.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "सर्वस्य चाहं हृदि सन्निविष्टो    मत्तः स्मृतिर्ज्ञानमपोहनं च।वेदैश्च सर्वैरहमेव वेद्यो    वेदान्तकृद्वेदविदेव चाहम्।।15.15।।",
   "tr": "sarvasya chāhaṁ hṛidi sanniviṣhṭo\nmattaḥ smṛitir jñānam apohanaṁ cha\nvedaiśh cha sarvair aham eva vedyo\nvedānta-kṛid veda-vid eva chāham",
   "hi": "मैं ही समस्त प्राणियों के हृदय में स्थित हूँ। मुझसे ही स्मृति, ज्ञान और अपोहन (उनका अभाव) होता है। समस्त वेदों के द्वारा मैं ही वेद्य (जानने योग्य) वस्तु हूँ तथा वेदान्त का और वेदों का ज्ञाता भी मैं ही हूँ।।",
   "en": "I am enthroned in the hearts of all; memory, wisdom, and discrimination owe their origins to Me. I am He Who is to be realized in the scriptures; I inspire their wisdom, and I know their truth.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "द्वाविमौ पुरुषौ लोके क्षरश्चाक्षर एव च।क्षरः सर्वाणि भूतानि कूटस्थोऽक्षर उच्यते।।15.16।।",
   "tr": "dvāv imau puruṣhau loke kṣharaśh chākṣhara eva cha\nkṣharaḥ sarvāṇi bhūtāni kūṭa-stho ’kṣhara uchyate",
   "hi": "इस लोक में क्षर (नश्वर) और अक्षर (अनश्वर) ये दो पुरुष हैं, समस्त भूत क्षर हैं और 'कूटस्थ' अक्षर कहलाता है।।",
   "en": "There are two aspects in Nature: the perishable and the imperishable. All life in this world belongs to the former, while the unchanging element belongs to the latter.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "उत्तमः पुरुषस्त्वन्यः परमात्मेत्युदाहृतः।यो लोकत्रयमाविश्य बिभर्त्यव्यय ईश्वरः।।15.17।।",
   "tr": "uttamaḥ puruṣhas tv anyaḥ paramātmety udāhṛitaḥ\nyo loka-trayam āviśhya bibharty avyaya īśhvaraḥ",
   "hi": "परन्तु उत्तम पुरुष अन्य ही है, जो परमात्मा कहलाता है और जो तीनों लोकों में प्रवेश करके सबका धारण करने वाला अव्यय ईश्वर है।।",
   "en": "But I am higher than all, the Supreme God, the Absolute Self, the Eternal Lord, who pervades and upholds all the worlds.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "यस्मात्क्षरमतीतोऽहमक्षरादपि चोत्तमः।अतोऽस्मि लोके वेदे च प्रथितः पुरुषोत्तमः।।15.18।।",
   "tr": "yasmāt kṣharam atīto ’ham akṣharād api chottamaḥ\nato ’smi loke vede cha prathitaḥ puruṣhottamaḥ",
   "hi": "क्योंकि मैं क्षर से अतीत हूँ और अक्षर से भी उत्तम हूँ, इसलिये लोक में और वेद में भी पुरुषोत्तम के नाम से प्रसिद्ध हूँ।।",
   "en": "I am beyond comparison with the Eternal and the non-eternal; I am known as the Supreme Personality, the Highest God, by scriptures and sages.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "यो मामेवमसम्मूढो जानाति पुरुषोत्तमम्।स सर्वविद्भजति मां सर्वभावेन भारत।।15.19।।",
   "tr": "yo mām evam asammūḍho jānāti puruṣhottamam\nsa sarva-vid bhajati māṁ sarva-bhāvena bhārata",
   "hi": "हे भारत ! इस प्रकार, जो, संमोहरहित, पुरुष मुझ पुरुषोत्तम को जानता है, वह सर्वज्ञ होकर सम्पूर्ण भाव से अर्थात् पूर्ण हृदय से मेरी भक्ति करता है।।",
   "en": "He who, with unclouded vision, sees Me as the Lord-God, knows all that there is to be known and will always worship Me with his whole heart.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "इति गुह्यतमं शास्त्रमिदमुक्तं मयाऽनघ।एतद्बुद्ध्वा बुद्धिमान्स्यात्कृतकृत्यश्च भारत।।15.20।।",
   "tr": "iti guhyatamaṁ śhāstram idam uktaṁ mayānagha\netad buddhvā buddhimān syāt kṛita-kṛityaśh cha bhārata",
   "hi": "हे निष्पाप भारत ! इस प्रकार यह गुह्यतम शास्त्र मेरे द्वारा कहा गया, इसको जानकर मनुष्य बुद्धिमान और कृतकृत्य हो जाता है।।",
   "en": "Thus, O sinless one, I have revealed this most mystic knowledge to thee. He who understands it gains wisdom and attains the consummation of life.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
