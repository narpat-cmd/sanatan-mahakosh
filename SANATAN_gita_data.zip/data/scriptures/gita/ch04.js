// Bhagavad Gita adhyay 4 - Jnana Karma Sanyasa Yoga (42 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch04"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 4,
 "title": "ज्ञानकर्मसंन्यासयोग",
 "illustration": "",
 "illustrationCaption": "Path of Knowledge and the Disciplines of Action",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का चौथा अध्याय ज्ञानकर्मसंन्यासयोग योग है। इस अध्याय में श्रीकृष्ण कर्मयोग का गुणगान करते हैं अथवा अर्जुन को आत्मा एवं परम सत्य का बोध कराते हैं। वे भौतिक संसार में अपनी उपस्तिथि के पीछे कारण का वर्णन करते हैं। वे बताते हैं कि भले ही वह अनन्त हैं, फिर भी वह इस धरती पर धर्म और शांति को पुन: स्थापित करने के लिए समय समय पर जन्म लेते रहते हैं। उनके जन्म और क्रियाकलाप शाश्वत हैं और सामूहिक दोषों से कभी भी दूषित नहीं होते हैं। वे मनुष्य जो इस सत्य को जानते और समझते हैं, वे संपूर्ण श्रद्धा के साथ उनकी भक्ति करते हैं और अंततः उन्हें प्राप्त करते हैं। उनहे इस दुनिया में फिर से जन्म लेने की जरूरत नहीं है।",
 "summaryEn": "The fourth chapter of the Bhagavad Gita is \"Jnana Karma Sanyasa Yoga\". In this chapter, Krishna glorifies the Karma Yoga and imparts the Transcendental Knowledge (the knowledge of the soul and the Ultimate Truth) to Arjuna. He reveals the reason behind his appearance in this material world. He reveals that even though he is eternal, he reincarnates time after time to re-establish dharma and peace on this Earth. His births and activities are eternal and are never contaminated by material flaws. Those persons who know and understand this Truth engage in his devotion with full faith and eventually attain Him. They do not have to take birth in this world again.",
 "verses": [
  {
   "n": 1,
   "sa": "श्री भगवानुवाच\nइमं विवस्वते योगं प्रोक्तवानहमव्ययम्।\nविवस्वान् मनवे प्राह मनुरिक्ष्वाकवेऽब्रवीत्।।4.1।।",
   "tr": "śhrī bhagavān uvācha\nimaṁ vivasvate yogaṁ proktavān aham avyayam\nvivasvān manave prāha manur ikṣhvākave ’bravīt",
   "hi": "श्रीभगवान् ने कहा --- मैंने इस अविनाशी योग को विवस्वान् (सूर्य देवता) से कहा (सिखाया); विवस्वान् ने मनु से कहा; मनु ने इक्ष्वाकु से कहा।।",
   "en": "Lord Shri Krishna said: I taught this imperishable philosophy to Vivaswān, the founder of the Sun dynasty; Vivaswān gave it to Manu, the lawgiver, and Manu to King Ikshvāku.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "एवं परम्पराप्राप्तमिमं राजर्षयो विदुः।\nस कालेनेह महता योगो नष्टः परन्तप।।4.2।।",
   "tr": "evaṁ paramparā-prāptam imaṁ rājarṣhayo viduḥ\nsa kāleneha mahatā yogo naṣhṭaḥ parantapa",
   "hi": "इस प्रकार परम्परा से प्राप्त हुये इस योग को राजर्षियों ने जाना, (परन्तु) हे परन्तप ! वह योग बहुत काल (के अन्तराल) से यहाँ (इस लोक में) नष्टप्राय हो गया।।",
   "en": "The Divine Kings knew it, for it was their tradition; then, after a long time, it was at last forgotten.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "स एवायं मया तेऽद्य योगः प्रोक्तः पुरातनः।\nभक्तोऽसि मे सखा चेति रहस्यं ह्येतदुत्तमम्।।4.3।।",
   "tr": "sa evāyaṁ mayā te ’dya yogaḥ proktaḥ purātanaḥ\nbhakto ’si me sakhā cheti rahasyaṁ hyetad uttamam",
   "hi": "वह ही यह पुरातन योग आज मैंने तुम्हें कहा (सिखाया) क्योंकि तुम मेरे भक्त और मित्र हो। यह उत्तम रहस्य है।।",
   "en": "It is the same ancient path that I have now revealed to you, for you are my devotee and my friend. It is the supreme secret.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "अर्जुन उवाच\nअपरं भवतो जन्म परं जन्म विवस्वतः।\nकथमेतद्विजानीयां त्वमादौ प्रोक्तवानिति।।4.4।।",
   "tr": "arjuna uvācha\naparaṁ bhavato janma paraṁ janma vivasvataḥ\nkatham etad vijānīyāṁ tvam ādau proktavān iti",
   "hi": "अर्जुन ने कहा -- आपका जन्म अपर अर्थात् पश्चात का है और विवस्वान् का जन्म (आपके) पूर्व का है, इसलिये यह मैं कैसे जानूँ कि (सृष्टि के) आदि में आपने (इस योग को) कहा था?",
   "en": "Arjuna asked: My Lord! Vyasawana was born before You; how then can You have revealed it to him?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "श्री भगवानुवाच\nबहूनि मे व्यतीतानि जन्मानि तव चार्जुन।\nतान्यहं वेद सर्वाणि न त्वं वेत्थ परन्तप।।4.5।।",
   "tr": "śhrī bhagavān uvācha\nbahūni me vyatītāni janmāni tava chārjuna\ntānyahaṁ veda sarvāṇi na tvaṁ vettha parantapa",
   "hi": "श्रीभगवान् ने कहा -- हे अर्जुन ! मेरे और तुम्हारे बहुत से जन्म हो चुके हैं, (परन्तु) हे परन्तप ! उन सबको मैं जानता हूँ और तुम नहीं जानते।।",
   "en": "Lord Shri Krishna replied: I have been born again and again, from time to time; thou too, O Arjuna! My births are known to me, but yours are unknown to you.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "अजोऽपि सन्नव्ययात्मा भूतानामीश्वरोऽपि सन्।\nप्रकृतिं स्वामधिष्ठाय संभवाम्यात्ममायया।।4.6।।",
   "tr": "ajo ’pi sannavyayātmā bhūtānām īśhvaro ’pi san\nprakṛitiṁ svām adhiṣhṭhāya sambhavāmyātma-māyayā",
   "hi": "यद्यपि मैं अजन्मा और अविनाशी स्वरूप हूँ और भूतमात्र का ईश्वर हूँ (तथापि) अपनी प्रकृति को अपने अधीन रखकर (अधिष्ठाय) मैं अपनी माया से जन्म लेता हूँ।।",
   "en": "There is no beginning to Me. Though I am imperishable and the Lord of all that exists, I manifest Myself by My own will and power.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "यदा यदा हि धर्मस्य ग्लानिर्भवति भारत।\nअभ्युत्थानमधर्मस्य तदाऽऽत्मानं सृजाम्यहम्।।4.7।।",
   "tr": "yadā yadā hi dharmasya glānir bhavati bhārata\nabhyutthānam adharmasya tadātmānaṁ sṛijāmyaham",
   "hi": "हे भारत ! जब-जब धर्म की हानि और अधर्म की वृद्धि होती है, तब-तब मैं स्वयं को प्रकट करता हूँ।।",
   "en": "Whenever spirituality decays and materialism is rampant, then, O Arjuna, I reincarnate myself.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "परित्राणाय साधूनां विनाशाय च दुष्कृताम्।\nधर्मसंस्थापनार्थाय संभवामि युगे युगे।।4.8।।",
   "tr": "paritrāṇāya sādhūnāṁ vināśhāya cha duṣhkṛitām\ndharma-sansthāpanārthāya sambhavāmi yuge yuge",
   "hi": "साधु पुरुषों के रक्षण, दुष्कृत्य करने वालों के नाश, तथा धर्म संस्थापना के लिये, मैं प्रत्येक युग में प्रगट होता हूँ।।",
   "en": "To protect the righteous, to destroy the wicked, and to establish the kingdom of God, I am reborn from age to age.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "जन्म कर्म च मे दिव्यमेवं यो वेत्ति तत्त्वतः।\nत्यक्त्वा देहं पुनर्जन्म नैति मामेति सोऽर्जुन।।4.9।।",
   "tr": "janma karma cha me divyam evaṁ yo vetti tattvataḥ\ntyaktvā dehaṁ punar janma naiti mām eti so ’rjuna",
   "hi": "हे अर्जुन ! मेरा जन्म और कर्म दिव्य है, इस प्रकार जो पुरुष तत्त्वत: जानता है, वह शरीर को त्यागकर फिर जन्म को नहीं प्राप्त होता; वह मुझे ही प्राप्त होता है।।",
   "en": "He who realizes the divine truth concerning My birth and life does not take birth again; and when he leaves his body, he becomes one with Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "वीतरागभयक्रोधा मन्मया मामुपाश्रिताः।\nबहवो ज्ञानतपसा पूता मद्भावमागताः।।4.10।।",
   "tr": "vīta-rāga-bhaya-krodhā man-mayā mām upāśhritāḥ\nbahavo jñāna-tapasā pūtā mad-bhāvam āgatāḥ",
   "hi": "राग भय और क्रोध से रहित मनमय मेरे शरण हुए बहुत से पुरुष ज्ञान रुप तप से पवित्र‌ हुए मेरे स्वरुप को प्राप्त हुए हैं।।",
   "en": "Many have merged their existences in Mine, being freed from desire, fear, and anger, always filled with Me and purified by the illuminating flame of self-abnegation.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "ये यथा मां प्रपद्यन्ते तांस्तथैव भजाम्यहम्।\nमम वर्त्मानुवर्तन्ते मनुष्याः पार्थ सर्वशः।।4.11।।",
   "tr": "ye yathā māṁ prapadyante tāns tathaiva bhajāmyaham\nmama vartmānuvartante manuṣhyāḥ pārtha sarvaśhaḥ",
   "hi": "जो मुझे जैसे भजते हैं, मैं उन पर वैसे ही अनुग्रह करता हूँ; हे पार्थ सभी मनुष्य सब प्रकार से, मेरे ही मार्ग का अनुवर्तन करते हैं।।",
   "en": "However men try to worship Me, I welcome them. Whatever path they take, it leads to Me in the end.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "काङ्क्षन्तः कर्मणां सिद्धिं यजन्त इह देवताः।\nक्षिप्रं हि मानुषे लोके सिद्धिर्भवति कर्मजा।।4.12।।",
   "tr": "kāṅkṣhantaḥ karmaṇāṁ siddhiṁ yajanta iha devatāḥ\nkṣhipraṁ hi mānuṣhe loke siddhir bhavati karmajā",
   "hi": "(सामान्य मनुष्य) यहाँ (इस लोक में) कर्मों के फल को चाहते हुये देवताओं को पूजते हैं; क्योंकि मनुष्य लोक में कर्मों के फल शीघ्र ही प्राप्त होते हैं।।",
   "en": "Those who seek success worship the Powers, and their actions in this world bear immediate fruit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "चातुर्वर्ण्यं मया सृष्टं गुणकर्मविभागशः।\nतस्य कर्तारमपि मां विद्ध्यकर्तारमव्ययम्।।4.13।।",
   "tr": "chātur-varṇyaṁ mayā sṛiṣhṭaṁ guṇa-karma-vibhāgaśhaḥ\ntasya kartāram api māṁ viddhyakartāram avyayam",
   "hi": "गुण और कर्मों के विभाग से चातुर्वण्य मेरे द्वारा रचा गया है। यद्यपि मैं उसका कर्ता हूँ, तथापि तुम मुझे अकर्ता और अविनाशी जानो।।",
   "en": "The four divisions of society—the wise, the soldier, the merchant, and the laborer—were created by Me, according to the natural distribution of qualities and instincts. I am the author of them, though I Myself do not act and am changeless.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "न मां कर्माणि लिम्पन्ति न मे कर्मफले स्पृहा।\nइति मां योऽभिजानाति कर्मभिर्न स बध्यते।।4.14।।",
   "tr": "na māṁ karmāṇi limpanti na me karma-phale spṛihā\niti māṁ yo ’bhijānāti karmabhir na sa badhyate",
   "hi": "कर्म मुझे लिप्त नहीं करते; न मुझे कर्मफल में स्पृहा है। इस प्रकार मुझे जो जानता है, वह भी कर्मों से नहीं बन्धता है।।",
   "en": "My actions do not bind Me, nor do I desire anything that they can bring. He who thus realizes Me is not enslaved by action.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "एवं ज्ञात्वा कृतं कर्म पूर्वैरपि मुमुक्षुभिः।\nकुरु कर्मैव तस्मात्त्वं पूर्वैः पूर्वतरं कृतम्।।4.15।।",
   "tr": "evaṁ jñātvā kṛitaṁ karma pūrvair api mumukṣhubhiḥ\nkuru karmaiva tasmāttvaṁ pūrvaiḥ pūrvataraṁ kṛitam",
   "hi": "पूर्व के मुमुक्ष पुरुषों द्वारा भी इस प्रकार जानकर ही कर्म किया गया है; इसलिये तुम भी पूर्वजों द्वारा सदा से किये हुए कर्मों को ही करो।।",
   "en": "In the light of wisdom, our ancestors who sought deliverance performed their acts. Act thou also as our fathers of old did.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "किं कर्म किमकर्मेति कवयोऽप्यत्र मोहिताः।\nतत्ते कर्म प्रवक्ष्यामि यज्ज्ञात्वा मोक्ष्यसेऽशुभात्।।4.16।।",
   "tr": "kiṁ karma kim akarmeti kavayo ’pyatra mohitāḥ\ntat te karma pravakṣhyāmi yaj jñātvā mokṣhyase ’śhubhāt",
   "hi": "कर्म क्या है और अकर्म क्या है? इस विषय में बुद्धिमान पुरुष भी भ्रमित हो जाते हैं। इसलिये मैं तुम्हें कर्म कहूँगा, (अर्थात् कर्म और अकर्म का स्वरूप समझाऊँगा) जिसको जानकर तुम अशुभ (संसार बन्धन) से मुक्त हो जाओगे।।",
   "en": "What is action and what is inaction? This is a question that has bewildered the wise. But I will declare to you the philosophy of action, and knowing it, you will be free from evil.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "कर्मणो ह्यपि बोद्धव्यं बोद्धव्यं च विकर्मणः।\nअकर्मणश्च बोद्धव्यं गहना कर्मणो गतिः।।4.17।।",
   "tr": "karmaṇo hyapi boddhavyaṁ boddhavyaṁ cha vikarmaṇaḥ\nakarmaṇaśh cha boddhavyaṁ gahanā karmaṇo gatiḥ",
   "hi": "कर्म का (स्वरूप) जानना चाहिये और विकर्म का (स्वरूप) भी जानना चाहिये ; (बोद्धव्यम्) तथा अकर्म का भी (स्वरूप) जानना चाहिये (क्योंकि) कर्म की गति गहन है।।",
   "en": "It is necessary to consider what is right action, what is wrong action, and what is inaction, for the law of action is mysterious.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "कर्मण्यकर्म यः पश्येदकर्मणि च कर्म यः।\nस बुद्धिमान् मनुष्येषु स युक्तः कृत्स्नकर्मकृत्।।4.18।।",
   "tr": "karmaṇyakarma yaḥ paśhyed akarmaṇi cha karma yaḥ\nsa buddhimān manuṣhyeṣhu sa yuktaḥ kṛitsna-karma-kṛit",
   "hi": "जो पुरुष कर्म में अकर्म और अकर्म में कर्म देखता है, वह मनुष्यों में बुद्धिमान है, वह योगी सम्पूर्ण कर्मों को करने वाला है।।",
   "en": "He who can see inaction in action, and action in inaction, is the wisest among men. He is a saint, even though he still acts.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "यस्य सर्वे समारम्भाः कामसङ्कल्पवर्जिताः।\nज्ञानाग्निदग्धकर्माणं तमाहुः पण्डितं बुधाः।।4.19।।",
   "tr": "yasya sarve samārambhāḥ kāma-saṅkalpa-varjitāḥ\njñānāgni-dagdha-karmāṇaṁ tam āhuḥ paṇḍitaṁ budhāḥ",
   "hi": "जिसके समस्त कार्य कामना और संकल्प से रहित हैं, ऐसे उस ज्ञानरूप अग्नि के द्वारा भस्म हुये कर्मों वाले पुरुष को ज्ञानीजन पण्डित कहते हैं।।",
   "en": "The wise call him a sage, for whatever he undertakes is free from the motive of desire, and his deeds are purified by the fire of wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "त्यक्त्वा कर्मफलासङ्गं नित्यतृप्तो निराश्रयः।\nकर्मण्यभिप्रवृत्तोऽपि नैव किञ्चित्करोति सः।।4.20।।",
   "tr": "tyaktvā karma-phalāsaṅgaṁ nitya-tṛipto nirāśhrayaḥ\nkarmaṇyabhipravṛitto ’pi naiva kiñchit karoti saḥ",
   "hi": "जो पुरुष, कर्मफलासक्ति को त्यागकर, नित्यतृप्त और सब आश्रयों से रहित है वह कर्म में प्रवृत्त होते हुए भी (वास्तव में) कुछ भी नहीं करता है।।",
   "en": "Having surrendered all claim to the results of his actions, he is always contented and independent; in reality, he does nothing, even though he appears to be acting.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "निराशीर्यतचित्तात्मा त्यक्तसर्वपरिग्रहः।\nशारीरं केवलं कर्म कुर्वन्नाप्नोति किल्बिषम्।।4.21।।",
   "tr": "nirāśhīr yata-chittātmā tyakta-sarva-parigrahaḥ\nśhārīraṁ kevalaṁ karma kurvan nāpnoti kilbiṣham",
   "hi": "जो आशा रहित है तथा जिसने चित्त और आत्मा (शरीर) को संयमित किया है, जिसने सब परिग्रहों का त्याग किया है, ऐसा पुरुष शारीरिक कर्म करते हुए भी पाप को नहीं प्राप्त होता है।।",
   "en": "Expecting nothing, his mind and personality controlled, without greed, doing only bodily actions; though he acts, he remains untainted.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "यदृच्छालाभसन्तुष्टो द्वन्द्वातीतो विमत्सरः।\nसमः सिद्धावसिद्धौ च कृत्वापि न निबध्यते।।4.22।।",
   "tr": "yadṛichchhā-lābha-santuṣhṭo dvandvātīto vimatsaraḥ\nsamaḥ siddhāvasiddhau cha kṛitvāpi na nibadhyate",
   "hi": "यदृच्छया (अपने आप) जो कुछ प्राप्त हो उसमें ही सन्तुष्ट रहने वाला, द्वन्द्वों से अतीत तथा मत्सर से रहित, सिद्धि व असिद्धि में समभाव वाला पुरुष कर्म करके भी नहीं बन्धता है।।",
   "en": "Content with what comes to him without any effort of his own, rising above the pairs of opposites, free from envy, his mind balanced in both success and failure; though he acts, the consequences do not bind him.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "गतसङ्गस्य मुक्तस्य ज्ञानावस्थितचेतसः।\nयज्ञायाचरतः कर्म समग्रं प्रविलीयते।।4.23।।",
   "tr": "gata-saṅgasya muktasya jñānāvasthita-chetasaḥ\nyajñāyācharataḥ karma samagraṁ pravilīyate",
   "hi": "जो आसक्तिरहित और मुक्त है, जिसका चित्त ज्ञान में स्थित है, यज्ञ के लिये आचरण करने वाले ऐसे पुरुष के समस्त कर्म लीन हो जाते हैं।।",
   "en": "He who is without attachment, free, his mind centered in wisdom, and his actions done as a sacrifice, leave no trace behind.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "ब्रह्मार्पणं ब्रह्महविर्ब्रह्माग्नौ ब्रह्मणा हुतम्।\nब्रह्मैव तेन गन्तव्यं ब्रह्मकर्मसमाधिना।।4.24।।",
   "tr": "brahmārpaṇaṁ brahma havir brahmāgnau brahmaṇā hutam\nbrahmaiva tena gantavyaṁ brahma-karma-samādhinā",
   "hi": "अर्पण (अर्थात् अर्पण करने का साधन श्रुवा) ब्रह्म है और हवि (शाकल्य अथवा हवन करने योग्य द्रव्य) भी ब्रह्म है; ब्रह्मरूप अग्नि में ब्रह्मरूप कर्ता के द्वारा जो हवन किया गया है, वह भी ब्रह्म ही है। इस प्रकार ब्रह्मरूप कर्म में समाधिस्थ पुरुष का गन्तव्य भी ब्रह्म ही है।।",
   "en": "For him, the sacrifice is the Spirit; the Spirit and the offering are one; it is the Spirit that is sacrificed in its own fire, and the man, even in action, is united with God, since his mind never ceases to be fixed on Him while performing the act.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "दैवमेवापरे यज्ञं योगिनः पर्युपासते।\nब्रह्माग्नावपरे यज्ञं यज्ञेनैवोपजुह्वति।।4.25।।",
   "tr": "daivam evāpare yajñaṁ yoginaḥ paryupāsate\nbrahmāgnāvapare yajñaṁ yajñenaivopajuhvati",
   "hi": "कोई योगीजन देवताओं के पूजनरूप यज्ञ को ही करते हैं ; और दूसरे (ज्ञानीजन) ब्रह्मरूप अग्नि में यज्ञ के द्वारा यज्ञ को हवन करते हैं।।",
   "en": "Some sages sacrifice to the powers, while others offer themselves on the altar of the eternal.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "श्रोत्रादीनीन्द्रियाण्यन्ये संयमाग्निषु जुह्वति।\nशब्दादीन्विषयानन्य इन्द्रियाग्निषु जुह्वति।।4.26।।",
   "tr": "śhrotrādīnīndriyāṇyanye sanyamāgniṣhu juhvati\nśhabdādīn viṣhayānanya indriyāgniṣhu juhvati",
   "hi": "अन्य (योगीजन) श्रोत्रादिक सब इन्द्रियों को संयमरूप अग्नि में हवन करते हैं, और अन्य (लोग) शब्दादिक विषयों को इन्द्रियरूप अग्नि में हवन करते हैं।।",
   "en": "Some sacrifice their physical senses in the fire of self-control; others offer up their contact with external objects in the sacrificial fire of their senses.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "सर्वाणीन्द्रियकर्माणि प्राणकर्माणि चापरे।\nआत्मसंयमयोगाग्नौ जुह्वति ज्ञानदीपिते।।4.27।।",
   "tr": "sarvāṇīndriya-karmāṇi prāṇa-karmāṇi chāpare\nātma-sanyama-yogāgnau juhvati jñāna-dīpite",
   "hi": "दूसरे (योगीजन) सम्पूर्ण इन्द्रियों के तथा प्राणों के कर्मों को ज्ञान से प्रकाशित आत्मसंयमयोगरूप अग्नि में हवन करते हैं।।",
   "en": "Others again sacrifice their activities and vitality in the spiritual fire of self-abnegation, kindled by wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "द्रव्ययज्ञास्तपोयज्ञा योगयज्ञास्तथापरे।\nस्वाध्यायज्ञानयज्ञाश्च यतयः संशितव्रताः।।4.28।।",
   "tr": "dravya-yajñās tapo-yajñā yoga-yajñās tathāpare\nswādhyāya-jñāna-yajñāśh cha yatayaḥ sanśhita-vratāḥ",
   "hi": "कुछ (साधक) द्रव्ययज्ञ, तपयज्ञ और योगयज्ञ करने वाले होते हैं; और दूसरे कठिन व्रत करने वाले स्वाध्याय और ज्ञानयज्ञ करने वाले योगीजन होते हैं।।",
   "en": "Others offer as their sacrifice wealth, austerities, and meditation. Monks, wedded to their vows, renounce their scriptural learning and even their spiritual powers.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "अपाने जुह्वति प्राण प्राणेऽपानं तथाऽपरे।\nप्राणापानगती रुद्ध्वा प्राणायामपरायणाः।।4.29।।",
   "tr": "apāne juhvati prāṇaṁ prāṇe ’pānaṁ tathāpare\nprāṇāpāna-gatī ruddhvā prāṇāyāma-parāyaṇāḥ\napare niyatāhārāḥ prāṇān prāṇeṣhu juhvati\nsarve ’pyete yajña-vido yajña-kṣhapita-kalmaṣhāḥ",
   "hi": "अन्य (योगीजन) अपानवायु में प्राणवायु को हवन करते हैं, तथा प्राण में अपान की आहुति देते हैं, प्राण और अपान की गति को रोककर, वे प्राणायाम के ही समलक्ष्य समझने वाले होते हैं।।",
   "en": "There are some who practice controlling the vital energy and governing the subtle forces of prana and apana, thereby sacrificing their prana to apana, or their apana to prana.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 30,
   "sa": "अपरे नियताहाराः प्राणान्प्राणेषु जुह्वति।\nसर्वेऽप्येते यज्ञविदो यज्ञक्षपितकल्मषाः।।4.30।।",
   "tr": "apare niyatāhārāḥ prāṇān  prāṇeṣu juhvati\nsarve py 'ete yajña-vido yajña-kṣapita-kalmaṣāḥ",
   "hi": "दूसरे नियमित आहार करने वाले (साधक जन) प्राणों को प्राणों में हवन करते हैं। ये सभी यज्ञ को जानने वाले हैं, जिनके पाप यज्ञ के द्वारा नष्ट हो चुके हैं।।",
   "en": "Others, controlling their diet, sacrifice their worldly life to the spiritual fire. All understand the principle of sacrifice, and by it their sins are washed away.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 31,
   "sa": "यज्ञशिष्टामृतभुजो यान्ति ब्रह्म सनातनम्।\nनायं लोकोऽस्त्ययज्ञस्य कुतो़ऽन्यः कुरुसत्तम।।4.31।।",
   "tr": "yajña-śhiṣhṭāmṛita-bhujo yānti brahma sanātanam\nnāyaṁ loko ’styayajñasya kuto ’nyaḥ kuru-sattama",
   "hi": "हे कुरुश्रेष्ठ ! यज्ञ के अवशिष्ट अमृत को भोगने वाले पुरुष सनातन ब्रह्म को प्राप्त होते हैं। यज्ञ रहित पुरुष को यह लोक भी नहीं मिलता, फिर परलोक कैसे मिलेगा?",
   "en": "Tasting the nectar of immortality, as the reward of sacrifice, they reach the Eternal. This world is not for those who refuse to sacrifice; nor is the other world.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 32,
   "sa": "एवं बहुविधा यज्ञा वितता ब्रह्मणो मुखे।\nकर्मजान्विद्धि तान्सर्वानेवं ज्ञात्वा विमोक्ष्यसे।।4.32।।",
   "tr": "evaṁ bahu-vidhā yajñā vitatā brahmaṇo mukhe\nkarma-jān viddhi tān sarvān evaṁ jñātvā vimokṣhyase",
   "hi": "ऐसे अनेक प्रकार के यज्ञों का ब्रह्मा के मुख अर्थात् वेदों में प्रसार है अर्थात् वर्णित हैं। उन सब को कर्मों से उत्पन्न हुए जानो; इस प्रकार जानकर तुम मुक्त हो जाओगे।।",
   "en": "In this way, other sacrifices may also be undertaken for the sake of the Spirit. Know that they all depend on action. Knowing this, you will be free.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 33,
   "sa": "श्रेयान्द्रव्यमयाद्यज्ञाज्ज्ञानयज्ञः परन्तप।\nसर्वं कर्माखिलं पार्थ ज्ञाने परिसमाप्यते।।4.33।।",
   "tr": "śhreyān dravya-mayād yajñāj jñāna-yajñaḥ parantapa\nsarvaṁ karmākhilaṁ pārtha jñāne parisamāpyate",
   "hi": "हे परन्तप ! द्रव्यों से सम्पन्न होने वाले यज्ञ की अपेक्षा ज्ञानयज्ञ श्रेष्ठ है। हे पार्थ ! सम्पूर्ण अखिल कर्म ज्ञान में समाप्त होते हैं, अर्थात् ज्ञान उनकी पराकाष्ठा है।।",
   "en": "The sacrifice of wisdom is superior to any material sacrifice, for, O Arjuna, the pinnacle of action is always realization.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 34,
   "sa": "तद्विद्धि प्रणिपातेन परिप्रश्नेन सेवया।\nउपदेक्ष्यन्ति ते ज्ञानं ज्ञानिनस्तत्त्वदर्शिनः।।4.34।।",
   "tr": "tad viddhi praṇipātena paripraśhnena sevayā\nupadekṣhyanti te jñānaṁ jñāninas tattva-darśhinaḥ",
   "hi": "उस (ज्ञान) को (गुरु के समीप जाकर) साष्टांग प्रणिपात, प्रश्न तथा सेवा करके जानो; ये तत्त्वदर्शी ज्ञानी पुरुष तुम्हें ज्ञान का उपदेश करेंगे।।",
   "en": "This you shall learn by prostrating yourself at the master's feet, questioning them, and serving them. The wise who have realized the truth will teach you wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 35,
   "sa": "यज्ज्ञात्वा न पुनर्मोहमेवं यास्यसि पाण्डव।\nयेन भूतान्यशेषेण द्रक्ष्यस्यात्मन्यथो मयि।।4.35।।",
   "tr": "yaj jñātvā na punar moham evaṁ yāsyasi pāṇḍava\nyena bhūtānyaśheṣheṇa drakṣhyasyātmanyatho mayi",
   "hi": "जिसको जानकर तुम पुन इस प्रकार मोह को नहीं प्राप्त होगे, और हे पाण्डव ! जिसके द्वारा तुम भूतमात्र को अपने आत्मस्वरूप में तथा मुझमें भी देखोगे।।",
   "en": "Having known That, you shall never again be confounded; and, O Arjuna, by the power of that wisdom, you shall see all these people as if they were your own Self, and therefore as Me.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 36,
   "sa": "अपि चेदसि पापेभ्यः सर्वेभ्यः पापकृत्तमः।\nसर्वं ज्ञानप्लवेनैव वृजिनं सन्तरिष्यसि।।4.36।।",
   "tr": "api ched asi pāpebhyaḥ sarvebhyaḥ pāpa-kṛit-tamaḥ\nsarvaṁ jñāna-plavenaiva vṛijinaṁ santariṣhyasi",
   "hi": "यदि तुम सब पापियों से भी अधिक पाप करने वाले हो, तो भी ज्ञानरूपी नौका द्वारा, निश्चय ही सम्पूर्ण पापों का तुम संतरण कर जाओगे।।",
   "en": "Even if you are the greatest of sinners, you will cross over all sin by the ferryboat of wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 37,
   "sa": "यथैधांसि समिद्धोऽग्निर्भस्मसात्कुरुतेऽर्जुन।\nज्ञानाग्निः सर्वकर्माणि भस्मसात्कुरुते तथा।।4.37।।",
   "tr": "yathaidhānsi samiddho ’gnir bhasma-sāt kurute ’rjuna\njñānāgniḥ sarva-karmāṇi bhasma-sāt kurute tathā",
   "hi": "जैसे प्रज्जवलित अग्नि ईन्धन को भस्मसात् कर देती है, वैसे ही, हे अर्जुन ! ज्ञानरूपी अग्नि सम्पूर्ण कर्मों को भस्मसात् कर देती है।।",
   "en": "As the kindled fire consumes the fuel, so, O Arjuna, the embers of action are burnt to ashes in the flame of wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 38,
   "sa": "न हि ज्ञानेन सदृशं पवित्रमिह विद्यते।\nतत्स्वयं योगसंसिद्धः कालेनात्मनि विन्दति।।4.38।।",
   "tr": "na hi jñānena sadṛiśhaṁ pavitramiha vidyate\ntatsvayaṁ yogasansiddhaḥ kālenātmani vindati",
   "hi": "इस लोक में ज्ञान के समान पवित्र करने वाला, निसंदेह, कुछ भी नहीं है। योग में संसिद्ध पुरुष स्वयं ही उसे (उचित) काल में आत्मा में प्राप्त करता है।।",
   "en": "There is nothing in the world so purifying as wisdom; and he who is a perfect saint finds that at last within himself.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 39,
   "sa": "श्रद्धावाँल्लभते ज्ञानं तत्परः संयतेन्द्रियः।\nज्ञानं लब्ध्वा परां शान्तिमचिरेणाधिगच्छति।।4.39।।",
   "tr": "śhraddhāvān labhate jñānaṁ tat-paraḥ sanyatendriyaḥ\njñānaṁ labdhvā parāṁ śhāntim achireṇādhigachchhati",
   "hi": "श्रद्धावान्, तत्पर और जितेन्द्रिय पुरुष ज्ञान प्राप्त करता है। ज्ञान को प्राप्त करके शीघ्र ही वह परम शान्ति को प्राप्त होता है।।",
   "en": "He who is full of faith attains wisdom, and he who can control his senses, having attained that wisdom, will soon attain Supreme Peace.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 40,
   "sa": "अज्ञश्चाश्रद्दधानश्च संशयात्मा विनश्यति।\nनायं लोकोऽस्ति न परो न सुखं संशयात्मनः।।4.40।।",
   "tr": "ajñaśh chāśhraddadhānaśh cha sanśhayātmā vinaśhyati\nnāyaṁ loko ’sti na paro na sukhaṁ sanśhayātmanaḥ",
   "hi": "अज्ञानी तथा श्रद्धारहित और संशययुक्त पुरुष नष्ट हो जाता है, (उनमें भी) संशयी पुरुष के लिये न यह लोक है, न परलोक और न सुख।।",
   "en": "But the ignorant man, and he who has no faith, and the skeptic are lost. Neither in this world nor elsewhere is there any happiness in store for him who always doubts.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 41,
   "sa": "योगसंन्यस्तकर्माणं ज्ञानसंछिन्नसंशयम्।\nआत्मवन्तं न कर्माणि निबध्नन्ति धनञ्जय।।4.41।।",
   "tr": "yoga-sannyasta-karmāṇaṁ jñāna-sañchhinna-sanśhayam\nātmavantaṁ na karmāṇi nibadhnanti dhanañjaya",
   "hi": "जिसने योगद्वारा कर्मों का संन्यास किया है, ज्ञानद्वारा जिसके संशय नष्ट हो गये हैं, ऐसे आत्मवान् पुरुष को, हे धनंजय ! कर्म नहीं बांधते हैं।।",
   "en": "But the one who has renounced their actions for meditation, who has cleaved their doubts in two by the sword of wisdom, and who remains always enthroned in their Self, is not bound by their actions.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 42,
   "sa": "तस्मादज्ञानसंभूतं हृत्स्थं ज्ञानासिनाऽऽत्मनः।\nछित्त्वैनं संशयं योगमातिष्ठोत्तिष्ठ भारत।।4.42।।",
   "tr": "tasmād ajñāna-sambhūtaṁ hṛit-sthaṁ jñānāsinātmanaḥ\nchhittvainaṁ sanśhayaṁ yogam ātiṣhṭhottiṣhṭha bhārata",
   "hi": "इसलिये अपने हृदय में स्थित अज्ञान से उत्पन्न आत्मविषयक संशय को ज्ञान खड्ग से काटकर, हे भारत ! योग का आश्रय लेकर खड़े हो जाओ।।",
   "en": "Therefore, cleave asunder with the sword of wisdom the doubts of the heart, which your own ignorance has engendered, and follow the path of wisdom and arise!",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
