// Bhagavad Gita adhyay 17 - Sraddhatraya Vibhaga Yoga (28 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch17"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 17,
 "title": "श्रद्धात्रयविभागयोग",
 "illustration": "",
 "illustrationCaption": "Yoga through Discerning the Three Divisions of Faith",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का सत्रहवा अध्याय श्रद्धात्रयविभागयोग है। इस अध्याय में, कृष्ण भौतिक प्रकृति के तीन गुणों से संबंधित तीन प्रकार के विश्वासों का वर्णन करते हैं। भगवान कृष्ण आगे बताते हैं कि यह विश्वास की प्रकृति है जो जीवन की गुणवत्ता और जीवित संस्थाओं के चरित्र को निर्धारित करती है। जो लोग लालसा और अज्ञानता में विश्वास रखते हैं, वे ऐसे कार्य करते हैं जो कि अस्थायी और भौतिक फल देते हैं परन्तु जो लोग अच्छाई में विश्वास रखते हैं वे शास्त्रपूर्ण निर्देशों के अनुसार कार्य करते हैं और इसलिए उन्हें स्थायी और अधिक प्रवीण फल प्राप्त होते हैं जो मन को और भी शुद्ध करते हैं।        ",
 "summaryEn": "The seventeenth chapter of the Bhagavad Gita is \"Sraddhatraya Vibhaga Yoga\". In this chapter, Krishna describes the three types of faith corresponding to the three modes of the material nature. Lord Krishna further reveals that it is the nature of faith that determines the quality of life and the character of living entities. Those who have faith in passion and ignorance perform actions that yield temporary, material results while those who have faith in goodness perform actions in accordance with scriptural instructions and hence their hearts get further purified.",
 "verses": [
  {
   "n": 1,
   "sa": "अर्जुन उवाचये शास्त्रविधिमुत्सृज्य यजन्ते श्रद्धयाऽन्विताः।तेषां निष्ठा तु का कृष्ण सत्त्वमाहो रजस्तमः।।17.1।।",
   "tr": "arjuna uvācha\nye śhāstra-vidhim utsṛijya yajante śhraddhayānvitāḥ\nteṣhāṁ niṣhṭhā tu kā kṛiṣhṇa sattvam āho rajas tamaḥ",
   "hi": "अर्जुन ने कहा -- हे कृष्ण ! जो लोग शास्त्रविधि को त्यागकर (केवल) श्रद्धा युक्त यज्ञ (पूजा) करते हैं, उनकी स्थिति (निष्ठा) कौन सी है ?क्या वह सात्त्विक है अथवा राजसिक या तामसिक ?",
   "en": "Arjuna asked, \"My Lord, what is the condition of those who perform acts of sacrifice not according to the scriptures, but with implicit faith? Is it one of purity, passion, or ignorance?\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "श्री भगवानुवाचत्रिविधा भवति श्रद्धा देहिनां सा स्वभावजा।सात्त्विकी राजसी चैव तामसी चेति तां श्रृणु।।17.2।।",
   "tr": "śhrī-bhagavān uvācha\ntri-vidhā bhavati śhraddhā dehināṁ sā svabhāva-jā\nsāttvikī rājasī chaiva tāmasī cheti tāṁ śhṛiṇu",
   "hi": "श्री भगवान् ने कहा -- देहधारियों (मनुष्यों) की वह स्वाभाविक (ज्ञानरहित) श्रद्धा तीन प्रकार की - सात्त्विक, राजसिक और तामसिक - होती हैं, उसे तुम मुझसे सुनो।।",
   "en": "Lord Shri Krishna replied: Man has an inherent faith in one or another of the qualities—purity, passion, and ignorance. Now, listen.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "सत्त्वानुरूपा सर्वस्य श्रद्धा भवति भारत।श्रद्धामयोऽयं पुरुषो यो यच्छ्रद्धः स एव सः।।17.3।।",
   "tr": "sattvānurūpā sarvasya śhraddhā bhavati bhārata\nśhraddhā-mayo ‘yaṁ puruṣho yo yach-chhraddhaḥ sa eva saḥ",
   "hi": "हे भारत सभी मनुष्यों की श्रद्धा उनके सत्त्व (स्वभाव, संस्कार) के अनुरूप होती है। यह पुरुष श्रद्धामय है, इसलिए जो पुरुष जिस श्रद्धा वाला है वह स्वयं भी वही है अर्थात् जैसी जिसकी श्रद्धा वैसा ही उसका स्वरूप होता है।।",
   "en": "Every person's faith conforms to their nature. By nature, they are full of faith. They are, in fact, what their faith makes them.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "यजन्ते सात्त्विका देवान्यक्षरक्षांसि राजसाः।प्रेतान्भूतगणांश्चान्ये यजन्ते तामसा जनाः।।17.4।।",
   "tr": "yajante sāttvikā devān yakṣha-rakṣhānsi rājasāḥ\npretān bhūta-gaṇānśh chānye yajante tāmasā janāḥ",
   "hi": "सात्त्विक पुरुष देवताओं को पूजते हैं और राजस लोग यक्ष और राक्षसों को, तथा अन्य तामसी जन प्रेत और भूतगणों को पूजते हैं।।",
   "en": "The pure worship the true God; the passionate, the powers of wealth and magic; the ignorant, the spirits of the dead and lower orders of nature.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "अशास्त्रविहितं घोरं तप्यन्ते ये तपो जनाः।दम्भाहङ्कारसंयुक्ताः कामरागबलान्विताः।।17.5।।",
   "tr": "aśhāstra-vihitaṁ ghoraṁ tapyante ye tapo janāḥ\ndambhāhankāra-sanyuktāḥ kāma-rāga-balānvitāḥ",
   "hi": "जो लोग शास्त्रविधि से रहित घोर तप करते हैं तथा दम्भ, अहंकार, काम और राग से भी युक्त होते हैं।।",
   "en": "Those who practice austerities not commanded by scripture, who are enslaved to hypocrisy and egotism, who are carried away by the fury of desire and passion,",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "कर्षयन्तः शरीरस्थं भूतग्राममचेतसः।मां चैवान्तःशरीरस्थं तान्विद्ध्यासुरनिश्चयान्।।17.6।।",
   "tr": "karṣhayantaḥ śharīra-sthaṁ bhūta-grāmam achetasaḥ\nmāṁ chaivāntaḥ śharīra-sthaṁ tān viddhy āsura-niśhchayān",
   "hi": "और शरीरस्थ भूतसमुदाय को तथा मुझ अन्तर्यामी को भी कृश करने वाले अर्थात् कष्ट पहुँचाने वाले जो अविवेकी लोग हैं, उन्हें तुम आसुरी निश्चय वाले जानो।।",
   "en": "They are ignorant and torment the organs of the body, harassing Me who lives within. Know that they are devoted to evil.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "आहारस्त्वपि सर्वस्य त्रिविधो भवति प्रियः।यज्ञस्तपस्तथा दानं तेषां भेदमिमं श्रृणु।।17.7।।",
   "tr": "āhāras tv api sarvasya tri-vidho bhavati priyaḥ\nyajñas tapas tathā dānaṁ teṣhāṁ bhedam imaṁ śhṛiṇu",
   "hi": "(अपनीअपनी प्रकृति के अनुसार) सब का प्रिय भोजन भी तीन प्रकार का होता है? उसी प्रकार यज्ञ? तप और दान भी तीन प्रकार के होते हैं? उनके भेद को तुम मुझसे सुनो।।",
   "en": "The food that people enjoy is also threefold, like the ways of sacrifice, austerity, and almsgiving. Listen to the distinction.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "आयुःसत्त्वबलारोग्यसुखप्रीतिविवर्धनाः।रस्याः स्निग्धाः स्थिरा हृद्या आहाराः सात्त्विकप्रियाः।।17.8।।",
   "tr": "āyuḥ-sattva-balārogya-sukha-prīti-vivardhanāḥ\nrasyāḥ snigdhāḥ sthirā hṛidyā āhārāḥ sāttvika-priyāḥ",
   "hi": "आयु, सत्त्व (शुद्धि), बल, आरोग्य, सुख और प्रीति को प्रवृद्ध करने वाले एवं रसयुक्त, स्निग्ध ( घी आदि की चिकनाई से युक्त) स्थिर तथा मन को प्रसन्न करने वाले आहार अर्थात् भोज्य पदार्थ सात्त्विक पुरुषों को प्रिय होते हैं।।",
   "en": "The foods that prolong life, increase purity, vigour, health, cheerfulness, and happiness are those that are delicious, soothing, substantial, and agreeable; these are loved by the pure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "कट्वम्ललवणात्युष्णतीक्ष्णरूक्षविदाहिनः।आहारा राजसस्येष्टा दुःखशोकामयप्रदाः।।17.9।।",
   "tr": "kaṭv-amla-lavaṇāty-uṣhṇa- tīkṣhṇa-rūkṣha-vidāhinaḥ\nāhārā rājasasyeṣhṭā duḥkha-śhokāmaya-pradāḥ",
   "hi": "कड़वे, खट्टे, लवणयुक्त, अति उष्ण, तीक्ष्ण (तीखे, मिर्च युक्त), रूखे. दाहकारक, दु:ख, शोक और रोग उत्पन्न कारक भोज्य पदार्थ राजस पुरुष को प्रिय होते हैं।।",
   "en": "Those in whom passion is dominant like foods that are bitter, sour, salty, overly hot, pungent, dry, and burning. These produce unhappiness, repentance, and disease.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "यातयामं गतरसं पूति पर्युषितं च यत्।उच्छिष्टमपि चामेध्यं भोजनं तामसप्रियम्।।17.10।।",
   "tr": "yāta-yāmaṁ gata-rasaṁ pūti paryuṣhitaṁ cha yat\nuchchhiṣhṭam api chāmedhyaṁ bhojanaṁ tāmasa-priyam",
   "hi": "अर्धपक्व, रसरहित, दुर्गन्धयुक्त, बासी, उच्छिष्ट तथा अपवित्र (अमेध्य) अन्न तामस जनों को प्रिय होता है।।",
   "en": "The ignorant love food that is stale, not nourishing, putrid, and corrupt; the leftovers of others, and unclean.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "अफलाकाङ्क्षिभिर्यज्ञो विधिदृष्टो य इज्यते।यष्टव्यमेवेति मनः समाधाय स सात्त्विकः।।17.11।।",
   "tr": "aphalākāṅkṣhibhir yajño vidhi-driṣhṭo ya ijyate\nyaṣhṭavyam eveti manaḥ samādhāya sa sāttvikaḥ",
   "hi": "जो यज्ञ शास्त्रविधि से नियन्त्रित किया हुआ तथा जिसे \"यह मेरा कर्तव्य है\" ऐसा मन का समाधान (निश्चय) कर फल की आकांक्षा नहीं रखने वाले लोगों के द्वारा किया जाता है, वह यज्ञ सात्त्विक है।।",
   "en": "Sacrifice is pure when it is offered by one who does not covet the fruit of it, when it is done according to the commands of scripture, and with implicit faith that the sacrifice is a duty.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "अभिसंधाय तु फलं दम्भार्थमपि चैव यत्।इज्यते भरतश्रेष्ठ तं यज्ञं विद्धि राजसम्।।17.12।।",
   "tr": "abhisandhāya tu phalaṁ dambhārtham api chaiva yat\nijyate bharata-śhreṣhṭha taṁ yajñaṁ viddhi rājasam",
   "hi": "हे भरतश्रेष्ठ अर्जुन ! जो यज्ञ दम्भ के लिए तथा फल की आकांक्षा रख कर किया जाता है, उस यज्ञ को तुम राजस समझो।।",
   "en": "Sacrifice which is performed for the sake of its results, or for self-glorification - that, O best of Aryans, is the product of passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "विधिहीनमसृष्टान्नं मन्त्रहीनमदक्षिणम्।श्रद्धाविरहितं यज्ञं तामसं परिचक्षते।।17.13।।",
   "tr": "vidhi-hīnam asṛiṣhṭānnaṁ mantra-hīnam adakṣhiṇam\nśhraddhā-virahitaṁ yajñaṁ tāmasaṁ parichakṣhate",
   "hi": "शास्त्रविधि से रहित, अन्नदान से रहित, बिना मन्त्रों, बिना दक्षिणा और बिना श्रद्धा के किये हुए यज्ञ को तामस यज्ञ कहते हैं।।",
   "en": "Sacrifice that is contrary to scriptural command, that is unaccompanied by prayers or gifts of food or money, and is without faith—that is the product of ignorance.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "देवद्विजगुरुप्राज्ञपूजनं शौचमार्जवम्।ब्रह्मचर्यमहिंसा च शारीरं तप उच्यते।।17.14।।",
   "tr": "deva-dwija-guru-prājña- pūjanaṁ śhaucham ārjavam\nbrahmacharyam ahinsā cha śhārīraṁ tapa uchyate",
   "hi": "देव, द्विज (ब्राह्मण), गुरु और ज्ञानी जनों का पूजन, शौच, आर्जव (सरलता), ब्रह्मचर्य और अहिंसा, यह शरीर संबंधी तप कहा जाता है।।",
   "en": "Worship of God and the Master; respect for the preacher and the philosopher; purity, rectitude, continence, and harmlessness—all of these constitute physical austerity.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "अनुद्वेगकरं वाक्यं सत्यं प्रियहितं च यत्।स्वाध्यायाभ्यसनं चैव वाङ्मयं तप उच्यते।।17.15।।",
   "tr": "anudvega-karaṁ vākyaṁ satyaṁ priya-hitaṁ cha yat\nsvādhyāyābhyasanaṁ chaiva vāṅ-mayaṁ tapa uchyate",
   "hi": "जो वाक्य (भाषण) उद्वेग उत्पन्न करने वाला नहीं है, जो प्रिय, हितकारक और सत्य है तथा वेदों का स्वाध्याय अभ्यास वाङ्मय (वाणी का) तप कहलाता है।।",
   "en": "Speech that hurts no one, that is true, pleasant to listen to, and beneficial, and the constant study of the scriptures—this is austerity of speech.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "मनःप्रसादः सौम्यत्वं मौनमात्मविनिग्रहः।भावसंशुद्धिरित्येतत्तपो मानसमुच्यते।।17.16।।",
   "tr": "manaḥ-prasādaḥ saumyatvaṁ maunam ātma-vinigrahaḥ\nbhāva-sanśhuddhir ity etat tapo mānasam uchyate",
   "hi": "मन की प्रसन्नता, सौम्यभाव, मौन आत्मसंयम और अन्त:करण की शुद्धि यह सब मानस तप कहलाता है।।",
   "en": "Serenity, kindness, silence, self-control, and purity—these are the austerities of the mind.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "श्रद्धया परया तप्तं तपस्तत्ित्रविधं नरैः।अफलाकाङ्क्षिभिर्युक्तैः सात्त्विकं परिचक्षते।।17.17।।",
   "tr": "śhraddhayā parayā taptaṁ tapas tat tri-vidhaṁ naraiḥ\naphalākāṅkṣhibhir yuktaiḥ sāttvikaṁ parichakṣhate",
   "hi": "फल की आकांक्षा न रखने वाले युक्त पुरुषों के द्वारा परम श्रद्धा से किये गये उस पूर्वोक्त त्रिविध तप को सात्त्विक कहते हैं।।",
   "en": "These threefold austerities, performed with faith and without thought of reward, can truly be considered pure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "सत्कारमानपूजार्थं तपो दम्भेन चैव यत्।क्रियते तदिह प्रोक्तं राजसं चलमध्रुवम्।।17.18।।",
   "tr": "satkāra-māna-pūjārthaṁ tapo dambhena chaiva yat\nkriyate tad iha proktaṁ rājasaṁ chalam adhruvam",
   "hi": "जो तप सत्कार, मान और पूजा के लिए अथवा केवल दम्भ (पाखण्ड) से ही किया जाता है, वह अनिश्चित और क्षणिक तप यहाँ राजस कहा गया है।।",
   "en": "Austerity coupled with hypocrisy, or performed for the sake of self-glorification, popularity, or vanity, comes from passion, and its result is always uncertain and temporary.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "मूढग्राहेणात्मनो यत्पीडया क्रियते तपः।परस्योत्सादनार्थं वा तत्तामसमुदाहृतम्।।17.19।।",
   "tr": "mūḍha-grāheṇātmano yat pīḍayā kriyate tapaḥ\nparasyotsādanārthaṁ vā tat tāmasam udāhṛitam",
   "hi": "जो तप मूढ़तापूर्वक स्वयं को पीड़ित करते हुए अथवा अन्य लोगों के नाश के लिए किया जाता है, वह तप तामस कहा गया है।।",
   "en": "Austerity done under delusion, and accompanied with sorcery or the infliction of pain upon oneself or another, may be assumed to spring from ignorance.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "दातव्यमिति यद्दानं दीयतेऽनुपकारिणे।देशे काले च पात्रे च तद्दानं सात्त्विकं स्मृतम्।।17.20।।",
   "tr": "dātavyam iti yad dānaṁ dīyate ‘nupakāriṇe\ndeśhe kāle cha pātre cha tad dānaṁ sāttvikaṁ smṛitam",
   "hi": "\"दान देना ही कर्तव्य है\" - इस भाव से जो दान योग्य देश, काल को देखकर ऐसे (योग्य) पात्र (व्यक्ति) को दिया जाता है, जिससे प्रत्युपकार की अपेक्षा नहीं होती है, वह दान सात्त्विक माना गया है।।",
   "en": "The gift that is given without thought of recompense, believing it should be made, in an appropriate place, at an opportune time, and to a deserving person—such a gift is pure.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "यत्तु प्रत्युपकारार्थं फलमुद्दिश्य वा पुनः।दीयते च परिक्लिष्टं तद्दानं राजसं स्मृतम्।।17.21।।",
   "tr": "yat tu pratyupakārārthaṁ phalam uddiśhya vā punaḥ\ndīyate cha parikliṣhṭaṁ tad dānaṁ rājasaṁ smṛitam",
   "hi": "और जो दान क्लेशपूर्वक तथा प्रत्युपकार के उद्देश्य से अथवा फल की कामना रखकर दिया जाता हैं, वह दान राजस माना गया है।।",
   "en": "That which is given for the sake of the results it will produce, or with the hope of recompense, or grudgingly—that may truly be said to be the outcome of passion.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "अदेशकाले यद्दानमपात्रेभ्यश्च दीयते।असत्कृतमवज्ञातं तत्तामसमुदाहृतम्।।17.22।।",
   "tr": "adeśha-kāle yad dānam apātrebhyaśh cha dīyate\nasat-kṛitam avajñātaṁ tat tāmasam udāhṛitam",
   "hi": "जो दान बिना सत्कार किये, अथवा तिरस्कारपूर्वक, अयोग्य देशकाल में, कुपात्रों के लिए दिया जाता है, वह दान तामस माना गया है।।",
   "en": "And that which is given at an inappropriate place or time or to one who is undeserving, or with disrespect or contempt - such a gift is the result of ignorance.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "तत्सदिति निर्देशो ब्रह्मणस्त्रिविधः स्मृतः।ब्राह्मणास्तेन वेदाश्च यज्ञाश्च विहिताः पुरा।।17.23।।",
   "tr": "oṁ tat sad iti nirdeśho brahmaṇas tri-vidhaḥ smṛitaḥ\nbrāhmaṇās tena vedāśh cha yajñāśh cha vihitāḥ purā",
   "hi": "'ऊँ, तत् सत्' ऐसा यह ब्रह्म का त्रिविध निर्देश (नाम) कहा गया है; उसी से आदिकाल में (पुरा) ब्राहम्ण, वेद और यज्ञ निर्मित हुए हैं।।",
   "en": "Om Tat Sat is the triple designation of the Eternal Spirit, by which the Vedic Scriptures, ceremonials, and sacrifices were ordained of old.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "तस्मादोमित्युदाहृत्य यज्ञदानतपःक्रियाः।प्रवर्तन्ते विधानोक्ताः सततं ब्रह्मवादिनाम्।।17.24।।",
   "tr": "tasmād oṁ ity udāhṛitya yajña-dāna-tapaḥ-kriyāḥ\npravartante vidhānoktāḥ satataṁ brahma-vādinām",
   "hi": "इसलिए, ब्रह्मवादियों की शास्त्र प्रतिपादित यज्ञ, दान और तप की क्रियायें सदैव ओंकार के उच्चारण के साथ प्रारम्भ होती हैं।।",
   "en": "Therefore, all acts of sacrifice, gifts, and austerities prescribed by the scriptures are always begun by those who understand the Spirit with the word \"Om.\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "तदित्यनभिसन्धाय फलं यज्ञतपःक्रियाः।दानक्रियाश्च विविधाः क्रियन्ते मोक्षकाङ्क्षि।।17.25।।",
   "tr": "tad ity anabhisandhāya phalaṁ yajña-tapaḥ-kriyāḥ\ndāna-kriyāśh cha vividhāḥ kriyante mokṣha-kāṅkṣhibhiḥ",
   "hi": "'तत्' शब्द का उच्चारण कर, फल की इच्छा नहीं रखते हुए, मुमुक्षुजन यज्ञ, तप, दान आदि विविध कर्म करते हैं।।",
   "en": "Those who desire deliverance begin their acts of sacrifice, austerity, or gift with the word \"Tat\" (meaning \"That\"), without thought of reward.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "सद्भावे साधुभावे च सदित्येतत्प्रयुज्यते।प्रशस्ते कर्मणि तथा सच्छब्दः पार्थ युज्यते।।17.26।।",
   "tr": "sad-bhāve sādhu-bhāve cha sad ity etat prayujyate\npraśhaste karmaṇi tathā sach-chhabdaḥ pārtha yujyate",
   "hi": "हे पार्थ ! सत्य भाव व साधुभाव में 'सत्' शब्द का प्रयोग किया जाता है, और प्रशस्त (श्रेष्ठ, शुभ) कर्म में 'सत्' शब्द प्रयुक्त होता है।।",
   "en": "Sat' means Reality or the highest Good, and also, O Arjuna, it is used to denote an action of exceptional merit.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "यज्ञे तपसि दाने च स्थितिः सदिति चोच्यते।कर्म चैव तदर्थीयं सदित्येवाभिधीयते।।17.27।।",
   "tr": "yajñe tapasi dāne cha sthitiḥ sad iti chochyate\nkarma chaiva tad-arthīyaṁ sad ity evābhidhīyate",
   "hi": "यज्ञ, तप और दान में दृढ़ स्थिति भी सत् कही जाती है, और उस (परमात्मा) के लिए किया गया कर्म भी सत् ही कहलाता है।।",
   "en": "Conviction in sacrifice, austerity, and giving is also called Sat. So too, an action done only for the Lord's sake.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "अश्रद्धया हुतं दत्तं तपस्तप्तं कृतं च यत्।असदित्युच्यते पार्थ न च तत्प्रेत्य नो इह।।17.28।।",
   "tr": "aśhraddhayā hutaṁ dattaṁ tapas taptaṁ kṛitaṁ cha yat\nasad ity uchyate pārtha na cha tat pretya no iha",
   "hi": "हे पार्थ ! जो यज्ञ, दान, तप और कर्म अश्रद्धापूर्वक किया जाता है, वह 'असत्' कहा जाता है; वह न इस लोक में (इह) और न मरण के पश्चात् (उस लोक में) लाभदायक होता है।।",
   "en": "Whatever is done without faith, whether it be sacrifice, austerity, gift, or anything else, is called Asat (meaning \"Unreal\"), for it is the negation of Sat, O Arjuna! Such an act has no significance, here or hereafter.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
