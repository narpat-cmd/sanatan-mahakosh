// Bhagavad Gita adhyay 3 - Karma Yoga (43 shlok)
window.SCRIPTURE_CHUNKS = window.SCRIPTURE_CHUNKS || {};
window.SCRIPTURE_CHUNKS["bhagavad-gita/ch03"] = {
 "book": "bhagavad-gita",
 "section": "chapters",
 "chapter": 3,
 "title": "कर्मयोग",
 "illustration": "",
 "illustrationCaption": "Path of Selfless Service",
 "imageQuery": "Krishna Arjuna Bhagavad Gita",
 "summaryHi": "भगवद गीता का तीसरा अध्याय कर्मयोग या निःस्वार्थ सेवा का मार्ग है। इस अध्याय में भगवान श्रीकृष्ण जीवन में कर्म के महत्व पर जोर देते हैं। वे बताते हैं कि इस भौतिक संसार में हर मनुष्य का किसी न किसी प्रकार की क्रिया में सम्मिलित होना अनिवार्य है। इसके अलावा, वह उन कार्यों के बारे में बताते हैं जो मनुष्य को बांधते हैं अथवा वे जो मनुष्य को मुक्ति दिलाते हैं। वे मनुष्य जो अपने कर्तव्यों को भगवन की ख़ुशी के लिए एवं बिना फल की अपेक्षा किये हुए निरंतर करते रहते हैं, वे अंत में मुक्ति प्राप्त करते हैं।",
 "summaryEn": "The third chapter of the Bhagavad Gita is \"Karma Yoga\" or the \"Path of Selfless Service\". Here Lord Krishna emphasizes the importance of karma in life. He reveals that it is important for every human being to engage in some sort of activity in this material world. Further, he describes the kinds of actions that lead to bondage and the kinds that lead to liberation. Those persons who continue to perform their respective duties externally for the pleasure of the Supreme, without attachment to its rewards get liberation at the end.",
 "verses": [
  {
   "n": 1,
   "sa": "अर्जुन उवाच\nज्यायसी चेत्कर्मणस्ते मता बुद्धिर्जनार्दन।\nतत्किं कर्मणि घोरे मां नियोजयसि केशव।।3.1।।",
   "tr": "arjuna uvācha\njyāyasī chet karmaṇas te matā buddhir janārdana\ntat kiṁ karmaṇi ghore māṁ niyojayasi keśhava",
   "hi": "हे जनार्दन यदि आपको यह मान्य है कि कर्म से ज्ञान श्रेष्ठ है तो फिर हे केशव आप मुझे इस भयंकर कर्म में क्यों प्रवृत्त करते हैं",
   "en": "Arjuna questioned: My Lord! If wisdom is superior to action, why do you advise me to engage in this terrible fight?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 2,
   "sa": "व्यामिश्रेणेव वाक्येन बुद्धिं मोहयसीव मे।\nतदेकं वद निश्िचत्य येन श्रेयोऽहमाप्नुयाम्।।3.2।।",
   "tr": "vyāmiśhreṇeva vākyena buddhiṁ mohayasīva me\ntad ekaṁ vada niśhchitya yena śhreyo ’ham āpnuyām",
   "hi": "आप इस मिश्रित वाक्य से मेरी बुद्धि को मोहितसा करते हैं अत आप उस एक (मार्ग) को निश्चित रूप से कहिये जिससे मैं परम श्रेय को प्राप्त कर सकूँ।।",
   "en": "Your language confuses me and confounds my reason. Therefore, please tell me the only way by which I can, without doubt, secure my spiritual welfare.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 3,
   "sa": "श्री भगवानुवाच\nलोकेऽस्मिन्द्विविधा निष्ठा पुरा प्रोक्ता मयानघ।\nज्ञानयोगेन सांख्यानां कर्मयोगेन योगिनाम्।।3.3।।",
   "tr": "śhrī bhagavān uvācha\nloke’smin dvi-vidhā niṣhṭhā purā proktā mayānagha\njñāna-yogena sāṅkhyānāṁ karma-yogena yoginām",
   "hi": "श्री भगवान् ने कहा हे निष्पाप (अनघ) अर्जुन इस श्लोक में दो प्रकार की निष्ठा मेरे द्वारा पहले कही गयी है ज्ञानियों की (सांख्यानां) ज्ञानयोग से और योगियों की कर्मयोग से।।",
   "en": "Lord Shri Krishna replied: In this world, as I have said, there is a twofold path, O sinless one! There is the path of wisdom for those who meditate, and the path of action for those who work.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 4,
   "sa": "न कर्मणामनारम्भान्नैष्कर्म्यं पुरुषोऽश्नुते।\nन च संन्यसनादेव सिद्धिं समधिगच्छति।।3.4।।",
   "tr": "na karmaṇām anārambhān naiṣhkarmyaṁ puruṣho ’śhnute\nna cha sannyasanād eva siddhiṁ samadhigachchhati",
   "hi": "कर्मों के न करने से मनुष्य नैर्ष्कम्य को प्राप्त नहीं होता और न कर्मों के संन्यास से ही वह सिद्धि (पूर्णत्व) प्राप्त करता है।।",
   "en": "No one can attain freedom from action by abstaining from action, nor can they reach perfection by simply not acting.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 5,
   "sa": "न हि कश्िचत्क्षणमपि जातु तिष्ठत्यकर्मकृत्।\nकार्यते ह्यवशः कर्म सर्वः प्रकृतिजैर्गुणैः।।3.5।।",
   "tr": "na hi kaśhchit kṣhaṇam api jātu tiṣhṭhatyakarma-kṛit\nkāryate hyavaśhaḥ karma sarvaḥ prakṛiti-jair guṇaiḥ",
   "hi": "कोई भी पुरुष कभी क्षणमात्र भी बिना कर्म किए नहीं रह सकता क्योंकि प्रकृति से उत्पन्न गुणों के द्वारा अवश हुए सब (पुरुषों) से कर्म करवा लिया जाता है।।",
   "en": "He cannot remain inactive even for a moment, for the qualities of Nature will compel him to act, whether he wills it or not.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 6,
   "sa": "कर्मेन्द्रियाणि संयम्य य आस्ते मनसा स्मरन्।\nइन्द्रियार्थान्विमूढात्मा मिथ्याचारः स उच्यते।।3.6।।",
   "tr": "karmendriyāṇi sanyamya ya āste manasā smaran\nindriyārthān vimūḍhātmā mithyāchāraḥ sa uchyate",
   "hi": "जो मूढ बुद्धि पुरुष कर्मेन्द्रियों का निग्रह कर इन्द्रियों के भोगों का मन से स्मरण (चिन्तन) करता रहता है वह मिथ्याचारी (दम्भी) कहा जाता है।।",
   "en": "He who remains motionless, refusing to act, yet brooding over sensuous objects, is that deluded soul simply a hypocrite.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 7,
   "sa": "यस्त्विन्द्रियाणि मनसा नियम्यारभतेऽर्जुन।\nकर्मेन्द्रियैः कर्मयोगमसक्तः स विशिष्यते।।3.7।।",
   "tr": "yas tvindriyāṇi manasā niyamyārabhate ’rjuna\nkarmendriyaiḥ karma-yogam asaktaḥ sa viśhiṣhyate",
   "hi": "परन्तु हे अर्जुन जो पुरुष मन से इन्द्रियों को वश में करके अनासक्त हुआ कर्मेंन्द्रियों से कर्मयोग का आचरण करता है वह श्रेष्ठ है।।",
   "en": "But, O Arjuna! All honor to him whose mind controls his senses, for he is thereby beginning to practice Karma-Yoga, the Path of Right Action, keeping himself always unattached.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 8,
   "sa": "नियतं कुरु कर्म त्वं कर्म ज्यायो ह्यकर्मणः।\nशरीरयात्रापि च ते न प्रसिद्ध्येदकर्मणः।।3.8।।",
   "tr": "niyataṁ kuru karma tvaṁ karma jyāyo hyakarmaṇaḥ\nśharīra-yātrāpi cha te na prasiddhyed akarmaṇaḥ",
   "hi": "तुम (अपने) नियत (कर्तव्य) कर्म करो क्योंकि अकर्म से श्रेष्ठ कर्म है। तुम्हारे अकर्म होने से (तुम्हारा) शरीर निर्वाह भी नहीं सिद्ध होगा।।",
   "en": "Do your duty as prescribed, for action for duty's sake is superior to inaction. Even the maintenance of the body would be impossible if one remained inactive.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 9,
   "sa": "यज्ञार्थात्कर्मणोऽन्यत्र लोकोऽयं कर्मबन्धनः।\nतदर्थं कर्म कौन्तेय मुक्तसंगः समाचर।।3.9।।",
   "tr": "yajñārthāt karmaṇo ’nyatra loko ’yaṁ karma-bandhanaḥ\ntad-arthaṁ karma kaunteya mukta-saṅgaḥ samāchara",
   "hi": "यज्ञ के लिये किये हुए कर्म के अतिरिक्त अन्य कर्म में प्रवृत्त हुआ यह पुरुष कर्मों द्वारा बंधता है इसलिए हे कौन्तेय आसक्ति को त्यागकर यज्ञ के निमित्त ही कर्म का सम्यक् आचरण करो।।",
   "en": "In this world, people are fettered by their actions, unless they are performed as a sacrifice. Therefore, O Arjuna, let your actions be done without attachment, as a sacrifice only.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 10,
   "sa": "सहयज्ञाः प्रजाः सृष्ट्वा पुरोवाच प्रजापतिः।\nअनेन प्रसविष्यध्वमेष वोऽस्त्विष्टकामधुक्।।3.10।।",
   "tr": "saha-yajñāḥ prajāḥ sṛiṣhṭvā purovācha prajāpatiḥ\nanena prasaviṣhyadhvam eṣha vo ’stviṣhṭa-kāma-dhuk",
   "hi": "प्रजापति (सृष्टिकर्त्ता) ने (सृष्टि के) आदि में यज्ञ सहित प्रजा का निर्माण कर कहा इस यज्ञ द्वारा तुम वृद्धि को प्राप्त हो और यह यज्ञ तुम्हारे लिये इच्छित कामनाओं को पूर्ण करने वाला (इष्टकामधुक्) होवे।।",
   "en": "In the beginning, when God created all beings through the sacrifice of Himself, He said to them: \"You can procreate through sacrifice, and it shall satisfy all your desires.\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 11,
   "sa": "देवान्भावयतानेन ते देवा भावयन्तु वः।\nपरस्परं भावयन्तः श्रेयः परमवाप्स्यथ।।3.11।।",
   "tr": "devān bhāvayatānena te devā bhāvayantu vaḥ\nparasparaṁ bhāvayantaḥ śhreyaḥ param avāpsyatha",
   "hi": "तुम लोग इस यज्ञ द्वारा देवताओं की उन्नति करो और वे देवतागण तुम्हारी उन्नति करें। इस प्रकार परस्पर उन्नति करते हुये परम श्रेय को तुम प्राप्त होगे।।",
   "en": "Worship the powers of Nature, and let them nourish you in return; thus, supporting each other, you shall attain your highest welfare.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 12,
   "sa": "इष्टान्भोगान्हि वो देवा दास्यन्ते यज्ञभाविताः।\nतैर्दत्तानप्रदायैभ्यो यो भुङ्क्ते स्तेन एव सः।।3.12।।",
   "tr": "iṣhṭān bhogān hi vo devā dāsyante yajña-bhāvitāḥ\ntair dattān apradāyaibhyo yo bhuṅkte stena eva saḥ",
   "hi": "यज्ञ द्वारा पोषित देवतागण तुम्हें इष्ट भोग प्रदान करेंगे। उनके द्वारा दिये हुये भोगों को जो पुरुष उनको दिये बिना ही भोगता है वह निश्चय ही चोर है।।",
   "en": "For, fed by sacrifice, nature will give you all the enjoyment you desire. But he who enjoys what she gives without returning is, indeed, a thief.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 13,
   "sa": "यज्ञशिष्टाशिनः सन्तो मुच्यन्ते सर्वकिल्बिषैः।\nभुञ्जते ते त्वघं पापा ये पचन्त्यात्मकारणात्।।3.13।।",
   "tr": "yajña-śhiṣhṭāśhinaḥ santo muchyante sarva-kilbiṣhaiḥ\nbhuñjate te tvaghaṁ pāpā ye pachantyātma-kāraṇāt",
   "hi": "यज्ञ के अवशिष्ट अन्न को खाने वाले श्रेष्ठ पुरुष सब पापों से मुक्त हो जाते हैं किन्तु जो लोग केवल स्वयं के लिये ही पकाते हैं वे तो पापों को ही खाते हैं।।",
   "en": "The sages who enjoy the food that remains after the sacrifice is made are freed from all sins; whereas, the selfish who spread their feast only for themselves feed on sin alone.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 14,
   "sa": "अन्नाद्भवन्ति भूतानि पर्जन्यादन्नसम्भवः।\nयज्ञाद्भवति पर्जन्यो यज्ञः कर्मसमुद्भवः।।3.14।।",
   "tr": "annād bhavanti bhūtāni parjanyād anna-sambhavaḥ\nyajñād bhavati parjanyo yajñaḥ karma-samudbhavaḥ",
   "hi": "समस्त प्राणी अन्न से उत्पन्न होते हैं अन्न की उत्पत्ति पर्जन्य से। पर्जन्य की उत्पत्ति यज्ञ से और यज्ञ कर्मों से उत्पन्न होता है।।",
   "en": "All creatures are the product of food; food is the product of rain; rain comes from sacrifice, and sacrifice is the noblest form of action.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 15,
   "sa": "कर्म ब्रह्मोद्भवं विद्धि ब्रह्माक्षरसमुद्भवम्।\nतस्मात्सर्वगतं ब्रह्म नित्यं यज्ञे प्रतिष्ठितम्।।3.15।।",
   "tr": "karma brahmodbhavaṁ viddhi brahmākṣhara-samudbhavam\ntasmāt sarva-gataṁ brahma nityaṁ yajñe pratiṣhṭhitam",
   "hi": "कर्म की उत्पत्ति ब्रह्माजी से होती है और ब्रह्माजी अक्षर तत्त्व से व्यक्त होते हैं। इसलिये सर्व व्यापी ब्रह्म सदा ही यज्ञ में प्रतिष्ठित है।।",
   "en": "All actions originate from the Supreme Spirit, which is Imperishable, and in sacrificial actions, the all-pervasive Spirit is consciously present.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 16,
   "sa": "एवं प्रवर्तितं चक्रं नानुवर्तयतीह यः।\nअघायुरिन्द्रियारामो मोघं पार्थ स जीवति।।3.16।।",
   "tr": "evaṁ pravartitaṁ chakraṁ nānuvartayatīha yaḥ\naghāyur indriyārāmo moghaṁ pārtha sa jīvati",
   "hi": "जो पुरुष यहाँ इस प्रकार प्रवर्तित हुए चक्र का अनुवर्तन नहीं करता हे पार्थ इंन्द्रियों में रमने वाला वह पाप आयु पुरुष व्यर्थ ही जीता है।।",
   "en": "Thus, he who does not help the revolving wheel of sacrifice, but instead leads a sinful life, rejoicing in the gratification of his senses, O Arjuna, is breathing in vain.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 17,
   "sa": "यस्त्वात्मरतिरेव स्यादात्मतृप्तश्च मानवः।\nआत्मन्येव च सन्तुष्टस्तस्य कार्यं न विद्यते।।3.17।।",
   "tr": "yas tvātma-ratir eva syād ātma-tṛiptaśh cha mānavaḥ\nātmanyeva cha santuṣhṭas tasya kāryaṁ na vidyate",
   "hi": "परन्तु जो मनुष्य आत्मा में ही रमने वाला आत्मा में ही तृप्त तथा आत्मा में ही सन्तुष्ट हो उसके लिये कोई कर्तव्य नहीं रहता।।",
   "en": "On the other hand, the soul who meditates on the Self is content to serve the Self and rests satisfied in the Self; there is nothing more for them to accomplish.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 18,
   "sa": "नैव तस्य कृतेनार्थो नाकृतेनेह कश्चन।\nन चास्य सर्वभूतेषु कश्िचदर्थव्यपाश्रयः।।3.18।।",
   "tr": "naiva tasya kṛitenārtho nākṛiteneha kaśhchana\nna chāsya sarva-bhūteṣhu kaśhchid artha-vyapāśhrayaḥ",
   "hi": "इस जगत् में उस पुरुष का कृत और अकृत से कोई प्रयोजन नहीं है और न वह किसी वस्तु के लिये भूतमात्र पर आश्रित होता है।।",
   "en": "He has nothing to gain from the performance or non-performance of action; his welfare does not depend on any contribution that an earthly creature can make.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 19,
   "sa": "तस्मादसक्तः सततं कार्यं कर्म समाचर।\nअसक्तो ह्याचरन्कर्म परमाप्नोति पूरुषः।।3.19।।",
   "tr": "tasmād asaktaḥ satataṁ kāryaṁ karma samāchara\nasakto hyācharan karma param āpnoti pūruṣhaḥ",
   "hi": "इसलिए, तुम अनासक्त होकर सदैव कर्तव्य कर्म का सम्यक् आचरण करो; क्योकि, अनासक्त पुरुष कर्म करता हुआ परमात्मा को प्राप्त होता है।।",
   "en": "Therefore, do your duty perfectly, without worrying about the results, for he who does his duty without attachment attains the Supreme.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 20,
   "sa": "कर्मणैव हि संसिद्धिमास्थिता जनकादयः।\nलोकसंग्रहमेवापि संपश्यन्कर्तुमर्हसि।।3.20।।",
   "tr": "karmaṇaiva hi sansiddhim āsthitā janakādayaḥ\nloka-saṅgraham evāpi sampaśhyan kartum arhasi",
   "hi": "जनकादि (ज्ञानी जन) भी कर्म द्वारा ही संसिद्धि को प्राप्त हुये लोक संग्रह (लोक रक्षण) को भी देखते हुये; तुम कर्म करने योग्य हो।।",
   "en": "King Janaka and others attained perfection through action alone. Even for the sake of enlightening the world, it is your duty to act.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 21,
   "sa": "यद्यदाचरति श्रेष्ठस्तत्तदेवेतरो जनः।\nस यत्प्रमाणं कुरुते लोकस्तदनुवर्तते।।3.21।।",
   "tr": "yad yad ācharati śhreṣhṭhas tat tad evetaro janaḥ\nsa yat pramāṇaṁ kurute lokas tad anuvartate",
   "hi": "श्रेष्ठ पुरुष जैसा आचरण करता है, अन्य लोग भी वैसा ही अनुकरण करते हैं; वह पुरुष जो कुछ प्रमाण कर देता है, लोग भी उसका अनुसरण करते हैं।।",
   "en": "For whatever a great man does, others imitate; people conform to the standard he has set.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 22,
   "sa": "न मे पार्थास्ति कर्तव्यं त्रिषु लोकेषु किञ्चन।\nनानवाप्तमवाप्तव्यं वर्त एव च कर्मणि।।3.22।।",
   "tr": "na me pārthāsti kartavyaṁ triṣhu lokeṣhu kiñchana\nnānavāptam avāptavyaṁ varta eva cha karmaṇi",
   "hi": "यद्यपि मुझे त्रैलोक्य में कुछ भी कर्तव्य नहीं हैं तथा किंचित भी प्राप्त होने योग्य (अवाप्तव्यम्) वस्तु अप्राप्त नहीं है, तो भी मैं कर्म में ही बर्तता हूँ।।",
   "en": "There is nothing in this universe, O Arjuna, that I am compelled to do, nor anything for me to attain; yet I persistently remain active.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 23,
   "sa": "यदि ह्यहं न वर्तेयं जातु कर्मण्यतन्द्रितः।\nमम वर्त्मानुवर्तन्ते मनुष्याः पार्थ सर्वशः।।3.23।।",
   "tr": "yadi hyahaṁ na varteyaṁ jātu karmaṇyatandritaḥ\nmama vartmānuvartante manuṣhyāḥ pārtha sarvaśhaḥ",
   "hi": "यदि मैं सावधान हुआ (अतन्द्रित:) कदाचित कर्म में न लगा रहूँ तो, हे पार्थ ! सब प्रकार से मनुष्य मेरे मार्ग (र्वत्म) का अनुसरण करेंगे।।",
   "en": "Were I not to act without ceasing, O prince, people would be inclined to do the same.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 24,
   "sa": "उत्सीदेयुरिमे लोका न कुर्यां कर्म चेदहम्।\nसङ्करस्य च कर्ता स्यामुपहन्यामिमाः प्रजाः।।3.24।।",
   "tr": "utsīdeyur ime lokā na kuryāṁ karma ched aham\nsankarasya cha kartā syām upahanyām imāḥ prajāḥ",
   "hi": "यदि मैं कर्म न करूँ, तो ये समस्त लोक नष्ट हो जायेंगे; और मैं वर्णसंकर का कर्ता तथा इस प्रजा का हनन करने वाला होऊँगा।।",
   "en": "And if I were to refrain from action, the human race would be ruined; I would lead the world to chaos, and destruction would follow.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 25,
   "sa": "सक्ताः कर्मण्यविद्वांसो यथा कुर्वन्ति भारत।\nकुर्याद्विद्वांस्तथासक्तश्िचकीर्षुर्लोकसंग्रहम्।।3.25।।",
   "tr": "saktāḥ karmaṇyavidvānso yathā kurvanti bhārata\nkuryād vidvāns tathāsaktaśh chikīrṣhur loka-saṅgraham",
   "hi": "हे भारत ! कर्म में आसक्त हुए अज्ञानीजन जैसे कर्म करते हैं वैसे ही विद्वान् पुरुष अनासक्त होकर, लोकसंग्रह (लोक कल्याण) की इच्छा से कर्म करे।।",
   "en": "As the ignorant act, out of their fondness for action, so should the wise act without attachment, fixing their eyes, O Arjuna, only on the welfare of the world.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 26,
   "sa": "न बुद्धिभेदं जनयेदज्ञानां कर्मसङ्गिनाम्।\nजोषयेत्सर्वकर्माणि विद्वान् युक्तः समाचरन्।।3.26।।",
   "tr": "na buddhi-bhedaṁ janayed ajñānāṁ karma-saṅginām\njoṣhayet sarva-karmāṇi vidvān yuktaḥ samācharan",
   "hi": "ज्ञानी पुरुष, कर्मों में आसक्त अज्ञानियों की बुद्धि में भ्रम उत्पन्न न करे, स्वयं (भक्ति से) युक्त होकर कर्मों का सम्यक् आचरण कर, उनसे भी वैसा ही कराये।।",
   "en": "But a wise man should not disturb the minds of the ignorant, who are attached to action; let him perform his own actions in the right spirit, with concentration on Me, thus inspiring all others to do the same.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 27,
   "sa": "प्रकृतेः क्रियमाणानि गुणैः कर्माणि सर्वशः।\nअहङ्कारविमूढात्मा कर्ताऽहमिति मन्यते।।3.27।।",
   "tr": "prakṛiteḥ kriyamāṇāni guṇaiḥ karmāṇi sarvaśhaḥ\nahankāra-vimūḍhātmā kartāham iti manyate",
   "hi": "सम्पूर्ण कर्म प्रकृति के गुणों द्वारा किये जाते हैं, अहंकार से मोहित हुआ पुरुष, \"मैं कर्ता हूँ\" ऐसा मान लेता है।।",
   "en": "Action is the product of the qualities inherent in nature. It is only the ignorant man who, misled by personal egotism, says, \"I am the doer.\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 28,
   "sa": "तत्त्ववित्तु महाबाहो गुणकर्मविभागयोः।\nगुणा गुणेषु वर्तन्त इति मत्वा न सज्जते।।3.28।।",
   "tr": "tattva-vit tu mahā-bāho guṇa-karma-vibhāgayoḥ\nguṇā guṇeṣhu vartanta iti matvā na sajjate",
   "hi": "परन्तु हे महाबाहो ! गुण और कर्म के विभाग के सत्य (तत्त्व)को जानने वाला ज्ञानी पुरुष यह जानकर कि \"गुण गुणों में बर्तते हैं\" (कर्म में) आसक्त नहीं होता।।",
   "en": "But he, O Mighty One, who correctly understands the relationship between the Qualities and action, is not attached to the act, for he perceives that it is merely the action and reaction of the Qualities among themselves.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 29,
   "sa": "प्रकृतेर्गुणसम्मूढाः सज्जन्ते गुणकर्मसु।\nतानकृत्स्नविदो मन्दान्कृत्स्नविन्न विचालयेत्।।3.29।।",
   "tr": "prakṛiter guṇa-sammūḍhāḥ sajjante guṇa-karmasu\ntān akṛitsna-vido mandān kṛitsna-vin na vichālayet",
   "hi": "प्रकृति के गुणों से मोहित हुए पुरुष गुण और कर्म में आसक्त होते हैं, उन अपूर्ण ज्ञान वाले (अकृत्स्नविद:) मंदबुद्धि पुरुषों को पूर्ण ज्ञान प्राप्त पुरुष विचलित न करे।।",
   "en": "Those who do not understand the qualities are interested in the act; however, the wise man who knows the truth should not disturb the mind of those who do not.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 30,
   "sa": "मयि सर्वाणि कर्माणि संन्यस्याध्यात्मचेतसा।\nनिराशीर्निर्ममो भूत्वा युध्यस्व विगतज्वरः।।3.30।।",
   "tr": "mayi sarvāṇi karmāṇi sannyasyādhyātma-chetasā\nnirāśhīr nirmamo bhūtvā yudhyasva vigata-jvaraḥ",
   "hi": "सम्पूर्ण कर्मों का मुझ में संन्यास करके, आशा और ममता से रहित होकर, संतापरहित हुए तुम युद्ध करो।।",
   "en": "Therefore, surrender your actions to Me, keep your thoughts focused on the Absolute, free from selfishness and without expecting a reward, with a mind free from excitement, begin to fight.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 31,
   "sa": "ये मे मतमिदं नित्यमनुतिष्ठन्ति मानवाः।\nश्रद्धावन्तोऽनसूयन्तो मुच्यन्ते तेऽपि कर्मभिः।।3.31।।",
   "tr": "ye me matam idaṁ nityam anutiṣhṭhanti mānavāḥ\nśhraddhāvanto ’nasūyanto muchyante te ’pi karmabhiḥ",
   "hi": "जो मनुष्य दोष बुद्धि से रहित (अनसूयन्त:) और श्रद्धा से युक्त हुए सदा मेरे इस मत (उपदेश) का अनुष्ठानपूर्वक पालन करते हैं, वे कर्मों से (बन्धन से) मुक्त हो जाते हैं।।",
   "en": "Those who always act in accordance with My precepts, firmly in faith and without caviling, they too are freed from the bondage of action.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 32,
   "sa": "ये त्वेतदभ्यसूयन्तो नानुतिष्ठन्ति मे मतम्।\nसर्वज्ञानविमूढांस्तान्विद्धि नष्टानचेतसः।।3.32।।",
   "tr": "ye tvetad abhyasūyanto nānutiṣhṭhanti me matam\nsarva-jñāna-vimūḍhāns tān viddhi naṣhṭān achetasaḥ",
   "hi": "परन्तु जो दोष दृष्टि वाले मूढ़ लोग इस मेरे मत का पालन नहीं करते, उन सब ज्ञानों में मोहित चित्तवालों को नष्ट हुये ही तुम समझो।।",
   "en": "But they who ridicule My word and do not observe it, are ignorant, devoid of wisdom, and blind. They seek only their own destruction.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 33,
   "sa": "सदृशं चेष्टते स्वस्याः प्रकृतेर्ज्ञानवानपि।\nप्रकृतिं यान्ति भूतानि निग्रहः किं करिष्यति।।3.33।।",
   "tr": "sadṛiśhaṁ cheṣhṭate svasyāḥ prakṛiter jñānavān api\nprakṛitiṁ yānti bhūtāni nigrahaḥ kiṁ kariṣhyati",
   "hi": "ज्ञानवान् पुरुष भी अपनी प्रकृति के अनुसार चेष्टा करता है। सभी प्राणी अपनी प्रकृति पर ही जाते हैं, फिर इनमें (किसी का) निग्रह क्या करेगा।।",
   "en": "Even the wise man acts in accordance with his nature; indeed, all creatures act according to their natures. What is the use of compulsion then?",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 34,
   "sa": "इन्द्रियस्येन्द्रियस्यार्थे रागद्वेषौ व्यवस्थितौ।\nतयोर्न वशमागच्छेत्तौ ह्यस्य परिपन्थिनौ।।3.34।।",
   "tr": "indriyasyendriyasyārthe rāga-dveṣhau vyavasthitau\ntayor na vaśham āgachchhet tau hyasya paripanthinau",
   "hi": "इन्द्रियइन्द्रिय (अर्थात् प्रत्येक इन्द्रिय) के विषय के प्रति (मन में) रागद्वेष रहते हैं; मनुष्य को चाहिये कि वह उन दोनों के वश में न हो; क्योंकि वे इसके (मनुष्य के) शत्रु हैं।।",
   "en": "The love and hate that are aroused by the objects of sense arise from Nature; do not yield to them, as they only obstruct the path.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 35,
   "sa": "श्रेयान्स्वधर्मो विगुणः परधर्मात्स्वनुष्ठितात्।\nस्वधर्मे निधनं श्रेयः परधर्मो भयावहः।।3.35।।",
   "tr": "śhreyān swa-dharmo viguṇaḥ para-dharmāt sv-anuṣhṭhitāt\nswa-dharme nidhanaṁ śhreyaḥ para-dharmo bhayāvahaḥ",
   "hi": "सम्यक् प्रकार से अनुष्ठित परधर्म की अपेक्षा गुणरहित स्वधर्म का पालन श्रेयष्कर है; स्वधर्म में मरण कल्याणकारक है (किन्तु) परधर्म भय को देने वाला है।।",
   "en": "It is better to do one's own duty, however lacking in merit, than to do that of another, even though efficiently. It is better to die doing one's own duty, for doing the duty of another is fraught with danger.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 36,
   "sa": "अर्जुन उवाच\nअथ केन प्रयुक्तोऽयं पापं चरति पूरुषः।\nअनिच्छन्नपि वार्ष्णेय बलादिव नियोजितः।।3.36।।",
   "tr": "arjuna uvācha\natha kena prayukto ’yaṁ pāpaṁ charati pūruṣhaḥ\nanichchhann api vārṣhṇeya balād iva niyojitaḥ",
   "hi": "अर्जुन ने कहा -- हे वार्ष्णेय ! फिर यह पुरुष बलपूर्वक बाध्य किये हुये के समान अनिच्छा होते हुये भी किसके द्वारा प्रेरित होकर पाप का आचरण करता है?",
   "en": "Arjuna asked, \"My Lord, what is it that drives a person to sin, even against their will and as if by compulsion?\"",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 37,
   "sa": "श्री भगवानुवाच\nकाम एष क्रोध एष रजोगुणसमुद्भवः।\nमहाशनो महापाप्मा विद्ध्येनमिह वैरिणम्।।3.37।।",
   "tr": "śhrī bhagavān uvācha\nkāma eṣha krodha eṣha rajo-guṇa-samudbhavaḥ\nmahāśhano mahā-pāpmā viddhyenam iha vairiṇam",
   "hi": "श्रीभगवान् ने कहा -- रजोगुण में उत्पन्न हुई यह 'कामना' है, यही क्रोध है; यह महाशना (जिसकी भूख बड़ी हो) और महापापी है, इसे ही तुम यहाँ (इस जगत् में) शत्रु जानो।।",
   "en": "Lord Shri Krishna: It is desire, it is aversion, born of passion. Desire consumes and corrupts all things. It is the greatest enemy of man.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 38,
   "sa": "धूमेनाव्रियते वह्निर्यथाऽऽदर्शो मलेन च।\nयथोल्बेनावृतो गर्भस्तथा तेनेदमावृतम्।।3.38।।",
   "tr": "dhūmenāvriyate vahnir yathādarśho malena cha\nyatholbenāvṛito garbhas tathā tenedam āvṛitam",
   "hi": "जैसे धुयें से अग्नि और धूलि से दर्पण ढक जाता है तथा जैसे भ्रूण गर्भाशय से ढका रहता है, वैसे उस (काम) के द्वारा यह (ज्ञान) आवृत होता है।।",
   "en": "As fire is shrouded by smoke, a mirror is covered by dust, and a child is enveloped by the womb, so is the universe enveloped in desire.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 39,
   "sa": "आवृतं ज्ञानमेतेन ज्ञानिनो नित्यवैरिणा।\nकामरूपेण कौन्तेय दुष्पूरेणानलेन च।।3.39।।",
   "tr": "āvṛitaṁ jñānam etena jñānino nitya-vairiṇā\nkāma-rūpeṇa kaunteya duṣhpūreṇānalena cha",
   "hi": "हे कौन्तेय ! अग्नि के समान जिसको तृप्त करना कठिन है ऐसे कामरूप, ज्ञानी के इस नित्य शत्रु द्वारा ज्ञान आवृत है।।",
   "en": "It is the wise man's constant enemy; it tarnishes the face of wisdom, being as insatiable as a flame of fire.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 40,
   "sa": "इन्द्रियाणि मनो बुद्धिरस्याधिष्ठानमुच्यते।\nएतैर्विमोहयत्येष ज्ञानमावृत्य देहिनम्।।3.40।।",
   "tr": "indriyāṇi mano buddhir asyādhiṣhṭhānam uchyate\netair vimohayatyeṣha jñānam āvṛitya dehinam",
   "hi": "इन्द्रियाँ, मन और बुद्धि इसके निवास स्थान कहे जाते हैं; यह काम इनके द्वारा ही ज्ञान को आच्छादित करके देही पुरुष को मोहित करता है।।",
   "en": "It works through the senses, the mind, and the reason; and with their help, it destroys wisdom and confounds the soul.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 41,
   "sa": "तस्मात्त्वमिन्द्रियाण्यादौ नियम्य भरतर्षभ।\nपाप्मानं प्रजहि ह्येनं ज्ञानविज्ञाननाशनम्।।3.41।।",
   "tr": "tasmāt tvam indriyāṇyādau niyamya bharatarṣhabha\npāpmānaṁ prajahi hyenaṁ jñāna-vijñāna-nāśhanam",
   "hi": "इसलिये, हे अर्जुन ! तुम पहले इन्द्रियों को वश में करके, ज्ञान और विज्ञान के नाशक इस कामरूप पापी को नष्ट करो।।",
   "en": "Therefore, O Arjuna, first control your senses and then slay desire, for it is full of sin and is the destroyer of knowledge and wisdom.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 42,
   "sa": "इन्द्रियाणि पराण्याहुरिन्द्रियेभ्यः परं मनः।\nमनसस्तु परा बुद्धिर्यो बुद्धेः परतस्तु सः।।3.42।।",
   "tr": "indriyāṇi parāṇyāhur indriyebhyaḥ paraṁ manaḥ\nmanasas tu parā buddhir yo buddheḥ paratas tu saḥ",
   "hi": "(शरीर से) परे (श्रेष्ठ) इन्द्रियाँ कही जाती हैं; इन्द्रियों से परे मन है और मन से परे बुद्धि है, और जो बुद्धि से भी परे है, वह है आत्मा।।",
   "en": "It is said that the senses are powerful; however, beyond the senses is the mind, beyond the mind is the intellect, and greater than the intellect is He.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  },
  {
   "n": 43,
   "sa": "एवं बुद्धेः परं बुद्ध्वा संस्तभ्यात्मानमात्मना।\nजहि शत्रुं महाबाहो कामरूपं दुरासदम्।।3.43।।",
   "tr": "evaṁ buddheḥ paraṁ buddhvā sanstabhyātmānam ātmanā\njahi śhatruṁ mahā-bāho kāma-rūpaṁ durāsadam",
   "hi": "इस प्रकार बुद्धि से परे (शुद्ध) आत्मा को जानकर आत्मा (बुद्धि) के द्वारा आत्मा (मन) को वश में करके, हे महाबाहो ! तुम इस दुर्जेय (दुरासदम्) कामरूप शत्रु को मारो।।",
   "en": "Thus, O Mighty-Armed One, knowing Him to be beyond the intellect, and with His help, subdue your personal ego and kill your enemy, Desire, even though it is extremely difficult.",
   "source": "github.com/gita/gita (Unlicense); Hindi: Swami Tejomayananda; English: Shri Purohit Swami",
   "license": "dataset Unlicense; translations credited to authors"
  }
 ]
};
